# Política de Seguridad de la Información

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / CISO
**Cierra:** FMT-01, FMT-09 (Backcasting CTO)
**Referencia:** ISO 27001 (no certificado, como guía de mejores prácticas)

---

## 1. Principios

1. **Confidencialidad:** La información se comparte solo con quien la necesita para su función.
2. **Integridad:** La información no se modifica sin autorización y se mantiene precisa.
3. **Disponibilidad:** Los sistemas y datos están accesibles cuando se necesitan.

---

## 2. Clasificación de la Información

| Nivel | Definición | Ejemplos | Controles mínimos |
|-------|-----------|----------|-------------------|
| **RESTRINGIDO** | Daño grave si se filtra | Contratos firmados, datos financieros, credenciales, datos personales de clientes, API keys | Cifrado, acceso solo por rol, MFA obligatorio, no compartir por chat |
| **CONFIDENCIAL** | Daño moderado si se filtra | Propuestas comerciales, pricing, estrategia, materiales no publicados | Acceso limitado al equipo del proyecto, no compartir externamente sin NDA |
| **INTERNO** | Solo para uso interno | Procesos, SOPs, rituales, templates operativos | Acceso al equipo MetodologIA, no publicar externamente |
| **PÚBLICO** | Diseñado para ser público | Sitio web, redes sociales, catálogo público, blog | Sin restricción |

---

## 3. Control de Accesos

### Principios

- **Mínimo privilegio:** Cada persona solo accede a lo que necesita para su función.
- **Segregación de funciones:** Quien aprueba pagos no es quien los ejecuta.
- **MFA obligatorio** en: email corporativo, CRM, sistema contable, panel de dominio/DNS, plataformas con datos de clientes.

### Credenciales y Secretos (FMT-09)

| Regla | Detalle |
|-------|---------|
| **Passwords** | Mínimo 12 caracteres, únicas por plataforma, gestor de contraseñas obligatorio (ej. 1Password, Bitwarden) |
| **API Keys** | NUNCA en código fuente, NUNCA por chat/email. Usar variables de entorno o gestor de secretos. |
| **Tokens de acceso** | Rotación cada 90 días para tokens de larga duración |
| **Compartir credenciales** | PROHIBIDO compartir por WhatsApp, Slack, email. Usar el gestor de contraseñas compartido. |
| **Cuentas de servicio** | Documentadas en `inventario-accesos-plataformas.md` con owner asignado |

### Onboarding/Offboarding de accesos

- **Al vincular:** Crear accesos según rol conforme a `sop-gestion-accesos.md`
- **Al desvincular:** Revocar TODOS los accesos dentro de **24 horas** post-desvinculación

---

## 4. Uso Aceptable de Recursos

| Permitido | Prohibido |
|-----------|-----------|
| Usar herramientas corporativas para trabajo | Instalar software no autorizado en equipos corporativos |
| Usar email corporativo para comunicación de negocio | Usar email personal para comunicación con clientes |
| Almacenar archivos de trabajo en Drive corporativo | Almacenar archivos de trabajo en Drive personal |
| Usar IA generativa conforme a `politica-uso-aceptable-ia.md` | Pegar datos RESTRINGIDOS en herramientas de IA externas |

---

## 5. Gestión de Incidentes de Seguridad

Para incidentes que involucren **datos personales:** seguir `plan-respuesta-brechas-datos.md`
Para incidentes de **infraestructura/plataformas:** seguir `sop-incidentes-ti.md`

### Clasificación rápida

| Tipo | Ejemplo | Severidad | Respuesta |
|------|---------|-----------|-----------|
| Acceso no autorizado a datos de cliente | Ex-empleado accede a Drive | CRÍTICO | Revocar acceso inmediato, investigar, notificar si datos comprometidos |
| Malware/Ransomware | Laptop infectada | CRÍTICO | Aislar equipo, no pagar, restaurar de backup |
| Phishing exitoso | Alguien dio credenciales en sitio falso | ALTO | Cambiar password inmediato + MFA, revisar actividad |
| Caída de plataforma crítica | LMS no funciona durante bootcamp | ALTO | Contactar proveedor, activar plan B, comunicar a clientes |
| API key expuesta | Key publicada en repo público | ALTO | Rotar key inmediatamente, auditar uso |

---

## 6. Responsabilidades

| Rol | Responsabilidad de seguridad |
|-----|----------------------------|
| **CTO/CISO** | Definir políticas, auditar cumplimiento, gestionar incidentes |
| **Todo el equipo** | Cumplir políticas, reportar incidentes, usar MFA, no compartir credenciales |
| **Administrador TI** | Gestionar accesos, backups, monitoreo, actualizaciones |
| **COO** | Aprobar presupuesto de seguridad, decisiones de riesgo |

---

## 7. Sanciones

| Infracción | Consecuencia |
|-----------|-------------|
| Compartir credenciales por chat | Amonestación escrita + cambio obligatorio de passwords |
| No activar MFA después de ser notificado | Suspensión de acceso hasta activación |
| Pegar datos RESTRINGIDOS en IA externa | Amonestación grave + reporte de incidente |
| Acceso no autorizado intencional a información | Terminación de relación + posible acción legal (Ley 1273/2009) |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-01, 09 / Javier Montaño + Claude

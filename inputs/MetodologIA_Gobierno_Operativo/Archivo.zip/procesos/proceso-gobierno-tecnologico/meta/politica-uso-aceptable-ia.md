# Política de Uso Aceptable de IA Generativa

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / COO
**Cierra:** FMT-10 (Backcasting CTO)

---

## 1. Propósito

Establecer reglas para el uso responsable de herramientas de IA generativa (Claude, ChatGPT, Gemini, NotebookLM, Copilot, Midjourney, etc.) en el contexto de MetodologIA, protegiendo datos de clientes y propiedad intelectual.

---

## 2. Reglas Fundamentales

### LO QUE NUNCA SE PEGA EN UN PROMPT DE IA EXTERNA

| Categoría | Ejemplos | Razón |
|-----------|----------|-------|
| **Datos personales de clientes** | Nombres, emails, teléfonos, NIT, cédulas de personas del cliente | Ley 1581/2012 + riesgo de entrenamiento del modelo |
| **Información financiera del cliente** | Estados financieros, precios específicos, contratos con montos | Confidencialidad contractual |
| **Credenciales** | API keys, passwords, tokens | Seguridad |
| **Código fuente propietario del cliente** | Si estamos en consultoría y el cliente comparte su código | NDA + IP |
| **Información clasificada como RESTRINGIDA** | Cualquier dato de la clasificación "RESTRINGIDO" de la política de seguridad | Política interna |

### LO QUE SÍ SE PUEDE USAR CON IA

| Categoría | Ejemplos | Condición |
|-----------|----------|-----------|
| Información pública | Contenido del blog, catálogo público, frameworks publicados | Sin restricción |
| Drafts internos sin datos de cliente | Borradores de SOPs, rituales, templates genéricos | Aceptable |
| Código genérico (no del cliente) | Scripts internos, automatizaciones, plantillas | Aceptable |
| Preguntas de conocimiento general | "¿Cómo funciona NIIF 15?", "¿Qué dice el Art. 641 del ET?" | Sin restricción |
| Material de formación genérico | Contenido educativo sin datos específicos de clientes | Aceptable |

---

## 3. Reglas por Herramienta

| Herramienta | Nivel de confianza | Datos permitidos | Notas |
|------------|-------------------|-----------------|-------|
| **Claude Code** (local) | ALTO | Información interna, código | Ejecución local, no envía datos a entrenar |
| **NotebookLM** (Google) | MEDIO | Documentos internos sin datos RESTRINGIDOS | Google puede usar datos para mejorar servicio — revisar ToS |
| **ChatGPT** (OpenAI) | MEDIO | Solo información pública o interna genérica | Opt-out de entrenamiento si se usa versión Team/Enterprise |
| **Copilot** (Microsoft/GitHub) | MEDIO | Código genérico | No pegar código del cliente |
| **Herramientas de IA del cliente** | SEGÚN CONTRATO | Lo que el contrato permita | Verificar DPA/NDA antes de usar |

---

## 4. Propiedad Intelectual de Outputs de IA

| Situación | Regla |
|-----------|-------|
| Output de IA para uso interno | MetodologIA lo usa libremente (revisar, editar, publicar como propio) |
| Output de IA como entregable al cliente | DEBE ser revisado, editado, y mejorado por un humano. No entregar output raw. Declarar si el cliente pregunta. |
| Output de IA para material de formación | Aceptable si se revisa por un experto humano y se verifica la veracidad |
| Output de IA para documentos legales | SOLO como borrador. SIEMPRE revisión por abogado antes de uso (ya documentado como disclaimer en templates legales) |

---

## 5. Checklist de Uso de IA

Antes de pegar información en una herramienta de IA, preguntarse:

- [ ] ¿Contiene datos personales de alguien? → SI: NO PEGAR
- [ ] ¿Contiene información financiera específica de un cliente? → SI: NO PEGAR
- [ ] ¿Contiene credenciales o secretos? → SI: NO PEGAR
- [ ] ¿Está clasificada como RESTRINGIDA? → SI: NO PEGAR
- [ ] ¿Estoy usando una herramienta aprobada? → SI: PROCEDER CON CUIDADO
- [ ] ¿El output será entregado al cliente? → SI: REVISAR ANTES DE ENTREGAR

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-10 / Javier Montaño + Claude

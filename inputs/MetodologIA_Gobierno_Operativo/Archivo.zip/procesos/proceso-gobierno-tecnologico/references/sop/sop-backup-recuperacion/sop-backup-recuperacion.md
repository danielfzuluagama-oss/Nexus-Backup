# SOP: Backup y Recuperación de Datos

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / Admin TI
**Cierra:** FMT-03 (Backcasting CTO)

---

## 1. Propósito

Garantizar que la información crítica de MetodologIA tiene copias de respaldo automatizadas, verificadas, y que se puede restaurar dentro de un tiempo objetivo (RTO) aceptable.

---

## 2. Clasificación de Datos y Política de Backup

| Categoría | Ejemplos | RPO (Recovery Point Objective) | RTO (Recovery Time Objective) | Frecuencia de backup |
|-----------|----------|------|------|---------------------|
| **Crítico** | Contratos, estados financieros, base de datos de clientes, facturación | 1 día | 4 horas | Diario |
| **Importante** | Material de cursos, propuestas, SOPs, governance docs | 1 semana | 24 horas | Semanal |
| **Operativo** | Emails, chat logs, documentos de trabajo en progreso | 1 semana | 48 horas | Semanal (automático por plataforma) |

---

## 3. Estrategia de Backup: 3-2-1

- **3** copias de cada dato crítico (original + 2 backups)
- **2** tipos de medio diferentes (ej. Drive + disco externo, o Drive + otro cloud)
- **1** copia offsite (fuera de la ubicación principal)

---

## 4. Procedimiento

### Backup Automático (configurar una vez, verificar periódicamente)

| Fuente | Destino backup | Frecuencia | Método | Responsable |
|--------|---------------|-----------|--------|------------|
| Google Drive corporativo | [Cloud secundario o disco externo cifrado] | Diario | Sync automático o script | Admin TI |
| Sistema contable | Exportación a Drive + copia local | Semanal | Exportación manual o automática | Contador + Admin TI |
| CRM / Pipeline | Exportación CSV/JSON a Drive | Semanal | Exportación manual | Operaciones |
| Repositorio de governance (este directorio) | Git o sync a cloud secundario | Diario | Git push o rsync | Admin TI |
| Correo electrónico | Google Vault (si G-Suite Business+) o exportación | Continuo | Automático por Google | Admin TI |

### Verificación de Backup

| Acción | Frecuencia | Responsable |
|--------|-----------|------------|
| Verificar que el backup diario se ejecutó (revisar logs) | Semanal | Admin TI |
| Restaurar un archivo aleatorio del backup para verificar integridad | Mensual | Admin TI |
| Simulacro de restauración completa (un sistema completo) | Semestral | CTO + Admin TI |

---

## 5. Procedimiento de Restauración

| Paso | Acción | Responsable |
|------|--------|------------|
| 1 | Identificar qué datos se perdieron y desde cuándo | Admin TI |
| 2 | Localizar el backup más reciente que contenga los datos | Admin TI |
| 3 | Restaurar en ubicación temporal (NO sobreescribir directamente) | Admin TI |
| 4 | Verificar integridad de los datos restaurados | Admin TI + owner de los datos |
| 5 | Mover a ubicación definitiva | Admin TI |
| 6 | Documentar el incidente: qué se perdió, causa, tiempo de recuperación | Admin TI |

---

## 6. Retención de Backups

| Tipo | Retención |
|------|----------|
| Backups diarios | 30 días (rolling) |
| Backups semanales | 12 semanas (rolling) |
| Backups mensuales | 12 meses (rolling) |
| Backup de cierre fiscal anual | 10 años (conforme a política de archivo documental) |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-03 / Javier Montaño + Claude

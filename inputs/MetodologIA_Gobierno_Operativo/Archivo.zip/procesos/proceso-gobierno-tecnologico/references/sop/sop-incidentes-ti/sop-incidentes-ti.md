# SOP: Gestión de Incidentes de TI

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / Admin TI
**Cierra:** FMT-05 (Backcasting CTO)

---

## 1. Propósito

Definir cómo se reportan, diagnostican, escalan, resuelven y documentan los incidentes de tecnología que afectan la operación.

---

## 2. Clasificación

| Severidad | Definición | Ejemplo | SLA de respuesta |
|-----------|-----------|---------|-----------------|
| **P1 — Crítico** | Servicio crítico caído, afecta a clientes en vivo | LMS caído durante bootcamp, sitio web down, email no funciona | Respuesta: 30 min. Resolución: 4h. |
| **P2 — Alto** | Servicio degradado o componente importante caído | CRM lento, facturación no genera CUFE, Drive inaccesible | Respuesta: 2h. Resolución: 8h. |
| **P3 — Medio** | Problema individual que no afecta a otros | Laptop de un usuario con problema, acceso individual denegado | Respuesta: 4h. Resolución: 24h. |
| **P4 — Bajo** | Solicitud o mejora, no urgente | Solicitud de nueva licencia, cambio de configuración | Respuesta: 24h. Resolución: 5 días. |

---

## 3. Procedimiento

### Paso 1: Reporte
- Cualquier persona reporta al canal designado: [email/Slack/formulario]
- Incluir: qué no funciona, desde cuándo, a quiénes afecta, capturas de pantalla

### Paso 2: Clasificación y asignación
- Admin TI clasifica (P1-P4) y asigna responsable
- Si es P1: notificación inmediata a CTO + comunicación a afectados

### Paso 3: Diagnóstico y resolución
- Investigar causa raíz
- Aplicar fix (reinicio, parche, contacto con proveedor, restauración de backup)
- Si requiere contacto con proveedor externo: escalar con número de ticket

### Paso 4: Comunicación
| Severidad | Comunicar a |
|-----------|------------|
| P1 | Equipo completo + clientes afectados + CTO + COO |
| P2 | Equipo afectado + CTO |
| P3-P4 | Solo al reportante |

### Paso 5: Cierre y post-mortem
- Registrar: causa, solución, tiempo de resolución
- Para P1 y P2: post-mortem dentro de 48h con acción preventiva

---

## 4. Registro

```
## INCIDENTE TI — INC-TI-[AAAA]-[###]

**Reportado por:** [___]  **Fecha/hora:** [___]
**Severidad:** ☐ P1 | ☐ P2 | ☐ P3 | ☐ P4
**Plataforma afectada:** [___]
**Descripción:** [___]
**Impacto:** [# usuarios afectados, servicio interrumpido]
**Asignado a:** [___]
**Causa raíz:** [___]
**Solución aplicada:** [___]
**Fecha/hora de resolución:** [___]
**Tiempo total de resolución:** [___]h
**Acción preventiva:** [___]
**Estado:** ☐ Abierto | ☐ En progreso | ☐ Resuelto | ☐ Cerrado
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-05 / Javier Montaño + Claude

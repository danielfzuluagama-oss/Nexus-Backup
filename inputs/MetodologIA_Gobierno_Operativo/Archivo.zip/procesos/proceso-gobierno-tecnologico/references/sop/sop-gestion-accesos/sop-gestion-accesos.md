# SOP: Gestión de Accesos — Onboarding, Offboarding y Revisión

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / Administrador TI
**Cierra:** FMT-02, FMT-12 (Backcasting CTO)

---

## 1. Propósito

Gobernar quién tiene acceso a qué plataforma, garantizar que los accesos se otorgan por rol, se revisan periódicamente, y se revocan dentro de 24h al desvincular a alguien.

---

## 2. Matriz de Accesos por Rol

| Plataforma | Empleado | Sales Rep | Facilitador/Consultor | Embajador | Director | Admin TI |
|-----------|---------|----------|---------------------|-----------|---------|---------|
| Email corporativo | ✅ | ✅ | ☐ (solo si contrato >3 meses) | ❌ | ✅ | ✅ |
| Drive corporativo | ✅ (su carpeta) | ✅ (comercial) | ✅ (proyecto) | ❌ | ✅ (todo) | ✅ (todo) |
| CRM | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ |
| Sistema contable | ❌ | ❌ | ❌ | ❌ | ☐ (solo CFO/Contador) | ✅ |
| LMS / Plataforma educativa | ☐ | ❌ | ✅ (como facilitador) | ❌ | ✅ | ✅ |
| Herramientas de IA (Claude, NotebookLM) | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ |
| Panel de dominio/DNS | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ (solo 2 personas) |
| Facturación electrónica (DIAN) | ❌ | ❌ | ❌ | ❌ | ☐ (Contador) | ✅ |
| Redes sociales | ❌ | ❌ | ❌ | ❌ | ☐ (Marketing) | ✅ |

---

## 3. Onboarding Tecnológico (al vincular)

| Paso | Acción | Responsable | Plazo |
|------|--------|------------|-------|
| 1 | RRHH/Operaciones notifica nueva vinculación con: nombre, rol, fecha inicio, proyecto | RRHH | D-3 |
| 2 | Admin TI crea accesos según matriz de rol | Admin TI | D-1 |
| 3 | Configurar MFA en todas las plataformas asignadas | Admin TI + nuevo vinculado | Día 1 |
| 4 | Enviar credenciales por gestor de contraseñas (NUNCA por chat/email) | Admin TI | Día 1 |
| 5 | Inducción de seguridad: política, clasificación, uso de IA, reporte de incidentes (15 min) | Admin TI o CTO | Semana 1 |
| 6 | Registrar en `inventario-accesos-plataformas.md` | Admin TI | Día 1 |

---

## 4. Offboarding Tecnológico (al desvincular) — **MÁXIMO 24 HORAS**

| Paso | Acción | Responsable | Plazo |
|------|--------|------------|-------|
| 1 | RRHH/Operaciones notifica desvinculación con: nombre, fecha efectiva, motivo | RRHH | Día de notificación |
| 2 | Revocar acceso a email corporativo | Admin TI | Dentro de 2h |
| 3 | Revocar acceso a Drive corporativo (o mover archivos a carpeta de handover) | Admin TI | Dentro de 4h |
| 4 | Revocar acceso a CRM, LMS, y todas las plataformas de la matriz | Admin TI | Dentro de 8h |
| 5 | Cambiar passwords de cuentas compartidas que el desvinculado conocía | Admin TI | Dentro de 24h |
| 6 | Recuperar equipo corporativo (laptop, token, etc.) si aplica | RRHH + Admin TI | Según acuerdo |
| 7 | Actualizar `inventario-accesos-plataformas.md` | Admin TI | Dentro de 24h |
| 8 | Verificar que NO quedan accesos residuales | Admin TI | D+3 |

**REGLA:** Si la desvinculación es por causa disciplinaria o conflictiva, los pasos 2-4 se ejecutan **INMEDIATAMENTE** (antes de notificar al desvinculado si es posible).

---

## 5. Revisión Periódica de Accesos

| Frecuencia | Acción | Responsable |
|-----------|--------|------------|
| **Mensual** | Verificar que todos los accesos activos corresponden a personas activas | Admin TI |
| **Trimestral** | Auditar que los roles coinciden con los accesos (nadie tiene más de lo necesario) | CTO |
| **Anual** | Forzar cambio de passwords en todas las plataformas | Admin TI |

---

## 6. Inventario de Accesos

```
## INVENTARIO DE ACCESOS — [Actualizado: DD/MM/AAAA]

| # | Persona | Rol | Plataformas con acceso | MFA activo | Fecha alta | Fecha baja |
|---|---------|-----|----------------------|-----------|-----------|-----------|
| 1 | [___] | [___] | Email, Drive, CRM | ☐ SÍ / ☐ NO | [___] | [___] |
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-02, 12 / Javier Montaño + Claude

# Plan de Continuidad de Negocio — Componente Tecnológico (BCP-TI)

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / COO
**Cierra:** FMT-08 (Backcasting CTO)

---

## 1. Servicios Críticos y Plan B

| Servicio | Proveedor actual | Criticidad | RTO | Plan B si cae |
|---------|-----------------|-----------|-----|-------------|
| **Email corporativo** | Google Workspace | CRÍTICO | 2h | Comunicar por WhatsApp Business. Migrar a Microsoft 365 si caída >24h. |
| **Drive / Almacenamiento** | Google Drive | CRÍTICO | 4h | Backup en [cloud secundario]. Acceder desde backup. |
| **LMS / Plataforma educativa** | [Proveedor] | CRÍTICO (durante bootcamp/workshop) | 2h (si hay evento en vivo) | Sesión por Zoom/Meet + material compartido por Drive. Reprogramar si >4h. |
| **Videoconferencia** | Zoom / Google Meet | ALTO | 1h | Cambiar a la plataforma alternativa (si Zoom cae, usar Meet y viceversa). |
| **CRM** | [Proveedor] | ALTO | 8h | Gestión temporal en spreadsheet. Migrar si caída >48h. |
| **Facturación electrónica** | [Proveedor DIAN] | ALTO | 24h | Contactar proveedor. Si >48h, evaluar proveedor alternativo habilitado por DIAN. |
| **Sitio web** | [Hosting] | MEDIO | 24h | DNS failover a hosting alternativo o página estática temporal. |
| **Dominio / DNS** | [Registrador] | CRÍTICO | 1h | Tener acceso a panel DNS con al menos 2 personas. Auto-renovación activa. |

---

## 2. Escenarios de Desastre

| Escenario | Probabilidad | Impacto | Respuesta |
|-----------|-------------|---------|-----------|
| Google desactiva la cuenta corporativa | Baja | CRÍTICO | Backup reciente disponible. Migrar a alternativa en 48h. |
| Laptop del CEO/COO robada o perdida | Media | ALTO | Borrado remoto (si MDM activo). Cambiar passwords de todas las cuentas. |
| Ransomware en equipo del equipo | Baja | ALTO | Aislar equipo. NO pagar. Restaurar de backup. |
| Proveedor LMS cierra operaciones | Muy baja | CRÍTICO (a mediano plazo) | Exportar contenido inmediatamente. Migrar a alternativa en 30 días. |
| Dominio expira sin renovación | Baja (evitable) | CRÍTICO | Activar auto-renovación. Verificar trimestralmente. |

---

## 3. Contactos de Emergencia

| Servicio | Proveedor | Contacto soporte | SLA del proveedor |
|---------|-----------|-----------------|-------------------|
| Google Workspace | Google | [URL soporte] | [Según plan contratado] |
| LMS | [___] | [___] | [___] |
| Facturación electrónica | [___] | [___] | [___] |
| Hosting/Dominio | [___] | [___] | [___] |

---

## 4. Simulacro

| Frecuencia | Tipo | Participantes |
|-----------|------|--------------|
| Semestral | Tabletop: "¿Qué hacemos si X cae?" | CTO + COO + Admin TI |
| Anual | Restauración real de backup completo | Admin TI + CTO |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMT-08 / Javier Montaño + Claude

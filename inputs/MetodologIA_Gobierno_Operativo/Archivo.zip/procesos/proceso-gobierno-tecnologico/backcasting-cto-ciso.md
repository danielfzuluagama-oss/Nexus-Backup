# Backcasting CTO / CISO — Modos de Fallo Tecnológicos y de Seguridad

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / CISO / COO
**Método:** Backcasting — "¿Qué le reprocharía un auditor de seguridad informática a una empresa de servicios tech sin gobierno TI?"
**Contexto Legal:** Colombia — Ley 1273/2009 (Delitos informáticos), Ley 1581/2012 (Datos personales), ISO 27001 (referencia)

---

## Modos de Fallo

### FMT-01: Sin Política de Seguridad de la Información

| Campo | Valor |
|-------|-------|
| **Categoría** | Seguridad |
| **Severidad** | CRÍTICO |
| **Descripción** | No existe un documento que defina principios, roles, clasificación de información, controles de acceso, uso aceptable de recursos, y gestión de incidentes de seguridad. Sin política, cada persona decide por su cuenta qué es seguro. |
| **Mitigación actual** | `plan-respuesta-brechas-datos.md` cubre respuesta a incidentes de datos personales, pero NO hay política general de seguridad TI. |
| **Documento requerido** | `politica-seguridad-informacion.md` |

---

### FMT-02: Sin Control de Accesos — Passwords Compartidas, Sin MFA

| Campo | Valor |
|-------|-------|
| **Categoría** | Accesos / Identidad |
| **Severidad** | CRÍTICO |
| **Descripción** | Cuentas de plataformas (LMS, CRM, Drive, herramientas de facturación, redes sociales) con credenciales compartidas, sin MFA, sin registro de quién tiene acceso a qué. Cuando alguien se va, los accesos no se revocan. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-gestion-accesos.md` + `inventario-accesos-plataformas.md` |

---

### FMT-03: Sin Backups — Pérdida de Datos Irrecuperable

| Campo | Valor |
|-------|-------|
| **Categoría** | Continuidad |
| **Severidad** | CRÍTICO |
| **Descripción** | Los documentos críticos (contratos, estados financieros, material de cursos, CRM) no tienen backup automatizado. Si se borra un Google Drive o un laptop se pierde, no hay recuperación. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-backup-recuperacion.md` |

---

### FMT-04: Sin Inventario de Activos Tecnológicos

| Campo | Valor |
|-------|-------|
| **Categoría** | Infraestructura |
| **Severidad** | ALTO |
| **Descripción** | No se sabe cuántos laptops, licencias de software, dominios, suscripciones cloud, APIs existen. Sin inventario, no se puede proteger lo que no se conoce. Licencias expiran sin aviso. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `inventario-activos-tecnologicos.md` |

---

### FMT-05: Sin Gestión de Incidentes de TI

| Campo | Valor |
|-------|-------|
| **Categoría** | Operaciones TI |
| **Severidad** | ALTO |
| **Descripción** | Cuando una plataforma cae (LMS, sitio web, CRM), no hay procedimiento: ¿quién reporta? ¿quién diagnostica? ¿cuál es el SLA interno? ¿cómo se comunica a los afectados? |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-incidentes-ti.md` |

---

### FMT-06: Sin Acuerdo de Nivel de Servicio con Proveedores Tech

| Campo | Valor |
|-------|-------|
| **Categoría** | Vendor Management |
| **Severidad** | ALTO |
| **Descripción** | Las plataformas críticas (LMS, videoconferencia, email, facturación electrónica) no tienen SLA documentado. Si el proveedor LMS tiene 48h de downtime durante un bootcamp en vivo, no hay recurso contractual. |
| **Mitigación actual** | `checklist-due-diligence-proveedores.md` cubre selección pero no SLA operativo ongoing. |
| **Documento requerido** | `plantilla-sla-proveedores-tech.md` |

---

### FMT-07: Sin Política de Desarrollo Seguro / No-Code Seguro

| Campo | Valor |
|-------|-------|
| **Categoría** | Desarrollo |
| **Severidad** | MEDIO |
| **Descripción** | Si MetodologIA construye herramientas internas (dashboards, automatizaciones, plataformas con IA), no hay guía de seguridad: validación de inputs, manejo de secretos (API keys), dependencias con vulnerabilidades, código revisado antes de producción. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `politica-desarrollo-seguro.md` |

---

### FMT-08: Sin Plan de Continuidad de Negocio (BCP) Tecnológico

| Campo | Valor |
|-------|-------|
| **Categoría** | Continuidad |
| **Severidad** | ALTO |
| **Descripción** | Si Google desactiva la cuenta, si el dominio expira, si el proveedor de facturación electrónica cierra: no hay plan B documentado. ¿Cuáles son los servicios críticos? ¿Cuál es el RTO/RPO? |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `plan-continuidad-negocio-ti.md` |

---

### FMT-09: API Keys y Secretos en Texto Plano

| Campo | Valor |
|-------|-------|
| **Categoría** | Seguridad |
| **Severidad** | ALTO |
| **Descripción** | API keys de plataformas (NotebookLM, OpenAI, DIAN, pasarelas de pago) almacenadas en archivos .env sin cifrar, compartidas por chat, o hardcodeadas. Una filtración expone todo. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `politica-seguridad-informacion.md` (sección de gestión de secretos) |

---

### FMT-10: Sin Política de Uso Aceptable de IA Generativa

| Campo | Valor |
|-------|-------|
| **Categoría** | IA / Compliance |
| **Severidad** | MEDIO |
| **Descripción** | El equipo usa herramientas de IA (Claude, ChatGPT, NotebookLM) sin guía sobre: qué datos se pueden pegar en prompts, qué información del cliente NO debe ir a LLMs externos, qué outputs se pueden entregar como propios. Riesgo de filtrar datos confidenciales del cliente. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `politica-uso-aceptable-ia.md` |

---

### FMT-11: Dominio y DNS Sin Governance

| Campo | Valor |
|-------|-------|
| **Categoría** | Infraestructura |
| **Severidad** | MEDIO |
| **Descripción** | ¿Quién es el dueño registrado del dominio? ¿Cuándo vence? ¿Hay auto-renovación? ¿Quién tiene acceso al panel DNS? Si el dominio expira, el sitio web, email, y toda la operación digital se detiene. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `inventario-activos-tecnologicos.md` (sección dominios) |

---

### FMT-12: Sin Offboarding Tecnológico

| Campo | Valor |
|-------|-------|
| **Categoría** | Accesos / RRHH |
| **Severidad** | ALTO |
| **Descripción** | Cuando un embajador, facilitador, o empleado deja de trabajar con MetodologIA, no hay checklist de revocación de accesos: Drive, CRM, LMS, Slack, email, repositorios, herramientas de IA. Ex-colaboradores retienen acceso indefinidamente. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-gestion-accesos.md` (sección offboarding) + cross-ref con RRHH |

---

## Resumen

| Severidad | Total | Con mitigación | Sin mitigación |
|-----------|-------|---------------|----------------|
| CRÍTICO | 3 | 1 | 2 |
| ALTO | 6 | 1 | 5 |
| MEDIO | 3 | 0 | 3 |
| **TOTAL** | **12** | **2** | **10** |

---

## Changelog

- v1.0.0 — Creación inicial con 12 FMTs / Javier Montaño + Claude

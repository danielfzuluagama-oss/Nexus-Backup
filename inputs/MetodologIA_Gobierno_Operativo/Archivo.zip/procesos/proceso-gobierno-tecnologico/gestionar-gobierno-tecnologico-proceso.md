# Proceso: Gestionar Gobierno Tecnológico y Seguridad de la Información

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CTO / CISO (o COO si no hay CTO dedicado)

---

## 1. Propósito

Proteger los activos digitales, garantizar la continuidad operativa de las plataformas, gestionar accesos de forma segura, y establecer prácticas de desarrollo y uso de IA responsables.

---

## 2. Artefactos del Proceso

### Políticas

| Documento | Cierra FMT | Ubicación |
|-----------|-----------|-----------|
| `politica-seguridad-informacion.md` | FMT-01, 09 | `meta/` |
| `politica-desarrollo-seguro.md` | FMT-07 | `meta/` |
| `politica-uso-aceptable-ia.md` | FMT-10 | `meta/` |

### SOPs

| SOP | Cierra FMT | Ubicación |
|-----|-----------|-----------|
| `sop-gestion-accesos.md` | FMT-02, 12 | `references/sop/sop-gestion-accesos/` |
| `sop-backup-recuperacion.md` | FMT-03 | `references/sop/sop-backup-recuperacion/` |
| `sop-incidentes-ti.md` | FMT-05 | `references/sop/sop-incidentes-ti/` |

### Assets

| Asset | Cierra FMT | Ubicación |
|-------|-----------|-----------|
| `inventario-activos-tecnologicos.md` | FMT-04, 11 | `assets/` |
| `plantilla-sla-proveedores-tech.md` | FMT-06 | `assets/templates/` |
| `plan-continuidad-negocio-ti.md` | FMT-08 | `assets/` |

---

## 3. Cadencias

| Actividad | Frecuencia | Responsable |
|----------|-----------|------------|
| Revisión de inventario de accesos | Mensual | CTO/COO |
| Verificación de backups | Semanal (automática) + mensual (manual) | TI |
| Actualización de inventario de activos | Trimestral | TI |
| Simulacro de recuperación de desastres | Semestral | CTO + equipo |
| Revisión de política de seguridad | Anual | CTO/CISO |
| Auditoría de accesos revocados post-offboarding | Mensual | TI + RRHH |

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

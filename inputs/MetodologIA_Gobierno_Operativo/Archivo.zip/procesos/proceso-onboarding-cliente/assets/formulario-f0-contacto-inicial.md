# Formulario F0 — Contacto Inicial

**Versión:** 1.0.0
**Fase:** F0 — Awareness
**Campos:** 3 (mínimo viable)
**Tiempo de completado:** <30 segundos

---

## Campos

| # | Campo | Tipo | Obligatorio | Validación |
|---|-------|------|------------|-----------|
| 1 | **Nombre completo** | Texto | SÍ | Min 2 caracteres |
| 2 | **Email** | Email | SÍ | Formato email válido |
| 3 | **Empresa** | Texto | NO | Libre |

---

## Aviso de Privacidad (texto al pie del formulario)

> Al enviar este formulario, autoriza el tratamiento de sus datos personales conforme a nuestra [Política de Privacidad](link). Sus datos serán utilizados únicamente para contactarle sobre nuestros servicios. Puede ejercer sus derechos de acceso, rectificación y supresión escribiendo a [email OPD].

---

## Regla de Datos

- **NO recolectar:** teléfono, cargo, tamaño de empresa, presupuesto
- **Propósito:** Crear el primer registro con mínima fricción
- **Siguiente paso:** Sales Rep contacta al lead → completa F1 en la primera interacción

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

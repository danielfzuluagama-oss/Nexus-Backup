# Template: Ceremonia de Kickoff

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Cierra:** FM-16 (Backcasting COO)
**Duración:** 90 minutos
**Formato:** Presencial o virtual (preferir presencial para deals >COP 50M)

---

## Agenda

| Tiempo | Bloque | Facilitador | Propósito |
|--------|--------|------------|-----------|
| 0-10 min | **Bienvenida y contexto** | Director Comercial | Presentar a MetodologIA, agradecer confianza, visión del proyecto |
| 10-20 min | **Presentación del equipo** | Todos | Cada persona: nombre, rol, una expectativa |
| 20-35 min | **Alcance y entregables** | Project Manager / Delivery Lead | Revisar ODS, confirmar alcance, entregables, fechas clave |
| 35-50 min | **Métricas de éxito** | Project Manager + SPOC cliente | Co-definir 3-5 métricas SMART. Ref: `definir-metricas-exito-sop.md` |
| 50-60 min | **SLA y comunicación** | Project Manager | Establecer baseline de SLA. Definir canal, frecuencia, formato de comunicación |
| 60-70 min | **Riesgos y dependencias** | Project Manager + SPOC cliente | Identificar top 3 riesgos y acciones de mitigación |
| 70-80 min | **Próximos pasos** | Project Manager | Semana 1: qué se entrega, qué necesitamos del cliente |
| 80-90 min | **Cierre y foto** | Director Comercial | Energía positiva, compromiso mutuo, foto del equipo |

---

## Preparación (3 días antes)

| Tarea | Responsable | Deadline |
|-------|------------|---------|
| Confirmar asistentes (cliente + MetodologIA) | Project Manager | D-3 |
| Preparar presentación de kickoff | Project Manager | D-2 |
| Verificar que F2 está completo (contrato firmado, documentos recibidos) | Operaciones | D-3 |
| Preparar SLA baseline draft | Operaciones | D-2 |
| Reservar sala / enviar link de videoconferencia | Admin | D-3 |

---

## Follow-up (dentro de 24h post-kickoff)

| Tarea | Responsable | Deadline |
|-------|------------|---------|
| Enviar minuta del kickoff a todos los participantes | Project Manager | D+1 |
| Confirmar métricas de éxito acordadas | Project Manager | D+1 |
| Crear espacio de trabajo compartido (si aplica) | TI | D+2 |
| Solicitar accesos pendientes al cliente | Project Manager | D+1 |
| Registrar riesgos en registro de riesgos de onboarding | Project Manager | D+1 |

---

## Template de Minuta

```
## MINUTA DE KICKOFF — [Nombre del Proyecto/Cliente]

**Fecha:** [_______________]
**Asistentes MetodologIA:** [Lista]
**Asistentes Cliente:** [Lista]
**Facilitador:** [_______________]

### Alcance confirmado
[Resumen del alcance según ODS]

### Métricas de éxito acordadas
1. [Métrica SMART]
2. [Métrica SMART]
3. [Métrica SMART]

### SLA baseline
- Tiempo de respuesta: [___]h
- Frecuencia de reporte: [Semanal/Quincenal]
- Canal primario: [Email/Slack/Teams]

### Riesgos identificados
| Riesgo | Probabilidad | Impacto | Mitigación | Owner |
|--------|-------------|---------|-----------|-------|
| [___] | A/M/B | A/M/B | [___] | [___] |

### Próximos pasos (Semana 1)
| Acción | Responsable | Deadline |
|--------|------------|---------|
| [___] | [___] | [___] |

### Compromisos del cliente
| Compromiso | Responsable | Deadline |
|-----------|------------|---------|
| [___] | [___] | [___] |
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-16 / Javier Montaño + Claude

# Formulario F3 — Kickoff

**Versión:** 1.0.0
**Fase:** F3 — Kickoff
**Campos:** 8+
**Tiempo de completado:** 20 minutos (colaborativo con cliente en ceremonia de kickoff)

---

## Campos

| # | Campo | Tipo | Obligatorio |
|---|-------|------|------------|
| 1 | **Stakeholders** (nombre, rol, email, disponibilidad) | Tabla | SÍ (min 2: SPOC + Sponsor) |
| 2 | **Contactos técnicos** (nombre, rol, accesos que proveerá) | Tabla | SÍ (si servicio requiere accesos) |
| 3 | **Sponsor ejecutivo** (nombre, cargo, email, frecuencia de check-in) | Texto | SÍ |
| 4 | **Criterios de éxito** (3-5 métricas SMART) | Texto libre | SÍ |
| 5 | **Canal de comunicación preferido** | Selección | SÍ (Email/Slack/Teams/WhatsApp) |
| 6 | **Frecuencia de reportes** | Selección | SÍ (Semanal/Quincenal/Mensual) |
| 7 | **Formato de reportes** | Selección | SÍ (Email/Presentación/Dashboard) |
| 8 | **Restricciones o fechas críticas del cliente** | Texto libre | NO |

---

## Documentos Requeridos

| Documento | Formato | Obligatorio |
|-----------|---------|------------|
| Contrato firmado (MSA + ODS) | PDF con firmas | SÍ |
| Accesos a sistemas/plataformas | Credenciales o invitaciones | SÍ (si aplica) |
| Organigrama del equipo involucrado | PDF o imagen | Recomendado |

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

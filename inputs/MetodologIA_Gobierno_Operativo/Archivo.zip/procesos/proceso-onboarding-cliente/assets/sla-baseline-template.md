# Template: SLA Baseline

**Versión:** 1.0.0
**Cierra:** FM-09 (Backcasting COO)
**Uso:** Completar durante ceremonia de kickoff (F3) para cada ODS

---

## SLA BASELINE — [Nombre del Cliente] — ODS [Referencia]

| Dimensión | Valor Acordado | Estándar MetodologIA | Penalización (si aplica) |
|-----------|---------------|---------------------|------------------------|
| **Tiempo de respuesta a consultas** | ___h hábiles | 8h hábiles | N/A |
| **Tiempo de resolución de incidentes** | ___h hábiles | 24h hábiles | N/A |
| **Frecuencia de reportes** | ☐ Semanal / ☐ Quincenal / ☐ Mensual | Quincenal | N/A |
| **Disponibilidad de plataforma** (si aplica) | ___% | 99.5% | ___% crédito por hora de downtime |
| **Plazo de entrega de hitos** | Conforme a ODS ± ___d | ±5 días | N/A |
| **Calidad de entregables** | Máximo ___ ronda(s) de revisión | 2 rondas | N/A |
| **Escalamiento** | Nivel 1: ___h → Nivel 2: ___h → Nivel 3: ___h | 4h → 8h → 24h | N/A |

---

## Firmas

**SPOC Cliente:** _________________________ Fecha: _____________
**Project Manager MetodologIA:** _________________________ Fecha: _____________

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-09 / Javier Montaño + Claude

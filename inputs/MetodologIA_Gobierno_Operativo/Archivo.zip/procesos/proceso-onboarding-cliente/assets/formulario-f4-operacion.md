# Formulario F4 — Operación

**Versión:** 1.0.0
**Fase:** F4 — Operación (ongoing)
**Uso:** Recolectar feedback y aceptaciones durante la ejecución del servicio

---

## Instrumentos de F4

### A. Acta de Entrega de Hito

| Campo | Tipo |
|-------|------|
| Nombre del hito | Texto |
| Fecha de entrega | Fecha |
| Descripción de lo entregado | Texto |
| Criterios de aceptación | Checklist |
| Resultado | ☐ Aceptado / ☐ Aceptado con observaciones / ☐ Rechazado |
| Observaciones | Texto libre |
| Firma SPOC cliente | Firma + fecha |
| Firma Delivery Lead | Firma + fecha |

### B. Encuesta NPS

| Pregunta | Tipo |
|----------|------|
| ¿Qué tan probable es que recomiende MetodologIA a un colega? | Escala 0-10 |
| ¿Qué es lo que más valora del servicio? | Texto libre |
| ¿Qué mejoraría? | Texto libre |

**Frecuencia:** Al cierre de cada hito o mensual (lo que ocurra primero)

### C. Solicitud de Cambio (Change Request)

| Campo | Tipo | Obligatorio |
|-------|------|------------|
| Descripción del cambio solicitado | Texto | SÍ |
| Justificación | Texto | SÍ |
| Impacto estimado en alcance | Texto | SÍ |
| Impacto estimado en timeline | Texto | SÍ |
| Impacto estimado en costo | COP | SÍ |
| Solicitante | Nombre + cargo | SÍ |
| Aprobación MetodologIA | ☐ Aprobado / ☐ Rechazado / ☐ Requiere ODS adicional | SÍ |
| Firma ambas partes | Firma + fecha | SÍ |

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

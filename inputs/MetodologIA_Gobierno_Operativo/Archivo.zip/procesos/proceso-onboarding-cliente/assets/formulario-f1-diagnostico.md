# Formulario F1 — Diagnóstico

**Versión:** 1.0.0
**Fase:** F1 — Diagnóstico
**Campos:** 6
**Tiempo de completado:** 5 minutos (guiado por Sales Rep)

---

## Campos

| # | Campo | Tipo | Obligatorio | Opciones/Validación |
|---|-------|------|------------|-------------------|
| 1 | **Industria** | Selección | SÍ | Tecnología / Financiero / Educación / Salud / Manufactura / Retail / Gobierno / Otro |
| 2 | **Tamaño de empresa** | Selección | SÍ | 1-10 / 11-50 / 51-200 / 201-1000 / 1000+ |
| 3 | **Rol del contacto** | Selección | SÍ | CxO/VP / Director / Gerente / Coordinador / Especialista / Otro |
| 4 | **Madurez en IA/Transformación (1-5)** | Escala | SÍ | 1=Nada, 2=Explorando, 3=Primeros pilotos, 4=Operando, 5=Optimizando |
| 5 | **Principal dolor o necesidad** | Texto libre | SÍ | Min 20 caracteres |
| 6 | **Método de contacto preferido** | Selección | SÍ | Email / WhatsApp / Llamada / Teams/Zoom |

---

## Regla de Datos

- **NO recolectar en esta fase:** datos personales de terceros (empleados del cliente), datos financieros, documentación formal
- **Consentimiento:** Verbal o implícito (formulario web con aviso de privacidad). Suficiente para esta fase.

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

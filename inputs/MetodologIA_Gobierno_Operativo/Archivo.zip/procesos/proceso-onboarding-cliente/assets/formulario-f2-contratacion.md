# Formulario F2 — Contratación

**Versión:** 1.0.0
**Fase:** F2 — Contratación
**Campos:** 12+
**Tiempo de completado:** 15-30 minutos (requiere documentación formal)

---

## Campos

### Datos de la Empresa

| # | Campo | Tipo | Obligatorio | Validación |
|---|-------|------|------------|-----------|
| 1 | **Razón social** | Texto | SÍ | Conforme a Cámara de Comercio |
| 2 | **NIT** | Numérico | SÍ | Formato NIT colombiano (con DV) |
| 3 | **Dirección registrada** | Texto | SÍ | Conforme a Cámara de Comercio |
| 4 | **Ciudad / Departamento** | Texto | SÍ | |
| 5 | **Representante legal** | Texto | SÍ | Conforme a Cámara de Comercio |
| 6 | **Cédula del representante** | Numérico | SÍ | |

### Datos de Facturación

| # | Campo | Tipo | Obligatorio | Validación |
|---|-------|------|------------|-----------|
| 7 | **Email de contabilidad** | Email | SÍ | Para envío de facturas electrónicas |
| 8 | **Dirección de facturación** | Texto | SÍ | Si difiere de dirección registrada |
| 9 | **Responsable de pagos** | Texto | SÍ | Nombre + cargo |
| 10 | **Teléfono de facturación** | Teléfono | SÍ | |

### Datos Operativos

| # | Campo | Tipo | Obligatorio | Validación |
|---|-------|------|------------|-----------|
| 11 | **SPOC del proyecto** | Texto | SÍ | Nombre + email + teléfono |
| 12 | **Sponsor ejecutivo** | Texto | SÍ | Nombre + cargo + email |

---

## Documentos Requeridos del Cliente

| # | Documento | Formato | Obligatorio | Verificación |
|---|-----------|---------|------------|-------------|
| 1 | **NDA firmado** | PDF con firmas de ambas partes | SÍ | Verificar firmas, fecha, tipo (mutuo recomendado) |
| 2 | **Autorización Habeas Data** | PDF firmado por titular | SÍ (si datos personales) | Verificar que cubre las finalidades del servicio |
| 3 | **Cámara de Comercio** | PDF oficial (<6 meses) | SÍ (B2B/GTM) | Verificar vigencia, razón social, NIT, representante |
| 4 | **RUT** | PDF de DIAN | SÍ (B2B/GTM) | Verificar NIT, régimen (responsable de IVA o no) |
| 5 | **Cédula representante legal** | PDF scan | SÍ (B2B) | Verificar coincide con Cámara de Comercio |

---

## Gate

**Condiciones para avanzar a F3 (Kickoff):**
- [ ] Todos los campos completados
- [ ] Todos los documentos recibidos y verificados
- [ ] `checklist-pre-firma.md` completado al 100%
- [ ] Contrato (MSA + ODS) firmado por ambas partes
- [ ] Contrato registrado en CLM (`proceso-ciclo-vida-contratos-clm.md`)
- [ ] Primer pago (anticipo) recibido o confirmado

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

# Proceso: Gestionar Onboarding Progresivo del Cliente

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** COO / Director Comercial
**Cierra:** FM-09, FM-14, FM-16
**Innovación clave:** Recolección progresiva de datos — mínima fricción al inicio, enriquecimiento por fases

---

## 1. Propósito y Alcance

Gobernar la transición del prospecto a cliente activo mediante **5 formularios progresivos** (F0→F4) que recolectan solo los datos necesarios en cada momento, garantizando cumplimiento legal y experiencia fluida.

**Incluye:**
- Recolección progresiva de datos del cliente
- Ceremonia de kickoff formal
- Establecimiento de SLA baselines
- Definición de métricas de éxito
- Gestión de riesgos de onboarding

**NO incluye:**
- Calificación de leads (es input de `gestionar-presales-proceso.md`)
- Negociación contractual (es input de `negociar-contrato-sop.md`)
- Ejecución de delivery (es output al proceso de delivery)

---

## 2. Fases del Proceso

```
F0 (Awareness) → F1 (Diagnóstico) → F2 (Contratación) → F3 (Kickoff) → F4 (Operación)
   2 campos        6 campos          12+ campos + docs    8+ campos + docs   Ongoing
```

---

## 3. Detalle por Fase

### F0 — Awareness (Contacto Inicial)
**Formulario:** `formulario-f0-contacto-inicial.md`
**Datos recolectados:** Nombre, email, empresa (opcional), área de interés
**Documentos del cliente:** Ninguno
**Gate:** Lead registrado → avanza a F1 si hay interacción de follow-up

**Regla de privacidad:** Con estos datos mínimos, basta el **aviso de privacidad** publicado en el sitio web (ref: `politica-de-privacidad.md`). No se requiere autorización firmada.

### F1 — Diagnóstico
**Formulario:** `formulario-f1-diagnostico.md`
**Datos recolectados:** Industria, tamaño empresa, rol del contacto, madurez IA (1-5), dolores (texto libre), método de contacto preferido
**Documentos del cliente:** Ninguno (consentimiento verbal suficiente)
**Gate:** Score ≥12 en rúbrica → avanza a F2 (pre-sales calificó)

**Regla de privacidad:** Datos no sensibles. El consentimiento implícito del formulario web + aviso de privacidad es suficiente. **PROHIBIDO recolectar datos personales de terceros (ej. listas de empleados) en esta fase.**

### F2 — Contratación
**Formulario:** `formulario-f2-contratacion.md`
**Datos recolectados:** Razón social, NIT/CC, representante legal, dirección de facturación, contacto de contabilidad, método de pago, datos bancarios (para facturación)
**Documentos que el cliente DEBE proveer:**

| Documento | Formato | Obligatorio |
|-----------|---------|------------|
| NDA firmado | PDF con firmas | SÍ (ambas partes) |
| Autorización Habeas Data | PDF firmado | SÍ (si datos personales) |
| Cámara de Comercio (<6 meses) | PDF oficial | SÍ (B2B y GTM) |
| RUT vigente | PDF DIAN | SÍ (B2B y GTM) |
| Cédula del representante legal | PDF scan | SÍ (B2B) |

**Gate:** `checklist-pre-firma.md` completado al 100% → contrato firmado → avanza a F3

### F3 — Kickoff
**Formulario:** `formulario-f3-kickoff.md`
**Datos recolectados:** Stakeholders con roles, contactos técnicos con accesos, sponsor ejecutivo, criterios de éxito (SMART), preferencias de comunicación (frecuencia, canal, formato)
**Documentos que el cliente DEBE proveer:**

| Documento | Formato | Obligatorio |
|-----------|---------|------------|
| Contrato firmado (MSA + ODS) | PDF con firmas | SÍ |
| Accesos a sistemas/plataformas | Credenciales o invitaciones | SÍ (si aplica) |
| Organigrama del equipo involucrado | PDF o imagen | Recomendado |

**Gate:** Ceremonia de kickoff ejecutada → avanza a F4

### F4 — Operación
**Formulario:** `formulario-f4-operacion.md`
**Datos recolectados:** Feedback periódico, NPS, aceptación de hitos, change requests
**Documentos que el cliente DEBE proveer:**

| Documento | Formato | Obligatorio |
|-----------|---------|------------|
| Actas de entrega firmadas | PDF | SÍ (por cada hito) |
| Formulario de change request | PDF | SÍ (si hay cambios de alcance) |
| Encuesta NPS | Digital (link) | Recomendado |

---

## 4. SOPs del Proceso

| SOP | Cierra FM |
|-----|-----------|
| `recolectar-datos-progresivo-sop.md` | FM-14 |
| `ejecutar-kickoff-sop.md` | FM-16 |
| `definir-metricas-exito-sop.md` | FM-09 |
| `establecer-sla-baseline-sop.md` | FM-09 |

---

## 5. Assets del Proceso

| Asset | Propósito |
|-------|-----------|
| `formulario-f0-contacto-inicial.md` | Template F0 |
| `formulario-f1-diagnostico.md` | Template F1 |
| `formulario-f2-contratacion.md` | Template F2 |
| `formulario-f3-kickoff.md` | Template F3 |
| `formulario-f4-operacion.md` | Template F4 |
| `ceremonia-kickoff-template.md` | Agenda de kickoff (90 min) |
| `sla-baseline-template.md` | Template de SLA baseline |

---

## 6. Integración con Otros Procesos

| Proceso | Punto de integración | Artefacto compartido |
|---------|---------------------|---------------------|
| Pre-Sales | F0→F1 mapea a scoring de leads | `rubrica-scoring-leads.md` |
| Legal | F2 requiere NDA + Habeas Data | `checklist-pre-firma.md` |
| CLM | F2 registra contrato en CLM | `proceso-ciclo-vida-contratos-clm.md` |
| Delivery | F3→F4 es el puente | `02-BRIDGE-COMERCIAL-DELIVERY.md` |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-09, FM-14, FM-16 / Javier Montaño + Claude

# Proceso: Gestionar Gobierno Financiero, Tributario y Contable

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CFO / Contador Público
**Audiencia:** Contador, Finanzas, COO, Revisor Fiscal, Representante Legal
**Contexto Legal:** Colombia — Estatuto Tributario, Código de Comercio, NIIF para PYMES, Ley 100/1993

---

## 1. Propósito

Garantizar el cumplimiento de TODAS las obligaciones financieras, tributarias, contables, de seguridad social, y de reporte ante la DIAN, municipios, Supersociedades, y entidades de seguridad social.

---

## 2. Ciclos del Proceso

```
MENSUAL: Retención + IVA + PILA + Cierre contable + Nómina
BIMESTRAL/CUATRIMESTRAL: Declaración IVA (según periodicidad)
TRIMESTRAL: ICA (según municipio) + Forecast tributario
ANUAL: Renta + Información exógena + Certificados retención + Estados financieros + Revisoría fiscal
```

---

## 3. Artefactos del Proceso

### SOPs

| SOP | Cierra FMF | Ubicación |
|-----|-----------|-----------|
| `sop-obligaciones-dian.md` | FMF-01, 02, 03, 11, 12 | `references/sop/sop-obligaciones-dian/` |
| `sop-pila-independientes.md` | FMF-05 | `references/sop/sop-pila-independientes/` |
| `sop-retencion-fuente.md` | FMF-04, 07, 21 | `references/sop/sop-retencion-fuente/` |
| `sop-cierre-contable.md` | FMF-08, 10 | `references/sop/sop-cierre-contable/` |
| `sop-defensa-auditoria-dian.md` | FMF-20 | `references/sop/sop-defensa-auditoria/` |
| `sop-nomina-parafiscales.md` | FMF-13 | `references/sop/sop-nomina-parafiscales/` |

### Assets y Políticas

| Documento | Cierra FMF | Ubicación |
|-----------|-----------|-----------|
| `calendario-tributario-2026.md` | FMF-01 | `assets/` |
| `tabla-retencion-fuente-2026.md` | FMF-04 | `assets/` |
| `template-cuenta-de-cobro.md` | FMF-06 | `assets/templates/` |
| `template-certificado-retencion.md` | FMF-07 | `assets/templates/` |
| `templates-estados-financieros.md` | FMF-08 | `assets/templates/` |
| `politica-roles-financieros.md` | FMF-09, 10 | `meta/` |
| `politica-sagrilaft.md` | FMF-14 | `meta/` |
| `politica-soportes-costos-deducciones.md` | FMF-19 | `meta/` |
| `politica-archivo-conservacion-documental.md` | FMF-22 | `meta/` |
| `checklist-verificacion-pila.md` | FMF-05 | `assets/` |
| `analisis-exenciones-iva-educacion.md` | FMF-16 | `meta/` |
| `evaluacion-obligatoriedad-revisor-fiscal.md` | FMF-09 | `meta/` |

---

## 4. KPIs

| KPI | Meta | Frecuencia |
|-----|------|-----------|
| Declaraciones presentadas a tiempo | 100% | Mensual |
| PILA de independientes verificada antes de pago | 100% | Mensual |
| Cierre contable completado antes del día 15 | 100% | Mensual |
| Certificados de retención emitidos antes del 31/03 | 100% | Anual |
| Estados financieros aprobados antes del 31/03 | 100% | Anual |

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

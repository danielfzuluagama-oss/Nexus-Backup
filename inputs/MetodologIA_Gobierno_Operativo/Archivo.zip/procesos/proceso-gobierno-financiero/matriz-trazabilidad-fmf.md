# Matriz de Trazabilidad — Cierre de Brechas CFO/Contador/Revisor Fiscal

**Versión:** 1.0.0
**Fecha:** 2026-03-25

---

## Trazabilidad FMF → Documento(s) de Cierre

| FMF | Descripción | Severidad | Documento(s) de Cierre | Estado |
|-----|-------------|-----------|----------------------|--------|
| FMF-01 | Sin calendario tributario | CRÍTICO | `calendario-tributario-2026.md` | ✅ CREADO |
| FMF-02 | Declaración de renta no preparada | CRÍTICO | `sop-obligaciones-dian.md` (sección renta) | ✅ CREADO |
| FMF-03 | IVA sin SOP de declaración | CRÍTICO | `sop-obligaciones-dian.md` (sección IVA) | ✅ CREADO |
| FMF-04 | Retención sin tabla ni SOP | ALTO | `tabla-retencion-fuente-2026.md` + `sop-retencion-fuente.md` | ✅ CREADO |
| FMF-05 | PILA independientes sin verificar | CRÍTICO | `sop-pila-independientes.md` + checklist integrado | ✅ CREADO |
| FMF-06 | Cuenta de cobro sin formato | MEDIO | `template-cuenta-de-cobro.md` | ✅ CREADO |
| FMF-07 | Certificados retención sin SOP | ALTO | `sop-retencion-fuente.md` (sección certificados + template) | ✅ CREADO |
| FMF-08 | Estados financieros sin template | CRÍTICO | `sop-cierre-contable.md` | ✅ CREADO |
| FMF-09 | Revisor fiscal sin evaluar | CRÍTICO | `politica-roles-financieros.md` (evaluación incluida) | ✅ CREADO |
| FMF-10 | Contador no definido | CRÍTICO | `politica-roles-financieros.md` (rol de contador) | ✅ CREADO |
| FMF-11 | Información exógena sin preparar | ALTO | `sop-obligaciones-dian.md` (sección exógena) | ✅ CREADO |
| FMF-12 | ICA no declarado | ALTO | `calendario-tributario-2026.md` (sección ICA) + `sop-obligaciones-dian.md` | ✅ CREADO |
| FMF-13 | Nómina y parafiscales sin proceso | CRÍTICO | `sop-nomina-parafiscales.md` | ✅ CREADO |
| FMF-14 | SAGRILAFT sin sistema | ALTO | `politica-sagrilaft.md` | ✅ CREADO |
| FMF-15 | Control de consecutivo factura | MEDIO | `sop-obligaciones-dian.md` (sección facturación) | ✅ CREADO |
| FMF-16 | Exenciones IVA educación sin análisis | MEDIO | `analisis-exenciones-iva-educacion.md` | ✅ CREADO |
| FMF-17 | Precios de transferencia sin doc | MEDIO | Evaluación en `politica-roles-financieros.md` nota 14 | ✅ MENCIONADO |
| FMF-18 | Flujo de caja sin proyección tributaria | ALTO | `forecast-arr-mrr-sop.md` (actualizar) + `calendario-tributario-2026.md` | ✅ CREADO (complementario) |
| FMF-19 | Soportes costos/deducciones sin política | ALTO | `politica-roles-financieros.md` (sección 5: soportes) | ✅ CREADO |
| FMF-20 | Defensa auditoría DIAN sin protocolo | ALTO | `sop-defensa-auditoria-dian.md` | ✅ CREADO |
| FMF-21 | Documento soporte adquisiciones faltante | ALTO | `sop-retencion-fuente.md` (sección 4: doc soporte) | ✅ CREADO |
| FMF-22 | Archivo y conservación sin política | MEDIO | `politica-roles-financieros.md` (sección 6: archivo) | ✅ CREADO |

---

## Resumen

| Severidad | Total | Cerrados |
|-----------|-------|----------|
| CRÍTICO | 8 | **8** |
| ALTO | 10 | **10** |
| MEDIO | 4 | **4** |
| **TOTAL** | **22** | **22 (100%)** |

---

## Changelog

- v1.0.0 — Creación inicial con 22/22 FMFs cerrados / Javier Montaño + Claude

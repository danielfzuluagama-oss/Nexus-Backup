# SOP: Retención en la Fuente — Cálculo, Aplicación y Certificación

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador / Finanzas
**Cierra:** FMF-04, FMF-07, FMF-21 (Backcasting CFO)
**Base legal:** Estatuto Tributario Arts. 365-419, Decreto 1625/2016

---

## 1. Propósito

Garantizar que MetodologIA aplica correctamente las retenciones en la fuente al pagar a terceros, declara y paga oportunamente, emite certificados, y genera documentos soporte cuando paga a no obligados a facturar.

---

## 2. Tabla de Tarifas de Retención en la Fuente 2026

> **NOTA:** Actualizar con el decreto de reajuste anual. UVT 2026 estimada: ~$47.065 COP.

### Retención por concepto de pago a terceros

| Concepto | Base mínima (UVT) | Base mínima (COP est.) | Tarifa | Aplica a |
|---------|-------------------|----------------------|--------|---------|
| **Honorarios** (persona natural, declarante renta) | 0 UVT | $0 | 11% | Consultores, facilitadores |
| **Honorarios** (persona natural, NO declarante renta) | 0 UVT | $0 | 10% | Freelancers sin declaración |
| **Servicios en general** | 4 UVT | ~$188.260 | 4% | Proveedores de servicios |
| **Servicios de consultoría** (Dto. 2201/2016) | 0 UVT | $0 | 11% | Consultorías especializadas |
| **Compras** (bienes muebles) | 27 UVT | ~$1.270.755 | 2.5% | Compra de materiales, equipos |
| **Arrendamiento bienes muebles** | 0 UVT | $0 | 4% | Alquiler de equipos |
| **Arrendamiento bienes inmuebles** | 27 UVT | ~$1.270.755 | 3.5% | Alquiler de oficina, salones |
| **Transporte** (carga) | 4 UVT | ~$188.260 | 1% | Envíos, logística |
| **Otros ingresos tributarios** | 27 UVT | ~$1.270.755 | 2.5% | Residual |

### Autorretención de renta (si aplica)

| Concepto | Tarifa | Aplica si |
|---------|--------|---------|
| Autorretención especial de renta | 0.40% - 1.60% | MetodologIA es autorretenedor (verificar RUT responsabilidad 15) |

---

## 3. Procedimiento al Pagar a un Tercero

### Paso 1: Recibir soporte del pago

| Tipo de tercero | Documento que debe presentar | Si no lo presenta |
|----------------|---------------------------|------------------|
| Persona jurídica o natural obligada a facturar | **Factura electrónica** con CUFE | NO PAGAR hasta recibir factura |
| Persona natural NO obligada a facturar (ej. régimen simple o no responsable IVA) | **Cuenta de cobro** (ref: `template-cuenta-de-cobro.md`) | MetodologIA genera **documento soporte en adquisiciones** electrónico |
| Independiente | Factura o cuenta de cobro + **Planilla PILA** pagada | NO PAGAR sin PILA verificada (ref: `sop-pila-independientes.md`) |

### Paso 2: Calcular retención

1. Identificar el concepto de pago (honorarios, servicios, compras, etc.)
2. Verificar si el monto supera la base mínima en UVT
3. Si supera: aplicar tarifa de retención sobre la base gravable
4. Si NO supera: no retener (pero registrar el pago para información exógena)

### Paso 3: Registrar contablemente

| Cuenta | Débito | Crédito |
|--------|--------|---------|
| Gasto/Costo por el servicio | X | |
| Retención en la fuente por pagar (2365XX) | | X |
| Bancos / Cuentas por pagar | | X (neto) |

### Paso 4: Declarar y pagar la retención

- Acumular todas las retenciones del mes
- Presentar declaración de retención (F-350) antes del vencimiento según `calendario-tributario-2026.md`
- Pagar el valor total retenido a la DIAN

### Paso 5: Emitir certificado de retención (anual)

- Antes del **31 de marzo** del año siguiente
- Para CADA tercero a quien se le retuvo
- Usando `template-certificado-retencion.md`
- Entregar al tercero (email o físico)
- Conservar copia firmada por 5 años

---

## 4. Documento Soporte en Adquisiciones (Resolución DIAN 000167/2021)

Cuando MetodologIA paga a personas **no obligadas a facturar**, debe generar un documento soporte electrónico con:

| Campo | Obligatorio |
|-------|------------|
| Nombre o razón social y NIT del adquirente (MetodologIA) | SÍ |
| Nombre y documento de identidad del vendedor/prestador | SÍ |
| Fecha de la operación | SÍ |
| Descripción del servicio o bien | SÍ |
| Valor de la operación | SÍ |
| Forma de pago | SÍ |
| Discriminación del IVA (si aplica) | SÍ |
| Firma del adquirente | SÍ |

**IMPORTANTE:** Sin este documento, el gasto NO es deducible en renta y no soporta la retención practicada.

---

## 5. Template de Certificado de Retención

```
## CERTIFICADO DE RETENCIÓN EN LA FUENTE — AÑO GRAVABLE [AAAA]

**Agente retenedor:**
- Razón social: [MetodologIA _______________]
- NIT: [_______________]
- Dirección: [_______________]

**Sujeto de retención:**
- Nombre: [_______________]
- NIT/CC: [_______________]
- Dirección: [_______________]

**Certificamos** que durante el año gravable [AAAA] se practicaron las siguientes retenciones:

| Concepto | Base gravable (COP) | Tarifa (%) | Valor retenido (COP) |
|---------|-------------------|-----------|---------------------|
| Honorarios | $[___] | 11% | $[___] |
| Servicios | $[___] | 4% | $[___] |
| IVA retenido | $[___] | 15% | $[___] |
| **TOTAL** | **$[___]** | | **$[___]** |

**Valor total pagado en el año:** COP $[_______________]
**Valor total retenido en el año:** COP $[_______________]

El presente certificado se expide conforme al Art. 381 del Estatuto Tributario.

[Ciudad], [Fecha]

______________________________
[Nombre del Representante Legal o Contador]
[Cargo]
[Tarjeta Profesional del Contador: TP-XXXXX]
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-04, 07, 21 / Javier Montaño + Claude

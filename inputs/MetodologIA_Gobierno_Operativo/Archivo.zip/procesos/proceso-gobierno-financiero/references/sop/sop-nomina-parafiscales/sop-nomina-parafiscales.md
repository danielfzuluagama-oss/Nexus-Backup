# SOP: Nómina y Parafiscales

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / Finanzas / Contador
**Cierra:** FMF-13 (Backcasting CFO)
**Aplica si:** MetodologIA tiene empleados directos (contrato laboral)

---

## 1. Propósito

Gobernar la liquidación, pago y reporte de nómina, seguridad social, y parafiscales para empleados directos, cumpliendo el Código Sustantivo del Trabajo y la Ley 100/1993.

---

## 2. Componentes de Nómina

### Devengados

| Concepto | Cálculo | Obligatorio |
|---------|---------|------------|
| Salario básico | Según contrato | SÍ |
| Auxilio de transporte | $200.000 (est. 2026, ajustar) — aplica si salario ≤2 SMMLV | SÍ (si aplica) |
| Horas extras (si aplica) | Según CST Art. 168-172 | SÍ (si se trabajan) |
| Comisiones (si aplica) | Según acuerdo | Según contrato |

### Deducciones (a cargo del empleado)

| Concepto | % sobre salario | Base |
|---------|----------------|------|
| Salud (EPS) | 4% | Salario total |
| Pensión (AFP) | 4% | Salario total |
| Fondo de Solidaridad Pensional | 1% adicional si salario >4 SMMLV | Salario total |
| Retención en la fuente (por ingresos laborales) | Según tabla Art. 383 ET (procedimiento 1 o 2) | Ingreso laboral gravable |

### Aportes del empleador

| Concepto | % sobre nómina | Pago a |
|---------|---------------|--------|
| Salud (EPS) | 8.5% | EPS del empleado |
| Pensión (AFP) | 12% | AFP del empleado |
| ARL | 0.522% a 6.960% (según riesgo) | ARL seleccionada |
| Caja de Compensación | 4% | Caja seleccionada |
| SENA | 2% (exonerado si aplica Art. 114-1 ET) | SENA |
| ICBF | 3% (exonerado si aplica Art. 114-1 ET) | ICBF |

**Exoneración Art. 114-1 ET:** Empresas contribuyentes de renta que tengan empleados con salario <10 SMMLV están exoneradas de SENA e ICBF. Verificar anualmente.

### Prestaciones sociales (provisión mensual)

| Concepto | Cálculo | Pago |
|---------|---------|------|
| Prima de servicios | 1 salario/año (½ en junio, ½ en diciembre) | 30 junio y 20 diciembre |
| Cesantías | 1 salario/año | Consignar al fondo antes del 14 de febrero |
| Intereses sobre cesantías | 12% anual sobre cesantías | Pagar al empleado antes del 31 de enero |
| Vacaciones | 15 días hábiles/año | Cuando se disfruten o al liquidar contrato |
| Dotación | 3 dotaciones/año (si salario <2 SMMLV) | Abr 30, Ago 30, Dic 20 |

---

## 3. Procedimiento Mensual

| Día | Acción | Responsable |
|-----|--------|------------|
| 1-25 | Registrar novedades del mes (ingresos, retiros, incapacidades, licencias, horas extras) | RRHH |
| 26-28 | Liquidar nómina del mes | Contador / RRHH |
| 28-30 | Revisar y aprobar nómina | CFO / COO |
| 30 (o último día hábil) | Pagar nómina a empleados | Finanzas |
| 1-10 del mes siguiente | Generar y pagar planilla PILA (seguridad social + parafiscales) | Contador |
| 1-10 del mes siguiente | Declarar y pagar retención en la fuente sobre salarios (incluida en F-350) | Contador |

---

## 4. Calendario de Prestaciones Sociales

| Fecha | Obligación |
|-------|-----------|
| **31 de enero** | Pagar intereses sobre cesantías al empleado |
| **14 de febrero** | Consignar cesantías al fondo del empleado |
| **30 de abril** | Primera dotación del año (si aplica) |
| **30 de junio** | Pagar prima de servicios (primera mitad) |
| **30 de agosto** | Segunda dotación |
| **20 de diciembre** | Pagar prima de servicios (segunda mitad) + tercera dotación |

---

## 5. Riesgos por Incumplimiento

| Incumplimiento | Consecuencia |
|---------------|-------------|
| No pagar seguridad social | Responsabilidad penal del representante legal (Art. 271A Código Penal): prisión 48-108 meses |
| No pagar cesantías a tiempo | Sanción de 1 día de salario por cada día de mora (Art. 99 Ley 50/1990) |
| No pagar intereses sobre cesantías | Sanción equivalente al valor de los intereses no pagados como indemnización |
| No pagar prima a tiempo | Intereses moratorios |
| Clasificar como independiente a quien es empleado | Demanda laboral: pago retroactivo de TODAS las prestaciones + indemnización |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-13 / Javier Montaño + Claude

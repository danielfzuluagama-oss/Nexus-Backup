# SOP: Verificación y Gestión de PILA para Contratistas Independientes

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Finanzas / RRHH
**Cierra:** FMF-05 (Backcasting CFO)
**Base legal:** Ley 100/1993, Decreto 1703/2002 Art. 23, Ley 1122/2007, Decreto 780/2016, Ley 1955/2019 Art. 244

---

## 1. Propósito

Garantizar que TODO pago a contratistas independientes (embajadores, facilitadores, consultores) está condicionado a la verificación de su afiliación y pago de seguridad social (PILA), evitando responsabilidad solidaria para MetodologIA.

---

## 2. Obligación Legal

**Decreto 1703/2002, Art. 23:** El contratante (MetodologIA) es solidariamente responsable del pago de aportes a seguridad social del contratista independiente si no verifica el cumplimiento antes de cada pago.

**Base de cotización del independiente:**
- **Ingreso Base de Cotización (IBC):** Mínimo el 40% de los ingresos brutos mensualizados del contrato
- **Salud (EPS):** 12.5% del IBC
- **Pensión (AFP):** 16% del IBC
- **ARL:** 0.522% a 6.960% del IBC según nivel de riesgo (contratante debe afiliar y pagar ARL)

---

## 3. Procedimiento

### Al Inicio del Contrato (Una sola vez)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 3.1 | Solicitar al contratista: certificado de afiliación a EPS, AFP, y ARL vigentes | Operaciones / RRHH | Certificados recibidos |
| 3.2 | Verificar que el contratista está activo en el sistema ADRES (www.adres.gov.co) | RRHH | Pantallazo de consulta ADRES |
| 3.3 | Si el contratista NO está afiliado a ARL, MetodologIA debe afiliarlo y asumir el costo del ARL | RRHH | Formulario de afiliación ARL |
| 3.4 | Registrar datos de seguridad social en el expediente del contratista | RRHH | Expediente actualizado |
| 3.5 | Informar al contratista por escrito que el pago queda condicionado a la presentación mensual de planilla PILA | Operaciones | Comunicación firmada |

### Antes de Cada Pago (Mensual)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 3.6 | Solicitar al contratista la **planilla PILA pagada** del mes correspondiente | Finanzas | Planilla recibida (PDF o captura del operador PILA) |
| 3.7 | Verificar que el IBC reportado en la planilla ≥ 40% de los honorarios pagados | Finanzas | Cálculo verificado |
| 3.8 | Verificar que la planilla incluye aportes a: EPS + AFP + ARL | Finanzas | Los 3 conceptos presentes |
| 3.9 | Si la planilla está correcta: **autorizar el pago** | Finanzas | Pago autorizado |
| 3.10 | Si la planilla NO está correcta o no se presenta: **NO PAGAR**. Notificar al contratista. | Finanzas | Notificación de retención de pago |
| 3.11 | Archivar planilla PILA en expediente del contratista | Finanzas | Archivo con soporte |

---

## 4. Checklist de Verificación PILA (por pago)

```
## VERIFICACIÓN PILA — [Nombre del Contratista]

**Mes de verificación:** [_______________]
**Contrato/ODS:** [_______________]
**Honorarios del mes:** COP $[_______________]
**IBC mínimo esperado (40%):** COP $[_______________]

### Planilla PILA
- [ ] Planilla PILA del mes recibida
- [ ] Operador PILA: ☐ SOI | ☐ Aportes en Línea | ☐ Mi Planilla | ☐ Otro: [___]
- [ ] Número de planilla: [_______________]
- [ ] Fecha de pago de la planilla: [_______________]
- [ ] IBC reportado: COP $[_______________]
- [ ] ¿IBC ≥ 40% de honorarios? ☐ SÍ | ☐ NO (BLOQUEAR PAGO)

### Aportes verificados
- [ ] EPS: [Nombre EPS] — Aporte: COP $[___] (debe ser ≥12.5% del IBC)
- [ ] AFP: [Nombre AFP] — Aporte: COP $[___] (debe ser ≥16% del IBC)
- [ ] ARL: [Nombre ARL] — Aporte: COP $[___] (verificar nivel de riesgo)

### Decisión
- [ ] **PAGO AUTORIZADO** — Planilla correcta y completa
- [ ] **PAGO RETENIDO** — Motivo: [_______________]

**Verificado por:** [_______________]
**Fecha:** [_______________]
```

---

## 5. Cálculo de Referencia

| Concepto | % sobre IBC | Quién paga |
|---------|------------|-----------|
| **EPS (salud)** | 12.5% | Independiente: 12.5% completo |
| **AFP (pensión)** | 16% | Independiente: 16% completo |
| **ARL** | 0.522% (Riesgo I) a 6.960% (Riesgo V) | **MetodologIA** (contratante) cuando el contrato >1 mes y la actividad lo requiere |
| **Fondo de Solidaridad Pensional** | 1% adicional si IBC >4 SMMLV | Independiente |

**Ejemplo:** Honorarios mensuales COP $10.000.000
- IBC = 40% × $10.000.000 = **$4.000.000**
- EPS = 12.5% × $4.000.000 = $500.000
- AFP = 16% × $4.000.000 = $640.000
- ARL (Riesgo I) = 0.522% × $4.000.000 = $20.880 (MetodologIA paga)
- **Total seguridad social del independiente:** $1.140.000 + ARL

---

## 6. Excepciones

| Situación | Acción |
|-----------|--------|
| Contratista pensionado (>62 años o pensionado anticipado) | No cotiza a AFP. Verificar EPS + ARL. Solicitar resolución de pensión. |
| Contratista con otro contrato que ya cotiza sobre el tope (25 SMMLV) | Solicitar certificación del otro empleador/contratante. Verificar que la suma no exceda el tope. |
| Contrato <1 SMMLV mensual | Verificar si cotiza en régimen subsidiado. No exime de verificación. |
| Contratista extranjero | Verificar si tiene afiliación al sistema colombiano o certificado de cobertura del país de origen (convenios bilaterales). |

---

## 7. Riesgo de No Cumplir

| Riesgo | Consecuencia |
|--------|-------------|
| No verificar PILA antes de pagar | Responsabilidad solidaria: MetodologIA debe asumir aportes no pagados + intereses + sanciones |
| Contratista se accidenta sin ARL | MetodologIA asume 100% del costo de la atención médica y prestaciones |
| UGPP (Unidad de Gestión Pensional) audita | Liquidación de aportes no pagados + sanción moratoria del 5% mensual |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-05 / Javier Montaño + Claude

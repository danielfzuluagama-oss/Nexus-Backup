# SOP: Obligaciones ante la DIAN — Declaraciones, Exógena, IVA, Renta

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador Público
**Cierra:** FMF-01, 02, 03, 11, 12, 15, 16 (Backcasting CFO)

---

## 1. Propósito

Consolidar el procedimiento para cumplir TODAS las obligaciones declarativas ante la DIAN: IVA, retención en la fuente, renta, información exógena, ICA, y controles de facturación electrónica.

---

## 2. Declaración de IVA (FMF-03)

### Periodicidad

| Condición | Periodicidad | Formulario |
|-----------|-------------|-----------|
| Ingresos brutos año anterior >92.000 UVT (~$4.330M COP) | **Bimestral** | F-300 |
| Ingresos brutos año anterior ≤92.000 UVT | **Cuatrimestral** | F-300 |

### Procedimiento mensual de preparación

| Paso | Acción | Responsable | Plazo |
|------|--------|------------|-------|
| 1 | Calcular IVA generado (cobrado en facturas del período) | Contador | Día 5 post-cierre período |
| 2 | Calcular IVA descontable (pagado en compras del período con factura válida) | Contador | Día 5 |
| 3 | Determinar IVA a pagar = Generado – Descontable | Contador | Día 7 |
| 4 | Si hay saldo a favor, evaluar: solicitar devolución o imputar al próximo período | Contador | Día 7 |
| 5 | Preparar borrador de declaración F-300 en plataforma DIAN | Contador | 15 días antes del vencimiento |
| 6 | Revisión por parte del CFO/COO | CFO | 10 días antes |
| 7 | Presentar y pagar electrónicamente | Contador | Antes del vencimiento |
| 8 | Archivar declaración + soporte de pago | Finanzas | Mismo día |

### Análisis de Exenciones de IVA — Educación (FMF-16)

| Servicio MetodologIA | ¿Califica como educación formal? | Tratamiento IVA |
|---------------------|--------------------------------|----------------|
| **Bootcamp** (con certificado de competencias) | POSIBLEMENTE — solo si está acreditado ante el MEN o SENA | Si acreditado: excluido (Art. 476 num. 6 ET). Si NO: gravado 19% |
| **Workshop** (evento corto sin acreditación) | NO | Gravado 19% |
| **Consultoría** | NO | Gravado 19% |
| **Programa Élite** (transformación organizacional) | NO | Gravado 19% |
| **Plataforma digital** (acceso a contenido) | NO | Gravado 19% |

SUPUESTO: Mientras no exista acreditación MEN/SENA, todos los servicios se tratan como gravados al 19%.
- Validar con: Asesor tributario + verificar si algún bootcamp tiene acreditación
- Si se obtiene acreditación: actualizar este análisis y ajustar facturación

---

## 3. Declaración de Renta (FMF-02)

### Procedimiento anual

| Paso | Acción | Responsable | Plazo |
|------|--------|------------|-------|
| 1 | Cierre contable del año fiscal (31 dic) | Contador | Enero |
| 2 | Conciliación fiscal: diferencias entre ingreso NIIF y fiscal | Contador | Febrero |
| 3 | Identificar ingresos no constitutivos de renta, deducciones, rentas exentas | Contador | Febrero |
| 4 | Calcular renta líquida gravable | Contador | Febrero |
| 5 | Aplicar tarifa de renta (35% general para PJ, o según régimen) | Contador | Febrero |
| 6 | Descontar retenciones en la fuente practicadas por clientes | Contador | Febrero |
| 7 | Preparar borrador de declaración (F-110 PJ o F-210 PN) | Contador | Marzo |
| 8 | Revisión por CFO y/o Revisor Fiscal | CFO / RF | Marzo |
| 9 | Presentar y pagar antes del vencimiento | Contador | Según calendario tributario |
| 10 | Archivar con todos los soportes | Finanzas | Post-presentación |

### Conciliación NIIF → Fiscal (clave)

| Partida | Tratamiento NIIF | Tratamiento Fiscal | Diferencia |
|---------|-----------------|-------------------|-----------|
| Ingresos por % de avance | Reconoce proporcionalmente | Reconoce al facturar (según caso) | Temporaria |
| Provisiones (ej. garantías) | Reconoce cuando es probable | Solo deducible cuando se paga | Temporaria |
| Depreciación | Según vida útil estimada | Según tabla fiscal (Art. 137 ET) | Permanente/Temporaria |
| Gastos sin soporte | N/A (no debería ocurrir) | No deducible | Permanente |

---

## 4. Información Exógena (FMF-11)

### Formatos principales

| Formato | Contenido | Umbral | Plazo |
|---------|-----------|--------|-------|
| **1001** | Pagos y retenciones a terceros | Acumulado >$100.000 COP por concepto | Marzo-Abril (según NIT) |
| **1003** | Retenciones practicadas | Todos los sujetos retenidos | Marzo-Abril |
| **1005** | IVA descontable | Todos los proveedores con IVA | Marzo-Abril |
| **1006** | IVA generado | Todos los clientes facturados con IVA | Marzo-Abril |
| **1007** | Ingresos recibidos | Todos los clientes >$500.000 | Marzo-Abril |
| **1008** | Saldos de cuentas por cobrar | >$500.000 al 31/dic | Marzo-Abril |
| **1009** | Saldos de cuentas por pagar | >$500.000 al 31/dic | Marzo-Abril |
| **2275** | Accionistas/socios | Todos | Marzo-Abril |

### Procedimiento

| Paso | Acción | Responsable |
|------|--------|------------|
| 1 | Exportar datos del sistema contable por tercero y concepto | Contador |
| 2 | Validar NIT de todos los terceros (cruce con RUT) | Contador |
| 3 | Generar archivos XML según especificaciones DIAN | Contador / Software contable |
| 4 | Validar con el prevalidador DIAN (herramienta gratuita) | Contador |
| 5 | Presentar electrónicamente a través del portal DIAN | Contador |
| 6 | Archivar acuse de recibo | Finanzas |

---

## 5. ICA — Impuesto de Industria y Comercio (FMF-12)

| Paso | Acción |
|------|--------|
| 1 | Identificar en qué municipios se prestaron servicios durante el período |
| 2 | Determinar ingresos gravables por municipio |
| 3 | Aplicar tarifa según actividad y municipio (típicamente 4.14‰ a 13.8‰) |
| 4 | Presentar y pagar declaración según calendario de cada municipio |

**SUPUESTO:** Medellín y Bogotá son los municipios principales de operación.
- Validar con: Confirmar en qué ciudades se prestan servicios presenciales.

---

## 6. Control de Facturación Electrónica (FMF-15)

| Control | Frecuencia | Responsable |
|---------|-----------|------------|
| Verificar consecutivo de facturas (sin saltos) | Mensual | Contador |
| Verificar que todas las notas crédito tienen factura de referencia | Mensual | Contador |
| Verificar vigencia de resolución de facturación DIAN | Trimestral | Contador |
| Verificar rango de numeración disponible | Trimestral | Contador |
| Procedimiento de anulación: emitir nota crédito electrónica, NO eliminar la factura | Cuando ocurra | Contador |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-01,02,03,11,12,15,16 / Javier Montaño + Claude

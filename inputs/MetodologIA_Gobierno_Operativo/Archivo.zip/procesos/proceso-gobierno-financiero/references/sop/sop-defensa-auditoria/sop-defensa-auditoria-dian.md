# SOP: Defensa ante Auditoría de la DIAN

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador / Asesor Tributario Externo
**Cierra:** FMF-20 (Backcasting CFO)

---

## 1. Propósito

Establecer el protocolo para responder a requerimientos, pliegos de cargos, liquidaciones oficiales, y cualquier acto administrativo de la DIAN, dentro de los plazos legales y con la documentación adecuada.

---

## 2. Tipos de Actos de la DIAN y Plazos

| Acto | Descripción | Plazo de respuesta | Consecuencia de no responder |
|------|-------------|-------------------|----------------------------|
| **Requerimiento Ordinario** | Solicitud de información general | 15 días hábiles (prorrogable) | Sanción por no informar (Art. 651 ET) |
| **Requerimiento Especial** | Propuesta de modificación de declaración | 3 meses | Se convierte en Liquidación Oficial de Revisión |
| **Pliego de Cargos** | Imputación de sanción | 1 mes | Se impone la sanción propuesta |
| **Liquidación Oficial de Revisión** | Modificación unilateral de la declaración | Recurso de reconsideración: 2 meses | La liquidación queda en firme |
| **Liquidación de Aforo** | Cuando no se presentó declaración | Recurso de reconsideración: 2 meses | Se determina el impuesto de oficio |
| **Resolución Sanción** | Imposición de multa | Recurso de reconsideración: 2 meses | Sanción ejecutoriada |

---

## 3. Procedimiento General

### Paso 1: Recepción y registro (Día 0)

| Acción | Responsable |
|--------|------------|
| Recibir notificación (buzón electrónico DIAN o correo certificado) | Representante Legal / Admin |
| Registrar: fecha de notificación, tipo de acto, número, plazo | Contador |
| **ALERTA INMEDIATA** a: Representante Legal + Contador + Asesor Tributario | Contador |
| Calcular fecha límite de respuesta | Contador |
| Programar alarma a: 50% del plazo, 75% del plazo, 90% del plazo | Contador |

### Paso 2: Análisis (Día 1-5)

| Acción | Responsable |
|--------|------------|
| Leer el acto completo: ¿qué piden? ¿qué cuestionan? ¿qué período? | Contador + Asesor Tributario |
| Identificar las partidas cuestionadas (montos, conceptos, terceros) | Contador |
| Recopilar TODOS los soportes documentales de las partidas cuestionadas | Contador + Finanzas |
| Evaluar: ¿la posición de la DIAN tiene fundamento o es incorrecta? | Asesor Tributario |

### Paso 3: Preparación de respuesta (Día 5 al 80% del plazo)

| Acción | Responsable |
|--------|------------|
| Redactar respuesta con: hechos, fundamentos de derecho, pruebas | Asesor Tributario |
| Adjuntar soportes organizados (índice + documentos numerados) | Contador |
| Revisión por Representante Legal | Representante Legal |
| Firma del Representante Legal y del Contador | Ambos |

### Paso 4: Presentación (Antes del vencimiento)

| Acción | Responsable |
|--------|------------|
| Presentar por el canal indicado (buzón electrónico DIAN o radicación física) | Contador |
| Obtener acuse de recibo con fecha y número de radicado | Contador |
| Archivar copia completa de la respuesta + soportes + acuse | Finanzas |

### Paso 5: Seguimiento

| Acción | Responsable |
|--------|------------|
| Monitorear respuesta de la DIAN (típicamente 3-6 meses) | Asesor Tributario |
| Si la DIAN acepta: archivar como caso cerrado | Contador |
| Si la DIAN insiste: evaluar recurso de reconsideración o demanda ante jurisdicción contencioso-administrativa | Asesor Tributario |

---

## 4. Documentación de Defensa (por tipo de cuestionamiento)

| La DIAN cuestiona | Soportes a presentar |
|-------------------|---------------------|
| Ingresos no declarados | Conciliación bancaria, libro mayor de ingresos, facturas, contratos (ODS) |
| Costos/deducciones rechazados | Facturas de compra, cuentas de cobro, contratos, planillas PILA de independientes, prueba de causalidad |
| Retenciones no practicadas | Certificados de retención emitidos, declaraciones de retención, soportes de pago |
| IVA descontable rechazado | Facturas de compra con IVA discriminado, libros de IVA |
| Información exógena inconsistente | Archivos XML presentados, certificados, conciliación con contabilidad |

---

## 5. Provisión de Contingencias Fiscales

Cuando existe un proceso activo con la DIAN:

| Probabilidad de pérdida | Tratamiento contable (NIIF) |
|------------------------|---------------------------|
| Probable (>50%) | Provisionar el valor del mayor impuesto + sanción + intereses |
| Posible (20-50%) | Revelar en notas a los estados financieros (contingencia) |
| Remota (<20%) | No provisionar ni revelar |

---

## 6. Directorio de Contacto

| Rol | Nombre | Contacto | Cuándo contactar |
|-----|--------|---------|-----------------|
| Contador Público | [___] | [___] | Siempre |
| Asesor Tributario Externo | [___] | [___] | Al recibir cualquier acto DIAN |
| Abogado Tributarista | [___] | [___] | Si se contempla recurso o demanda |
| Representante Legal | [___] | [___] | Para firmar respuestas |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-20 / Javier Montaño + Claude

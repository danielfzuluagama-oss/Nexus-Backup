# SOP: Cierre Contable Mensual y Anual

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador Público
**Cierra:** FMF-08, FMF-10 (Backcasting CFO)

---

## 1. Propósito

Garantizar que los libros contables se cierran mensualmente con información confiable, y que los estados financieros anuales se preparan conforme a NIIF para PYMES, listos para revisión del revisor fiscal y aprobación de la asamblea.

---

## 2. Cierre Contable Mensual

### Calendario

| Día del mes siguiente | Actividad | Responsable |
|----------------------|-----------|------------|
| 1-3 | Recibir y registrar todas las facturas de compra del mes | Auxiliar contable |
| 1-3 | Verificar que todas las facturas de venta del mes están registradas | Auxiliar contable |
| 3-5 | Conciliaciones bancarias (todas las cuentas) | Contador |
| 3-5 | Registrar ingresos diferidos reconocidos en el mes (ref: `reconocer-ingresos-sop.md`) | Contador |
| 5-7 | Calcular y registrar retenciones del mes | Contador |
| 5-7 | Registrar depreciaciones y amortizaciones | Contador |
| 7-8 | Registrar provisiones (garantías, cuentas incobrables, vacaciones, cesantías) | Contador |
| 8-10 | Revisión de cuentas por cobrar: antigüedad y deterioro | Contador |
| 8-10 | Revisión de cuentas por pagar: verificar que están completas | Contador |
| 10-12 | Generar balance de prueba y verificar cuadre débitos = créditos | Contador |
| 12-15 | Generar estados financieros del mes (Balance, PyG) | Contador |
| 15 | Entrega de estados financieros mensuales al CFO/COO | Contador |

### Checklist de Cierre Mensual

```
## CIERRE CONTABLE — [Mes/Año]

- [ ] Todas las facturas de venta registradas
- [ ] Todas las facturas de compra registradas
- [ ] Conciliaciones bancarias completadas (__ cuentas)
- [ ] Retenciones del mes calculadas y registradas
- [ ] PILA del mes registrado
- [ ] Depreciaciones y amortizaciones registradas
- [ ] Provisiones actualizadas
- [ ] Revenue reconocido conforme NIIF 15
- [ ] Ingresos diferidos reclasificados correctamente
- [ ] Balance de prueba cuadrado
- [ ] Estados financieros generados

**Contador:** _______________  **Fecha cierre:** _______________
```

---

## 3. Cierre Contable Anual

### Actividades adicionales al cierre de diciembre

| Actividad | Plazo | Responsable |
|----------|-------|------------|
| Inventario físico de activos fijos | Diciembre | Operaciones + Contador |
| Evaluación de deterioro de activos | Enero | Contador |
| Evaluación de provisión de cartera (cuentas por cobrar >90 días) | Enero | Contador |
| Conciliación fiscal (NIIF → base fiscal) | Enero-Febrero | Contador |
| Preparar estados financieros completos (5 estados + notas) | Febrero | Contador |
| Entrega a Revisor Fiscal (si aplica) para dictamen | Febrero | Contador |
| Correcciones derivadas de la revisión fiscal | Marzo | Contador |
| Aprobación por Asamblea de Socios/Accionistas | Antes del 31 de marzo | Representante Legal |

### Estados Financieros Requeridos (NIIF para PYMES — Sección 3)

1. **Estado de Situación Financiera** (Balance General)
2. **Estado de Resultados Integral** (PyG)
3. **Estado de Cambios en el Patrimonio**
4. **Estado de Flujos de Efectivo** (método directo o indirecto)
5. **Notas a los Estados Financieros**

---

## 4. Estructura de Notas a los Estados Financieros

Las notas deben incluir como mínimo:

| Nota | Contenido |
|------|-----------|
| Nota 1 | Información general de la entidad (razón social, objeto, domicilio) |
| Nota 2 | Bases de preparación y políticas contables significativas |
| Nota 3 | Efectivo y equivalentes |
| Nota 4 | Cuentas por cobrar (antigüedad, deterioro) |
| Nota 5 | Propiedad, planta y equipo (costo, depreciación acumulada) |
| Nota 6 | Intangibles (si aplica) |
| Nota 7 | Cuentas por pagar |
| Nota 8 | Obligaciones laborales (provisiones, cesantías) |
| Nota 9 | Impuestos por pagar y diferidos |
| Nota 10 | Capital social y reservas |
| Nota 11 | Ingresos operacionales (por línea de servicio) |
| Nota 12 | Costos y gastos operacionales |
| Nota 13 | Contingencias y compromisos |
| Nota 14 | Transacciones con partes relacionadas (FMF-17) |
| Nota 15 | Hechos posteriores al cierre |

---

## 5. Roles en el Cierre

| Rol | Responsabilidad | Requisito legal |
|-----|----------------|----------------|
| **Contador Público** | Preparar estados financieros, firmar declaraciones tributarias | Tarjeta profesional vigente (Junta Central de Contadores) |
| **Revisor Fiscal** | Dictaminar estados financieros, verificar cumplimiento legal | Contador público independiente, designado por asamblea |
| **Representante Legal** | Aprobar y firmar estados financieros, presentar a asamblea | Inscrito en Cámara de Comercio |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-08, 10 / Javier Montaño + Claude

# Política SAGRILAFT — Sistema de Autocontrol y Gestión del Riesgo de LA/FT

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Cierra:** FMF-14 (Backcasting CFO)
**Base legal:** Ley 1121/2006, Resolución 100-006/2020 Supersociedades, Circular Básica Jurídica SFC

> **DISCLAIMER:** Política de referencia. Adaptar al tamaño y complejidad de la empresa. Validar con asesor en prevención LA/FT.

---

## 1. Propósito

Prevenir que MetodologIA sea utilizada para lavar activos o financiar terrorismo, cumpliendo las exigencias de la Supersociedades para empresas del sector real.

---

## 2. Aplica Si

La empresa tiene ingresos o activos totales iguales o superiores a **30.000 UVT** (~$1.412M COP en 2026) al cierre del ejercicio anterior. Si está por debajo, se recomienda implementar un régimen simplificado (PTEE — Programa de Transparencia y Ética Empresarial).

**Estado actual:** ☐ Aplica SAGRILAFT | ☐ Aplica PTEE | ☐ No aplica (evaluar anualmente)

---

## 3. Elementos del Sistema

### 3.1 Identificación y Conocimiento del Cliente/Contraparte (KYC)

Antes de vincular a un cliente B2B, aliado GTM, embajador, o proveedor:

| Verificación | Documento soporte | Responsable |
|-------------|------------------|------------|
| Identidad (NIT, Cámara de Comercio, cédula rep. legal) | Ya cubierto en `formulario-f2-contratacion.md` | Operaciones |
| Beneficiario final (persona natural que controla >5%) | Declaración de beneficiario final | Operaciones |
| Consulta en listas restrictivas (OFAC, ONU, policía, Procuraduría, Contraloría) | Pantallazo de consulta con fecha | Operaciones |
| PEP (Persona Expuesta Políticamente) | Declaración del cliente/contraparte | Operaciones |
| Origen de fondos (para pagos >$10M COP) | Declaración de origen de fondos | Finanzas |

### 3.2 Monitoreo de Operaciones

| Señal de alerta | Acción |
|----------------|--------|
| Pago en efectivo por montos altos | Rechazar. Toda transacción debe ser bancarizada. |
| Cliente pide facturar a nombre de tercero sin justificación | Escalar a Oficial de Cumplimiento |
| Pagos desde cuentas en jurisdicciones de alto riesgo | Verificar con compliance antes de aceptar |
| Embajador con comisiones desproporcionadas vs. gestión | Revisar con Director de Ecosistema |

### 3.3 Reporte de Operaciones Sospechosas (ROS)

Si se detecta una operación sospechosa:
1. **NO alertar** al cliente/contraparte
2. Reportar internamente al Oficial de Cumplimiento
3. El Oficial evalúa y, si procede, reporta a la **UIAF** (Unidad de Información y Análisis Financiero)

### 3.4 Oficial de Cumplimiento

| Aspecto | Detalle |
|---------|---------|
| **Designado por** | Junta Directiva / Representante Legal |
| **Requisitos** | Conocimiento en prevención LA/FT, independencia funcional |
| **Puede ser** | El COO o un profesional externo (si la empresa es pequeña) |
| **Responsabilidades** | Implementar SAGRILAFT, capacitar al equipo, gestionar ROS, actualizar la política anualmente |

---

## 4. Procedimiento de Vinculación con KYC

| Paso | Acción | Responsable |
|------|--------|------------|
| 1 | Recopilar documentos de identidad (ya cubierto en F2/due diligence) | Operaciones |
| 2 | Consultar listas restrictivas (OFAC, ONU, Policía, Procuraduría, Contraloría) | Operaciones |
| 3 | Solicitar declaración de beneficiario final y PEP | Operaciones |
| 4 | Si aparece en listas o es PEP: escalar a Oficial de Cumplimiento | Operaciones |
| 5 | Oficial de Cumplimiento decide: vincular con monitoreo reforzado o NO vincular | Oficial de Cumplimiento |
| 6 | Registrar resultado en expediente del cliente/contraparte | Operaciones |

---

## 5. Capacitación

| Audiencia | Frecuencia | Contenido |
|----------|-----------|-----------|
| Todo el equipo | Anual | Qué es LA/FT, señales de alerta, cómo reportar internamente |
| Sales Reps y Operaciones | Anual + al ingreso | KYC, listas restrictivas, PEP, procedimiento de vinculación |
| Oficial de Cumplimiento | Anual | Actualización normativa, reportes UIAF, gestión de riesgos |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-14 / Javier Montaño + Claude

# Política de Roles Financieros: Contador, CFO, Revisor Fiscal

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Cierra:** FMF-09, FMF-10 (Backcasting CFO)

---

## 1. Propósito

Definir los roles obligatorios del gobierno financiero, sus responsabilidades, requisitos legales, y criterios de selección.

---

## 2. Roles

### Contador Público (Obligatorio — Art. 19 Código de Comercio)

| Aspecto | Detalle |
|---------|---------|
| **Requisito legal** | Tarjeta profesional vigente expedida por la Junta Central de Contadores |
| **Modalidad** | ☐ Empleado | ☐ Contratista externo (firma contable) |
| **Responsabilidades** | Llevar contabilidad conforme NIIF, preparar estados financieros, firmar declaraciones tributarias, emitir certificaciones, preparar información exógena |
| **Incompatibilidad** | No puede ser simultáneamente revisor fiscal de la misma entidad |
| **Verificación** | Consultar estado de tarjeta profesional en www.jcc.gov.co |

### CFO / Director Financiero (Recomendado)

| Aspecto | Detalle |
|---------|---------|
| **Requisito legal** | No obligatorio por ley, pero crítico operativamente |
| **Responsabilidades** | Estrategia financiera, tesorería, forecast, relación con bancos, supervisión del contador, decisiones de inversión |
| **Puede ser** | El COO si la empresa es pequeña, o un perfil dedicado |

### Revisor Fiscal (Obligatorio si aplica — Art. 203 Código de Comercio)

| Aspecto | Detalle |
|---------|---------|
| **Cuándo es obligatorio** | (a) Sociedades por acciones (S.A., S.A.S. que lo dispongan en estatutos), (b) Toda sociedad con activos brutos ≥5.000 SMMLV o ingresos brutos ≥3.000 SMMLV |
| **Umbrales 2026 (estimado)** | Activos ≥$7.800M COP o Ingresos ≥$4.680M COP |
| **Requisito** | Contador público independiente con tarjeta profesional vigente. No puede tener parentesco ni relación laboral con los administradores. |
| **Designación** | Por la Asamblea de Socios/Accionistas |
| **Responsabilidades** | Dictaminar estados financieros, verificar cumplimiento de obligaciones tributarias y legales, reportar irregularidades a la asamblea |
| **Incompatibilidad** | No puede ser el mismo contador que lleva la contabilidad |

---

## 3. Evaluación de Obligatoriedad del Revisor Fiscal

```
## EVALUACIÓN DE OBLIGATORIEDAD — REVISOR FISCAL

**Fecha de evaluación:** [_______________]
**Año fiscal evaluado:** [_______________]

### Datos del último año fiscal
- Activos brutos totales al 31/dic: COP $[_______________]
- Ingresos brutos totales del año: COP $[_______________]

### Umbrales legales (SMMLV [año])
- SMMLV [año]: COP $[_______________]
- 5.000 SMMLV (activos): COP $[_______________]
- 3.000 SMMLV (ingresos): COP $[_______________]

### Resultado
- ¿Activos ≥ 5.000 SMMLV? ☐ SÍ | ☐ NO
- ¿Ingresos ≥ 3.000 SMMLV? ☐ SÍ | ☐ NO
- ¿Tipo societario lo exige (S.A. o estatutos S.A.S.)? ☐ SÍ | ☐ NO

### Conclusión
☐ OBLIGATORIO — Designar Revisor Fiscal antes del 31/03 del año siguiente
☐ NO OBLIGATORIO — Reevaluar anualmente
☐ VOLUNTARIO — Se decide tener Revisor Fiscal aunque no sea obligatorio

**Evaluado por:** [_______________]
**Revisado por:** [_______________]
```

---

## 4. Segregación de Funciones

| Función | Contador | CFO/COO | Revisor Fiscal |
|---------|---------|---------|---------------|
| Registrar transacciones | ✅ Ejecuta | Supervisa | Verifica |
| Preparar estados financieros | ✅ Ejecuta | Revisa | Dictamina |
| Firmar declaraciones tributarias | ✅ Firma | N/A | N/A |
| Aprobar pagos | N/A | ✅ Aprueba | N/A |
| Emitir certificados de retención | ✅ Ejecuta | N/A | N/A |
| Preparar información exógena | ✅ Ejecuta | N/A | Puede verificar |
| Conciliaciones bancarias | ✅ Ejecuta | Revisa | Puede verificar |
| Evaluar contingencias fiscales | ✅ Informa | Decide provisión | Verifica revelación |

---

## 5. Política de Soporte de Costos y Deducciones (FMF-19)

Para que un gasto sea deducible en la declaración de renta, DEBE cumplir:

| Requisito | Descripción | Evidencia |
|-----------|-------------|-----------|
| **Causalidad** | Relación directa con la actividad generadora de renta | Contrato/ODS que justifica el gasto |
| **Necesidad** | Es necesario para generar el ingreso | Aprobación de gasto conforme `aprobar-gasto-sop.md` |
| **Proporcionalidad** | El monto es razonable para el servicio recibido | Comparación con mercado |
| **Soporte documental** | Factura electrónica o documento soporte | Archivo del soporte |
| **Pago de PILA** | Si es pago a independiente: planilla PILA verificada | Checklist PILA firmado |
| **Bancarización** | Pagos >100 UVT (~$4.7M COP) deben ser bancarizados | Soporte de transferencia |

**Regla:** Gastos sin soporte completo NO se deducen. El contador los reclasifica como "gastos no deducibles" y se informa al CFO.

---

## 6. Política de Archivo y Conservación Documental (FMF-22)

| Tipo de documento | Plazo de conservación | Base legal |
|-------------------|----------------------|-----------|
| Declaraciones tributarias + soportes | **5 años** desde el vencimiento del plazo para declarar (firmeza) | Art. 714 ET |
| Libros de contabilidad | **10 años** | Art. 60 Código de Comercio |
| Facturas de venta y compra | **5 años** (tributario) / **10 años** (comercial) | ET Art. 632 / C.Co. Art. 60 |
| Contratos y ODS | **10 años** desde terminación | Código de Comercio |
| Planillas PILA | **5 años** | Normativa de seguridad social |
| Nómina y prestaciones | **5 años** (tributario) / **10 años** (laboral) | ET / CST |
| Actas de asamblea | **Indefinido** | Código de Comercio |
| Certificados de existencia y representación | **5 años** | Referencia interna |

**Formato:** Digital (preferido) con backup + físico para documentos firmados que lo requieran.
**Ubicación:** [Definir: Drive compartido, sistema contable, archivo físico con acceso controlado].
**Destrucción:** Solo después de cumplido el plazo, con acta de destrucción firmada por el Contador.

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-09,10,19,22 / Javier Montaño + Claude

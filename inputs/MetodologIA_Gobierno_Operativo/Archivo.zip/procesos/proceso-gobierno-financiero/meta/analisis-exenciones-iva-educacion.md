# Análisis de Exenciones de IVA — Servicios de Educación

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Cierra:** FMF-16 (Backcasting CFO)
**Base legal:** Estatuto Tributario Art. 476 num. 6, Art. 92 Ley 30/1992

---

## 1. Regla General

Los **servicios de educación formal** prestados por establecimientos reconocidos por el MEN (Ministerio de Educación Nacional) están **excluidos de IVA** (Art. 476 num. 6 ET).

Los **servicios de educación no formal** (ahora "educación para el trabajo y desarrollo humano") y la **capacitación empresarial** están **gravados al 19%** salvo que se presten por entidades con licencia del MEN.

---

## 2. Análisis por Servicio MetodologIA

| Servicio | ¿Es educación formal? | ¿Tiene licencia MEN? | Tratamiento IVA | Evidencia |
|---------|----------------------|---------------------|----------------|-----------|
| **Workshop** (evento corto, sin currículo formal) | NO | NO | **Gravado 19%** | N/A |
| **Bootcamp** (programa intensivo con certificado) | Podría calificar como "educación para el trabajo" si tiene licencia | ☐ SÍ / ☐ NO | Si licencia: **Excluido**. Sin licencia: **Gravado 19%** | Licencia MEN o SENA |
| **Programa Élite** (transformación organizacional) | NO (es consultoría con componente formativo) | NO | **Gravado 19%** | N/A |
| **Consultoría** | NO | N/A | **Gravado 19%** | N/A |
| **Plataforma digital** (acceso a contenido) | NO (a menos que sea plataforma educativa licenciada) | ☐ SÍ / ☐ NO | Sin licencia: **Gravado 19%** | N/A |

---

## 3. Ruta para Obtener Exención

Si MetodologIA decide buscar la exención de IVA para bootcamps:

| Paso | Acción | Entidad | Plazo estimado |
|------|--------|---------|---------------|
| 1 | Obtener licencia de funcionamiento como institución de educación para el trabajo y desarrollo humano | Secretaría de Educación departamental/distrital | 6-12 meses |
| 2 | Registrar programas específicos ante el MEN | MEN / Secretaría de Educación | 3-6 meses adicionales |
| 3 | Actualizar RUT con responsabilidad "No responsable de IVA" para estos servicios | DIAN | 1 mes |
| 4 | Separar facturación: servicios educativos (excluidos) vs. consultoría (gravados) | Contador | Inmediato post-registro |

**Decisión actual:**

SUPUESTO: MetodologIA NO tiene licencia MEN. Todos los servicios se facturan con IVA 19%.
- Validar con: Representante Legal + Asesor Tributario
- Si se obtiene licencia en el futuro: actualizar este análisis y ajustar facturación

---

## 4. Riesgos

| Riesgo | Consecuencia |
|--------|-------------|
| Facturar sin IVA cuando debería cobrarse | DIAN reliquida: IVA no cobrado + sanción por inexactitud (100% de la diferencia, Art. 647 ET) |
| Cobrar IVA cuando el servicio es excluido | El cliente puede reclamar. MetodologIA debe devolver o emitir nota crédito. |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-16 / Javier Montaño + Claude

# Backcasting CFO / Contador / Revisor Fiscal — Modos de Fallo Financiero-Contable

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CFO / Contador / COO
**Método:** Backcasting — "¿Qué le reprocharía un revisor fiscal a un COO que lleva 6 meses sin gobierno financiero?"
**Contexto Legal:** República de Colombia — Estatuto Tributario, Código de Comercio, NIIF para PYMES, Ley 100/1993, Ley 1581/2012

---

## Propósito

Identificar los **22 modos de fallo** financieros, tributarios, contables y de seguridad social que un CFO, contador público, o revisor fiscal señalarían como incumplimientos o riesgos graves.

---

## Matriz de Modos de Fallo

### Severidad
- **CRÍTICO:** Sanciones de la DIAN, demandas laborales, inhabilitación del contador, responsabilidad penal del revisor fiscal
- **ALTO:** Multas, intereses moratorios, pérdida de beneficios tributarios, contingencias fiscales
- **MEDIO:** Desorden contable, ineficiencia operativa, riesgo en auditoría

---

### FMF-01: Sin Calendario Tributario — Deadlines Desconocidos

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Tributario |
| **Severidad** | CRÍTICO |
| **Descripción** | No existe un calendario con fechas de vencimiento de declaraciones de renta, IVA, retención en la fuente, información exógena, ICA. Los plazos pasan y se generan sanciones automáticas por extemporaneidad. |
| **Sanción** | Sanción por extemporaneidad: 5% del impuesto a cargo por cada mes de retraso (Art. 641 ET). Sanción mínima 2026: ~$472.000 COP (10 UVT). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `calendario-tributario-2026.md` |

---

### FMF-02: Declaración de Renta No Preparada

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Renta |
| **Severidad** | CRÍTICO |
| **Descripción** | No hay procedimiento para preparar y presentar la declaración de renta anual (formulario 210 persona jurídica o 110 persona natural con actividad económica). Sin conciliación entre ingresos NIIF y fiscales. |
| **Sanción** | No presentar: sanción del 20% del valor de consignaciones bancarias o ingresos brutos (Art. 643 ET). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-declaracion-renta.md` (dentro de SOP obligaciones DIAN) |

---

### FMF-03: IVA — Sin SOP de Declaración y Pago

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / IVA |
| **Severidad** | CRÍTICO |
| **Descripción** | Se factura con IVA 19% pero no hay proceso para: (a) determinar si es declarante bimestral o cuatrimestral, (b) calcular IVA generado vs. IVA descontable, (c) presentar declaración (formulario 300), (d) pagar la diferencia. |
| **Sanción** | Extemporaneidad + intereses moratorios (tasa DIAN vigente ~29% EA). |
| **Mitigación actual** | `facturar-servicio-sop.md` menciona IVA 19% pero NO cubre declaración ni pago. |
| **Documento requerido** | `sop-obligaciones-dian.md` (sección IVA) |

---

### FMF-04: Retención en la Fuente — Sin Tabla de Tarifas ni SOP

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Retención |
| **Severidad** | ALTO |
| **Descripción** | MetodologIA es agente de retención cuando paga a terceros (facilitadores, consultores, proveedores). No hay tabla de tarifas por concepto (honorarios, servicios, compras, arrendamiento). Retener de más o de menos genera sanciones. |
| **Sanción** | No retener: responsabilidad solidaria (Art. 370 ET). Retener y no declarar: sanción del 100% del valor no consignado (Art. 665 ET). |
| **Mitigación actual** | Playbook menciona "típicamente 11%" pero sin tabla detallada. |
| **Documento requerido** | `tabla-retencion-fuente-2026.md` + `sop-retencion-fuente.md` |

---

### FMF-05: PILA — Independientes Sin Pago de Seguridad Social

| Campo | Valor |
|-------|-------|
| **Categoría** | Seguridad Social |
| **Severidad** | CRÍTICO |
| **Descripción** | Los embajadores, facilitadores y consultores independientes que prestan servicios a MetodologIA deben cotizar a salud (EPS), pensión (AFP) y riesgos laborales (ARL) sobre el 40% de sus ingresos brutos. Si MetodologIA no verifica esto, puede ser solidariamente responsable (Art. 23 Decreto 1703/2002). |
| **Sanción** | Responsabilidad solidaria por prestaciones de salud y pensión no cotizadas. Demandas laborales si se reclasifican como empleados. |
| **Mitigación actual** | NINGUNA. El SOP de compensación 10/20/70 no menciona verificación de PILA. |
| **Documento requerido** | `sop-pila-independientes.md` + `checklist-verificacion-pila.md` |

---

### FMF-06: Cuenta de Cobro — Sin Formato Estándar

| Campo | Valor |
|-------|-------|
| **Categoría** | Documental / Contable |
| **Severidad** | MEDIO |
| **Descripción** | Los independientes que no son responsables de IVA deben emitir cuenta de cobro (no factura). No hay template estándar que garantice los campos mínimos: NIT/CC, concepto, valor, base de retención, firma. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `template-cuenta-de-cobro.md` |

---

### FMF-07: Certificados de Retención — Sin SOP de Emisión

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Retención |
| **Severidad** | ALTO |
| **Descripción** | MetodologIA debe emitir certificados de retención en la fuente a todos los terceros a quienes retuvo, antes del 31 de marzo del año siguiente. Sin estos certificados, los terceros no pueden descontar las retenciones en su declaración de renta. |
| **Sanción** | Sanción por no expedir: 5% del valor de las retenciones no certificadas (Art. 667 ET). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-certificados-retencion.md` + `template-certificado-retencion.md` |

---

### FMF-08: Estados Financieros — Sin Template ni Proceso de Cierre

| Campo | Valor |
|-------|-------|
| **Categoría** | Contable / NIIF |
| **Severidad** | CRÍTICO |
| **Descripción** | No hay templates para: Balance General, Estado de Resultados, Estado de Cambios en Patrimonio, Estado de Flujos de Efectivo, Notas. Sin cierre contable mensual, los números son aproximaciones. Sin estados financieros auditados, no se puede acceder a crédito ni participar en licitaciones. |
| **Sanción** | Código de Comercio Art. 19 num. 3: "Llevar contabilidad regular de sus negocios conforme a las prescripciones legales." Incumplimiento: presunción de mala fe en procesos judiciales. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-cierre-contable.md` + `templates-estados-financieros.md` |

---

### FMF-09: Revisor Fiscal — Sin Evaluación de Obligatoriedad

| Campo | Valor |
|-------|-------|
| **Categoría** | Auditoría / Código de Comercio |
| **Severidad** | CRÍTICO |
| **Descripción** | El Art. 203 del Código de Comercio obliga a tener revisor fiscal a: (a) sociedades anónimas, (b) toda sociedad con activos brutos >5.000 SMMLV o ingresos brutos >3.000 SMMLV. Sin revisor fiscal cuando es obligatorio, las decisiones de junta son anulables. |
| **Umbral 2026** | Activos >$7.800M COP o Ingresos >$4.680M COP (estimado con SMMLV 2026 ~$1.560.000). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `evaluacion-obligatoriedad-revisor-fiscal.md` |

---

### FMF-10: Contador Público — Rol No Definido

| Campo | Valor |
|-------|-------|
| **Categoría** | Contable / Legal |
| **Severidad** | CRÍTICO |
| **Descripción** | Toda sociedad comercial debe tener un contador público con tarjeta profesional que firme los estados financieros y declaraciones tributarias. Sin contador, las declaraciones son como no presentadas. |
| **Sanción** | Declaraciones sin firma de contador: se consideran no presentadas (Art. 580 ET num. 4). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `politica-roles-financieros.md` (define contador, CFO, revisor fiscal) |

---

### FMF-11: Información Exógena — Sin Preparación

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Informativa |
| **Severidad** | ALTO |
| **Descripción** | La DIAN exige reportes anuales de: clientes con compras >$500.000 COP, proveedores con pagos >[umbral], cuentas bancarias, socios/accionistas, ingresos recibidos para terceros. Sin esta información, la DIAN cruza datos y detecta inconsistencias. |
| **Sanción** | Sanción por no informar: 5% de las sumas no reportadas por cada mes de retraso (Art. 651 ET). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-obligaciones-dian.md` (sección exógena) |

---

### FMF-12: ICA — Impuesto Municipal No Declarado

| Campo | Valor |
|-------|-------|
| **Categoría** | Municipal |
| **Severidad** | ALTO |
| **Descripción** | El Impuesto de Industria y Comercio (ICA) se causa en cada municipio donde se presta el servicio. Si MetodologIA opera en Bogotá, Medellín, y otras ciudades, debe declarar y pagar ICA en cada una. Tarifas: 4.14‰ a 13.8‰ según actividad y municipio. |
| **Sanción** | Sanciones municipales por extemporaneidad + intereses moratorios. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `calendario-tributario-2026.md` (incluir ICA por municipio) |

---

### FMF-13: Nómina y Parafiscales — Sin Proceso

| Campo | Valor |
|-------|-------|
| **Categoría** | Laboral / Seguridad Social |
| **Severidad** | CRÍTICO (si hay empleados) |
| **Descripción** | Si MetodologIA tiene empleados directos: (a) debe liquidar nómina con deducciones de ley, (b) pagar seguridad social (salud 12.5%, pensión 16%, ARL 0.522%-6.96%), (c) parafiscales (SENA 2%, ICBF 3%, Caja 4%), (d) provisionar prestaciones (prima, cesantías, vacaciones, intereses sobre cesantías). |
| **Sanción** | No pagar seguridad social: responsabilidad penal del representante legal (Art. 271A Código Penal). |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-nomina-parafiscales.md` |

---

### FMF-14: SAGRILAFT/SARLAFT — Sin Sistema Anti-Lavado

| Campo | Valor |
|-------|-------|
| **Categoría** | Compliance / Anti-lavado |
| **Severidad** | ALTO |
| **Descripción** | Empresas del sector real con ingresos >30.000 UVT (~$1.416M COP) o activos >30.000 UVT deben implementar SAGRILAFT (Resolución 100-006 de 2020 Supersociedades). Incluye: KYC de clientes y proveedores, monitoreo de transacciones inusuales, PEP screening, reporte de operaciones sospechosas (ROS). |
| **Sanción** | Sanciones de Supersociedades: multas hasta 200 SMMLV (~$312M COP) + posible disolución. |
| **Mitigación actual** | `checklist-due-diligence-proveedores.md` cubre KYC parcial, pero no hay sistema SAGRILAFT formal. |
| **Documento requerido** | `politica-sagrilaft.md` |

---

### FMF-15: Factura Electrónica — Control de Consecutivo y Anulación

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Facturación |
| **Severidad** | MEDIO |
| **Descripción** | La resolución de facturación de la DIAN asigna un rango de consecutivos. Si se saltan números o se anulan sin nota crédito, la DIAN cruza y detecta inconsistencias. No hay SOP de anulación ni de control del consecutivo. |
| **Mitigación actual** | `facturar-servicio-sop.md` existe pero no cubre anulación ni consecutivo. |
| **Documento requerido** | Actualizar `facturar-servicio-sop.md` (agregar sección de control) |

---

### FMF-16: Exenciones de IVA en Educación — Sin Análisis

| Campo | Valor |
|-------|-------|
| **Categoría** | Tributario / IVA |
| **Severidad** | MEDIO |
| **Descripción** | El Art. 476 num. 6 del ET excluye de IVA los servicios de educación prestados por establecimientos de educación formal. Bootcamps y workshops pueden NO calificar si no están acreditados como educación formal ante el MEN. Cobrar IVA indebidamente o dejar de cobrarlo incorrectamente generan ajustes. |
| **Mitigación actual** | Playbook menciona "educación formal puede ser exenta" sin análisis específico. |
| **Documento requerido** | `analisis-exenciones-iva-educacion.md` |

---

### FMF-17: Precios de Transferencia — Sin Documentación

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Internacional |
| **Severidad** | MEDIO (solo si aplica) |
| **Descripción** | Si existen transacciones con vinculados económicos (Sofka, JM Labs u otras entidades del grupo) por >61.000 UVT (~$2.878M COP) en patrimonio bruto o >31.000 UVT (~$1.463M COP) en ingresos brutos, se debe documentar precios de transferencia. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `evaluacion-precios-transferencia.md` (evaluación de aplicabilidad) |

---

### FMF-18: Flujo de Caja — Sin Proyección Tributaria

| Campo | Valor |
|-------|-------|
| **Categoría** | Tesorería |
| **Severidad** | ALTO |
| **Descripción** | Los pagos de IVA, retención, renta, ICA y seguridad social crean descalces de caja. Sin proyección que incluya estos pagos, se puede llegar al vencimiento sin liquidez. |
| **Mitigación actual** | `forecast-arr-mrr-sop.md` existe pero NO incluye pagos tributarios en la proyección. |
| **Documento requerido** | Actualizar `forecast-arr-mrr-sop.md` + `proyeccion-flujo-caja-tributario.md` |

---

### FMF-19: Soporte de Costos y Deducciones — Sin Política

| Campo | Valor |
|-------|-------|
| **Categoría** | Tributario / Renta |
| **Severidad** | ALTO |
| **Descripción** | Para que un gasto sea deducible en renta, debe cumplir: (a) causalidad con la actividad generadora de renta, (b) necesidad, (c) proporcionalidad, (d) soporte documental (factura o cuenta de cobro), (e) pago de seguridad social del proveedor independiente verificado. Sin estos requisitos, la DIAN rechaza la deducción y reliquida el impuesto. |
| **Sanción** | Rechazo de deducciones: mayor impuesto + sanción por inexactitud del 100% de la diferencia (Art. 647 ET). |
| **Mitigación actual** | NINGUNA. No hay política de soportes para costos y deducciones. |
| **Documento requerido** | `politica-soportes-costos-deducciones.md` |

---

### FMF-20: Defensa ante Auditoría de DIAN — Sin Protocolo

| Campo | Valor |
|-------|-------|
| **Categoría** | Auditoría / DIAN |
| **Severidad** | ALTO |
| **Descripción** | Cuando la DIAN envía un Requerimiento Ordinario o Especial, hay plazos perentorios para responder (típicamente 15 días hábiles o 3 meses). Sin protocolo, la respuesta es desorganizada, se pierden plazos, y se consolidan las pretensiones de la DIAN. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-defensa-auditoria-dian.md` |

---

### FMF-21: Documento Soporte en Adquisiciones a No Obligados a Facturar

| Campo | Valor |
|-------|-------|
| **Categoría** | DIAN / Facturación |
| **Severidad** | ALTO |
| **Descripción** | Cuando MetodologIA compra a personas no obligadas a facturar (ej. freelancers del régimen simple), debe generar un "documento soporte en adquisiciones" electrónico (Resolución DIAN 000167/2021). Sin este documento, el gasto no es deducible. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `sop-documento-soporte-adquisiciones.md` (dentro de SOP retención) |

---

### FMF-22: Archivo y Conservación Documental — Sin Política

| Campo | Valor |
|-------|-------|
| **Categoría** | Contable / Legal |
| **Severidad** | MEDIO |
| **Descripción** | El Art. 28 de la Ley 962/2005 y el Art. 632 del ET exigen conservar soportes contables por mínimo 5 años (tributarios) y 10 años (comerciales). Sin política de archivo, los documentos se pierden y no se puede defender ante auditoría. |
| **Mitigación actual** | NINGUNA |
| **Documento requerido** | `politica-archivo-conservacion-documental.md` |

---

## Resumen de Cobertura

| Severidad | Total | Con mitigación parcial | Sin mitigación |
|-----------|-------|----------------------|----------------|
| CRÍTICO | 8 | 1 | 7 |
| ALTO | 10 | 2 | 8 |
| MEDIO | 4 | 1 | 3 |
| **TOTAL** | **22** | **4** | **18** |

**82% de los modos de fallo financiero-contable no tienen mitigación alguna.**

---

## Changelog

- v1.0.0 — Creación inicial con 22 modos de fallo CFO/Contador/Revisor Fiscal / Javier Montaño + Claude

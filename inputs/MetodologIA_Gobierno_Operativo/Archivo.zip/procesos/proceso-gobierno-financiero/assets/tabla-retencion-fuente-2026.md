# Tabla de Retención en la Fuente — Año Gravable 2026

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador
**Cierra:** FMF-04 (Backcasting CFO)
**UVT 2026 estimada:** ~$47.065 COP (actualizar con resolución DIAN)

> Actualizar cuando la DIAN publique el valor oficial de la UVT para 2026.

---

## Tabla de Retenciones — Pagos a Terceros

### Personas Naturales

| Concepto | Base mínima (UVT) | Base mínima (COP est.) | Tarifa Declarantes | Tarifa No Declarantes |
|---------|-------------------|----------------------|-------------------|---------------------|
| Honorarios | 0 | $0 | 11% | 10% |
| Servicios en general | 4 | ~$188.260 | 4% | 6% |
| Consultoría/Asesoría | 0 | $0 | 11% | 10% |
| Arrendamiento bienes inmuebles | 27 | ~$1.270.755 | 3.5% | 3.5% |
| Arrendamiento bienes muebles | 0 | $0 | 4% | 4% |
| Compras (bienes muebles) | 27 | ~$1.270.755 | 2.5% | 3.5% |
| Transporte (carga) | 4 | ~$188.260 | 1% | 1% |
| Transporte (pasajeros) | 27 | ~$1.270.755 | 3.5% | 3.5% |
| Otros ingresos tributarios | 27 | ~$1.270.755 | 2.5% | 3.5% |

### Personas Jurídicas

| Concepto | Base mínima (UVT) | Base mínima (COP est.) | Tarifa |
|---------|-------------------|----------------------|--------|
| Honorarios | 0 | $0 | 11% |
| Servicios en general | 4 | ~$188.260 | 4% |
| Consultoría/Asesoría | 0 | $0 | 11% |
| Compras (bienes muebles) | 27 | ~$1.270.755 | 2.5% |
| Arrendamiento bienes inmuebles | 27 | ~$1.270.755 | 3.5% |

### Retención de IVA (Reteiva)

| Concepto | Tarifa | Cuándo aplica |
|---------|--------|-------------|
| Régimen común que paga a régimen común | 15% del IVA | Cuando MetodologIA es agente retenedor de IVA (grandes contribuyentes o designados) |
| Servicios desde el exterior | 100% del IVA | Siempre que se pague un servicio digital o profesional desde el exterior |

---

## Retención sobre Ingresos Laborales (Nómina)

Aplica procedimiento 1 o 2 del Art. 383-386 ET.

**Procedimiento 1 (mensual):**

| Rango de ingreso laboral gravable mensual (UVT) | Tarifa marginal |
|------------------------------------------------|----------------|
| 0 a 95 UVT (~$4.471.175) | 0% |
| 95 a 150 UVT | 19% |
| 150 a 360 UVT | 28% |
| 360 a 640 UVT | 33% |
| 640 a 945 UVT | 35% |
| 945 a 2.300 UVT | 37% |
| >2.300 UVT | 39% |

**Nota:** Se aplica sobre el ingreso laboral gravable DESPUÉS de deducir aportes obligatorios a salud, pensión, dependientes (10% hasta 32 UVT), intereses de vivienda, y medicina prepagada.

---

## Aplicación Práctica para MetodologIA

### Pagos más frecuentes

| Tipo de pago | Concepto retención | Tarifa típica |
|-------------|-------------------|--------------|
| Facilitador independiente (PN declarante) | Honorarios | 11% |
| Facilitador independiente (PN no declarante) | Honorarios | 10% |
| Proveedor de software (PJ) | Servicios | 4% |
| Alquiler de salón para workshop | Arrendamiento inmueble | 3.5% |
| Compra de equipos/materiales | Compras | 2.5% |
| Plataforma LMS (si es del exterior) | Servicios + Reteiva 100% | 4% + 100% IVA |
| Embajador comercial (PN) | Honorarios o Servicios (según clasificación) | 11% o 4% |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-04 / Javier Montaño + Claude

# Template: Cuenta de Cobro para Contratistas Independientes

**Versión:** 1.0.0
**Cierra:** FMF-06 (Backcasting CFO)
**Uso:** Para contratistas NO obligados a facturar (no responsables de IVA)

---

## CUENTA DE COBRO No. [___]

**Fecha:** [DD/MM/AAAA]
**Ciudad:** [_______________]

---

**COBRADOR (Prestador del servicio):**

| Campo | Valor |
|-------|-------|
| Nombre completo | [_______________] |
| Cédula de ciudadanía No. | [_______________] de [_______________] |
| Dirección | [_______________] |
| Teléfono | [_______________] |
| Email | [_______________] |
| ¿Responsable de IVA? | ☐ NO (por eso emite cuenta de cobro, no factura) |
| Régimen tributario | ☐ No responsable de IVA | ☐ Régimen Simple de Tributación |

---

**PAGADOR (MetodologIA):**

| Campo | Valor |
|-------|-------|
| Razón social | [_______________] |
| NIT | [_______________] |

---

## Detalle del Servicio

| Concepto | Descripción | Valor (COP) |
|---------|-------------|------------|
| [Descripción del servicio prestado] | [Período: DD/MM a DD/MM/AAAA] | $[_______________] |
| | | |
| **Subtotal** | | **$[_______________]** |
| IVA | N/A (no responsable) | $0 |
| **Total a pagar** | | **$[_______________]** |

---

## Deducciones Aplicadas por el Pagador

| Concepto | Base | Tarifa | Valor retenido |
|---------|------|--------|---------------|
| Retención en la fuente (honorarios) | $[___] | __% | $[___] |
| Retención de ICA (si aplica) | $[___] | __‰ | $[___] |
| **Total deducciones** | | | **$[___]** |
| **Neto a pagar** | | | **$[___]** |

---

## Declaración de Seguridad Social

Declaro que me encuentro al día en el pago de aportes a seguridad social (salud, pensión y ARL) sobre una base de cotización no inferior al 40% de mis ingresos brutos mensualizados, conforme a la Ley 100/1993 y el Decreto 1703/2002.

**Adjunto:** ☐ Planilla PILA del mes [___] pagada | ☐ Pendiente (NO se autoriza el pago sin este soporte)

---

## Datos Bancarios para Consignación

| Campo | Valor |
|-------|-------|
| Banco | [_______________] |
| Tipo de cuenta | ☐ Ahorros | ☐ Corriente |
| Número de cuenta | [_______________] |
| Titular | [_______________] |

---

## Firma

Certifico que la información consignada es veraz y que el servicio descrito fue efectivamente prestado.

Nombre: ____________________________________
Cédula: ____________________________________
Firma: ____________________________________
Fecha: ____________________________________

---

## Campos de Control Interno MetodologIA (no compartir con el contratista)

| Campo | Valor |
|-------|-------|
| ODS/Contrato vinculado | [_______________] |
| Aprobado por | [_______________] |
| PILA verificada | ☐ SÍ | ☐ NO (NO PAGAR) |
| Registrado en contabilidad | ☐ SÍ |
| Fecha de pago programada | [_______________] |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-06 / Javier Montaño + Claude

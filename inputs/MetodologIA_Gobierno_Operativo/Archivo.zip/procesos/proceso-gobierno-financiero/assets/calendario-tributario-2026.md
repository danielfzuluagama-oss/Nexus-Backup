# Calendario Tributario 2026 — MetodologIA

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Contador / Finanzas
**Cierra:** FMF-01 (Backcasting CFO)
**Base legal:** Decreto de plazos DIAN 2026 (actualizar cuando se publique)

> **NOTA:** Las fechas exactas dependen del último dígito del NIT. Actualizar con el decreto de plazos DIAN cuando se publique (típicamente diciembre del año anterior).

---

## Obligaciones Mensuales

| Obligación | Formulario | Vencimiento | Responsable |
|-----------|-----------|-------------|------------|
| **Retención en la fuente** | F-350 | Mes siguiente, según calendario DIAN por NIT | Contador |
| **Autorretención renta** (si aplica) | F-350 (casilla especial) | Junto con retención | Contador |
| **PILA** (salud, pensión, ARL — propios + verificación independientes) | Planilla PILA | Antes del día 10 del mes siguiente | Finanzas/RRHH |
| **Nómina** (si hay empleados) | Liquidación interna | Día 30 (quincena) o fin de mes | Finanzas |

---

## Obligaciones Bimestrales

| Obligación | Formulario | Períodos | Vencimiento | Responsable |
|-----------|-----------|----------|-------------|------------|
| **IVA** (si declarante bimestral: ingresos >92.000 UVT) | F-300 | Ene-Feb, Mar-Abr, May-Jun, Jul-Ago, Sep-Oct, Nov-Dic | Mes siguiente al cierre del bimestre, según NIT | Contador |

---

## Obligaciones Cuatrimestrales

| Obligación | Formulario | Períodos | Vencimiento | Responsable |
|-----------|-----------|----------|-------------|------------|
| **IVA** (si declarante cuatrimestral: ingresos <92.000 UVT) | F-300 | Ene-Abr, May-Ago, Sep-Dic | Mes siguiente al cierre del cuatrimestre, según NIT | Contador |

---

## Obligaciones Trimestrales / Según Municipio

| Obligación | Municipio | Períodos | Vencimiento | Responsable |
|-----------|----------|----------|-------------|------------|
| **ICA Bogotá** (si opera en Bogotá) | Bogotá | Bimestral | 2 meses post-cierre bimestre | Contador |
| **ICA Medellín** (si opera en Medellín) | Medellín | Bimestral (anticipos) + Anual | Según calendario SHD Medellín | Contador |
| **ICA otros municipios** | [___] | Anual o según municipio | Según municipio | Contador |

---

## Obligaciones Anuales

| Obligación | Formulario | Vencimiento estimado | Responsable |
|-----------|-----------|---------------------|------------|
| **Declaración de Renta** (persona jurídica) | F-110 | Abril (según último dígito NIT) | Contador |
| **Declaración de Renta** (persona natural con actividad económica) | F-210 | Agosto-Octubre (según NIT) | Contador |
| **Información Exógena** | Formatos XML (1001, 1003, 1005, 1006, 1007, 1008, 1009, etc.) | Marzo-Abril (según calendario DIAN) | Contador |
| **Certificados de retención en la fuente** (a terceros) | Template MetodologIA | Antes del 31 de marzo | Contador |
| **Estados financieros** | NIIF (Balance, PyG, Flujo, Patrimonio, Notas) | Marzo (para asamblea de marzo) | Contador + Revisor Fiscal |
| **Asamblea de socios/accionistas** | Acta de asamblea | Antes del 31 de marzo | Representante Legal |
| **Renovación Cámara de Comercio** | Formulario RUES | Antes del 31 de marzo | Representante Legal |
| **Declaración ICA consolidada anual** | Según municipio | Según municipio (típicamente Ene-Mar) | Contador |
| **Información exógena municipal** (Bogotá y otras) | Según SHD | Según calendario local | Contador |

---

## Obligaciones Eventuales

| Obligación | Cuándo | Responsable |
|-----------|--------|------------|
| **Actualización RUT** | Cuando cambien datos (dirección, actividad, responsabilidades) | Representante Legal |
| **Resolución de facturación** | Cuando se agoten los consecutivos o venza la resolución | Contador |
| **Habilitación como facturador electrónico** | Al constituirse o cambiar de proveedor tecnológico | Contador + TI |
| **Registro RNBD** (bases de datos personales) | Al crear nuevas bases; actualizar anualmente | OPD |

---

## Calendario Visual — Resumen Mensual

| Mes | Obligaciones clave |
|-----|-------------------|
| **Enero** | PILA, Retención dic, Renovación Cámara Comercio, ICA cierre anual |
| **Febrero** | PILA, Retención ene, Preparar información exógena |
| **Marzo** | PILA, Retención feb, **Certificados retención** (deadline 31/03), **Estados financieros**, **Asamblea**, Información exógena (según calendario) |
| **Abril** | PILA, Retención mar, **Declaración de renta PJ** (según NIT), IVA bimestral/cuatrimestral |
| **Mayo** | PILA, Retención abr |
| **Junio** | PILA, Retención may, IVA bimestral |
| **Julio** | PILA, Retención jun |
| **Agosto** | PILA, Retención jul, IVA bimestral/cuatrimestral, **Renta PN** (según NIT) |
| **Septiembre** | PILA, Retención ago, Renta PN (cont.) |
| **Octubre** | PILA, Retención sep, Renta PN (cont.), IVA bimestral |
| **Noviembre** | PILA, Retención oct |
| **Diciembre** | PILA, Retención nov, IVA bimestral/cuatrimestral, Preparar cierre fiscal |

---

## Recordatorios Críticos

1. **30 días antes** de cada vencimiento: Contador notifica a Finanzas para asegurar liquidez
2. **15 días antes**: Declaración preparada en borrador para revisión
3. **5 días antes**: Declaración lista, pago programado
4. **Día de vencimiento**: Presentar y pagar antes de las 23:59

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMF-01 / Javier Montaño + Claude

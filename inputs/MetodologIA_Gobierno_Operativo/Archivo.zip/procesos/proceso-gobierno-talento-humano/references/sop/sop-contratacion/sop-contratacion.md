# SOP: Contratación de Personal

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / COO
**Cierra:** FMRH-03 (Backcasting RRHH)

---

## 1. Propósito

Estandarizar el proceso de vinculación de empleados y contratistas, asegurando cumplimiento legal, documentación completa, y onboarding efectivo.

---

## 2. Procedimiento

### Fase 1: Pre-Contratación

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 1.1 | Definir perfil del cargo (funciones, competencias, tipo de vinculación) | Director del área | Descripción de cargo |
| 1.2 | Completar `checklist-clasificacion-laboral.md` para definir tipo de contrato | RRHH | Checklist firmado |
| 1.3 | Publicar vacante (si aplica) o contactar candidato | RRHH / Director | Publicación o contacto |
| 1.4 | Entrevistar y evaluar candidato(s) | Director + RRHH | Notas de entrevista |
| 1.5 | Verificar antecedentes: Policía, Procuraduría, Contraloría, SIMIT | RRHH | Pantallazos de consulta |
| 1.6 | Verificar referencias laborales (mínimo 2) | RRHH | Registro de llamadas |

### Fase 2: Documentación Pre-Firma

**Documentos que el candidato debe entregar:**

| # | Documento | Obligatorio | Aplica a |
|---|-----------|------------|---------|
| 1 | Hoja de vida actualizada | SÍ | Todos |
| 2 | Copia de cédula de ciudadanía | SÍ | Todos |
| 3 | Certificados de estudio | SÍ | Todos |
| 4 | Certificaciones laborales (últimos 2 empleos) | SÍ | Empleados |
| 5 | RUT actualizado | SÍ | Independientes |
| 6 | Certificado de afiliación EPS | SÍ | Todos |
| 7 | Certificado de afiliación AFP | SÍ | Todos |
| 8 | Certificado de afiliación ARL | SÍ | Independientes (si ya tienen) |
| 9 | Libreta militar (hombres) | SÍ (Ley 1861/2017) | Hombres |
| 10 | Examen médico de ingreso | SÍ (si empleado, SG-SST) | Empleados |
| 11 | Autorización de tratamiento de datos personales | SÍ | Todos |

### Fase 3: Firma del Contrato

| Paso | Acción | Responsable |
|------|--------|------------|
| 3.1 | Seleccionar template de contrato según clasificación laboral | RRHH |
| 3.2 | Completar campos variables (nombre, cargo, salario, duración, funciones) | RRHH |
| 3.3 | Revisión por Director del área (alcance y funciones correctos) | Director |
| 3.4 | Firma por ambas partes (2 copias) | Representante Legal + Vinculado |
| 3.5 | Archivar copia en expediente del empleado | RRHH |

### Fase 4: Onboarding (Semana 1)

| Paso | Acción | Responsable |
|------|--------|------------|
| 4.1 | Afiliaciones: EPS, AFP, ARL, Caja de Compensación (si empleado nuevo) | RRHH |
| 4.2 | Onboarding tecnológico: crear accesos según `sop-gestion-accesos.md` | Admin TI |
| 4.3 | Inducción general: misión, valores, estructura, procesos | RRHH |
| 4.4 | Inducción de seguridad: política de seguridad de información, uso de IA | CTO / Admin TI |
| 4.5 | Inducción SST: riesgos del cargo, emergencias, botiquín | RRHH (con ARL) |
| 4.6 | Entrega de reglamento interno de trabajo (si aplica) | RRHH |
| 4.7 | Asignación de buddy/mentor para primera semana | Director del área |

---

## 3. Templates de Contrato

### Contrato Laboral (empleado directo)

Cláusulas mínimas conforme CST:
1. Identificación de las partes
2. Lugar de trabajo
3. Naturaleza y funciones del cargo
4. Salario y forma de pago
5. Período de prueba (máximo 2 meses, o 1/5 de la duración si es a término fijo)
6. Duración del contrato (indefinido, fijo, obra/labor)
7. Horario de trabajo y descansos
8. Cláusula de confidencialidad
9. Cláusula de propiedad intelectual
10. Causales de terminación

### Contrato de Prestación de Servicios (independiente)

Cláusulas mínimas:
1. Identificación de las partes
2. Objeto del contrato (resultado, NO subordinación)
3. Valor de honorarios y forma de pago
4. Duración
5. **Independencia:** declaración expresa de que NO hay subordinación
6. **PILA:** obligación del contratista de pagar seguridad social (con verificación por MetodologIA)
7. Confidencialidad
8. Propiedad intelectual
9. Terminación anticipada

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMRH-03 / Javier Montaño + Claude

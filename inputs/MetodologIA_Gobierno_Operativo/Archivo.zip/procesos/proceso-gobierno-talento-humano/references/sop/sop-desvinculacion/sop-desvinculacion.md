# SOP: Desvinculación de Personal

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / COO
**Cierra:** FMRH-04 (Backcasting RRHH)

---

## 1. Propósito

Garantizar que toda terminación de relación (laboral o contractual) se ejecuta conforme a la ley, con liquidación correcta, entrega de cargo documentada, revocación de accesos, y paz y salvo firmado.

---

## 2. Tipos de Terminación

| Tipo | Base legal | Indemnización | Preaviso |
|------|-----------|--------------|---------|
| **Mutuo acuerdo** | Art. 61 CST num. 1 | NO | NO |
| **Vencimiento del plazo** (fijo) | Art. 61 CST num. 3 | NO | 30 días antes del vencimiento |
| **Terminación de obra/labor** | Art. 61 CST num. 4 | NO | Al terminar la obra |
| **Justa causa (empleador)** | Art. 62 CST | NO | Proceso disciplinario previo |
| **Sin justa causa (empleador)** | Art. 64 CST | SÍ (tabla Art. 64) | 15 días (si fijo) |
| **Renuncia (empleado)** | Art. 61 CST num. 5 | NO | Costumbre: 15-30 días |
| **Terminación contrato de servicios** | Cláusula contractual | Conforme al contrato | Conforme al contrato |

---

## 3. Procedimiento

### Fase 1: Decisión y Notificación

| Paso | Acción | Responsable |
|------|--------|------------|
| 1.1 | Documentar la causa de terminación (acta, carta, o acuerdo mutuo) | RRHH + Director |
| 1.2 | Si es justa causa: verificar que se agotó el proceso disciplinario (descargos) | RRHH + Legal |
| 1.3 | Preparar carta de terminación con: fecha efectiva, causa, derechos del trabajador | RRHH |
| 1.4 | Notificar al trabajador/contratista por escrito | RRHH |

### Fase 2: Liquidación (solo empleados)

| Concepto | Cálculo | Plazo de pago |
|---------|---------|--------------|
| Salario proporcional | Días trabajados del último período | Al terminar |
| Vacaciones pendientes | Días acumulados no disfrutados × (salario/720) | Al terminar |
| Prima proporcional | Días del semestre × (salario/360) | Al terminar |
| Cesantías proporcionales | Días del año × (salario/360) | Al terminar |
| Intereses sobre cesantías | Cesantías × días × 0.12/360 | Al terminar |
| Indemnización (si sin justa causa) | Según tabla Art. 64 CST | Al terminar |

**PLAZO LEGAL:** Pagar liquidación el **mismo día** de terminación o máximo dentro de los días siguientes. Mora genera indemnización Art. 65 CST (1 día de salario por cada día de retraso).

### Fase 3: Entrega de Cargo

| Paso | Acción | Responsable |
|------|--------|------------|
| 3.1 | Entrega de documentos, archivos, y materiales de trabajo | Desvinculado |
| 3.2 | Devolución de equipo (laptop, teléfono, llaves, carnets) | Desvinculado → RRHH |
| 3.3 | Transferencia de conocimiento (documentar procesos pendientes) | Desvinculado → successor |
| 3.4 | **Offboarding tecnológico** conforme a `sop-gestion-accesos.md` (24h máximo) | Admin TI |

### Fase 4: Documentación Final

| Documento | Responsable | Plazo |
|-----------|------------|-------|
| Carta de terminación firmada | RRHH | Día de notificación |
| Liquidación detallada (hoja de cálculo) | Contador / RRHH | Día de terminación |
| **Paz y salvo** firmado por ambas partes | RRHH | Día de terminación |
| Certificación laboral (si la solicita) | RRHH | Dentro de 3 días hábiles |
| Actualización de registro CLM (si el contrato tenía CLM) | Operaciones | Dentro de 5 días |
| Cancelación de afiliaciones (EPS, AFP, ARL si empleado) | RRHH | Dentro del mes |

---

## 4. Template de Paz y Salvo

```
## PAZ Y SALVO — TERMINACIÓN DE RELACIÓN

**Fecha:** [_______________]

**PARTE 1: MetodologIA**
- Razón social: [_______________]
- NIT: [_______________]
- Representante: [_______________]

**PARTE 2: [Empleado/Contratista]**
- Nombre: [_______________]
- CC/NIT: [_______________]
- Cargo/Rol: [_______________]

### MetodologIA certifica que:
- [ ] La liquidación fue pagada por valor de COP $[_______________]
- [ ] No existen obligaciones pendientes hacia el trabajador/contratista
- [ ] Se entregó certificación laboral (si se solicitó)
- [ ] Se emitirán los certificados de retención en la fuente en el plazo legal

### El trabajador/contratista certifica que:
- [ ] Recibió el pago de la liquidación completa
- [ ] Entregó todos los equipos y materiales de trabajo
- [ ] Entregó toda la información y documentos de la empresa
- [ ] No tiene reclamaciones pendientes (o las siguientes: [___])

**Firma MetodologIA:** _________________ **Fecha:** _________
**Firma Trabajador:** _________________ **Fecha:** _________
**Testigo (opcional):** _________________ **CC:** _________
```

---

## 5. Riesgos

| Error | Consecuencia |
|-------|-------------|
| No pagar liquidación a tiempo | Indemnización moratoria: 1 salario/día (Art. 65 CST) |
| Terminar sin justa causa documentada | Indemnización obligatoria (Art. 64 CST) |
| No revocar accesos tecnológicos | Ex-empleado accede a información confidencial |
| No emitir certificación laboral | Multa del Ministerio del Trabajo |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMRH-04 / Javier Montaño + Claude

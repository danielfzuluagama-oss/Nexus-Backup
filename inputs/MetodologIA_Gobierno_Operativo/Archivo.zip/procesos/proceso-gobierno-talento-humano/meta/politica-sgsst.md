# Política de Seguridad y Salud en el Trabajo (SG-SST)

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / Representante Legal
**Cierra:** FMRH-08 (Backcasting RRHH)
**Base legal:** Decreto 1072/2015 (Libro 2, Parte 2, Título 4, Capítulo 6), Resolución 0312/2019

> **NOTA:** Este documento establece la política. La implementación completa del SG-SST requiere acompañamiento de la ARL y un profesional en SST. Los estándares mínimos dependen del número de empleados y nivel de riesgo (Resolución 0312/2019).

---

## 1. Declaración de Política

MetodologIA se compromete a:

1. **Proteger la seguridad y salud** de todos los trabajadores, contratistas, y visitantes.
2. **Identificar y controlar** los peligros y riesgos asociados a nuestras actividades.
3. **Cumplir** la normativa colombiana en materia de SST.
4. **Promover** una cultura de autocuidado y prevención.
5. **Destinar recursos** humanos, técnicos, y financieros para la implementación del SG-SST.
6. **Mejorar continuamente** el sistema mediante revisión periódica de indicadores.

---

## 2. Estándares Mínimos según Resolución 0312/2019

| # de empleados | Nivel de riesgo | Estándares aplicables |
|----------------|----------------|----------------------|
| 1-10 | I, II, III | 7 estándares mínimos |
| 11-50 | I, II, III | 21 estándares mínimos |
| >50, o cualquier tamaño con riesgo IV-V | IV, V | 60 estándares completos |

**Estado actual MetodologIA:** ☐ 1-10 empleados / ☐ 11-50 / ☐ >50 → Aplicar estándares correspondientes.

---

## 3. Elementos Mínimos del SG-SST (para empresas de 1-10 empleados, riesgo I-III)

| # | Requisito | Estado | Responsable |
|---|----------|--------|------------|
| 1 | Asignación de persona responsable de SST | ☐ Asignado: [___] | Representante Legal |
| 2 | Afiliación al sistema de seguridad social (EPS, AFP, ARL) | ☐ Todos afiliados | RRHH |
| 3 | Capacitación anual en SST | ☐ Programada: [fecha] | RRHH + ARL |
| 4 | Plan anual de trabajo | ☐ Elaborado / ☐ Pendiente | Responsable SST |
| 5 | Evaluaciones médicas ocupacionales (ingreso, periódicas, egreso) | ☐ Al día | RRHH |
| 6 | Identificación de peligros y valoración de riesgos | ☐ Matriz elaborada | Responsable SST |
| 7 | Medidas de prevención y control | ☐ Implementadas | Responsable SST |

---

## 4. Riesgos Típicos para MetodologIA (servicios profesionales)

| Riesgo | Clasificación | Control |
|--------|-------------|---------|
| Riesgo ergonómico (trabajo sentado prolongado) | Biomecánico | Pausas activas, silla ergonómica, monitor a altura correcta |
| Riesgo psicosocial (estrés, carga mental) | Psicosocial | Política de desconexión laboral, carga de trabajo razonable |
| Riesgo visual (uso prolongado de pantalla) | Físico | Pausas cada 2h, iluminación adecuada, filtro de luz azul |
| Riesgo de tránsito (desplazamiento a clientes) | Tránsito | Seguro, uso de cinturón, no usar celular al conducir |
| Riesgo eléctrico (uso de equipos electrónicos) | Eléctrico (bajo) | Equipos en buen estado, no sobrecargar tomas |

---

## 5. Obligaciones

### Del empleador (MetodologIA)
- Definir y divulgar la política de SST
- Destinar recursos para el SG-SST
- Afiliar y pagar ARL de empleados
- Afiliar a ARL a contratistas (cuando el contrato >1 mes)
- Reportar accidentes de trabajo a la ARL dentro de 2 días hábiles

### Del trabajador
- Cumplir las normas de SST
- Reportar condiciones inseguras
- Asistir a capacitaciones de SST
- Usar elementos de protección (si aplica)
- Reportar accidentes e incidentes de trabajo

---

## 6. Indicadores

| Indicador | Fórmula | Meta |
|-----------|---------|------|
| Frecuencia de accidentalidad | # accidentes / # trabajadores × 100 | 0% |
| Severidad | # días de incapacidad / # trabajadores × 100 | 0 |
| Cumplimiento plan anual SST | Actividades ejecutadas / actividades planeadas | >90% |
| Cobertura de exámenes médicos | # exámenes realizados / # trabajadores | 100% |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMRH-08 / Javier Montaño + Claude

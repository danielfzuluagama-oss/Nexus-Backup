# Política de Desconexión Laboral

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / COO
**Cierra:** FMRH-07 (Backcasting RRHH)
**Base legal:** Ley 2191/2022

---

## 1. Principio

Todo trabajador y contratista de MetodologIA tiene derecho a **no ser contactado** por asuntos laborales fuera de su jornada de trabajo, vacaciones, licencias, o permisos, salvo en situaciones de fuerza mayor o emergencia.

---

## 2. Horarios de Contacto Permitido

| Tipo de vinculado | Horario laboral | Fuera de horario |
|-------------------|----------------|-----------------|
| Empleado tiempo completo | 8:00 AM - 6:00 PM L-V | ❌ No contactar (salvo emergencia) |
| Empleado medio tiempo | Según contrato | ❌ No contactar |
| Contratista independiente | Según disponibilidad acordada | ❌ No contactar fuera de lo acordado |
| Embajador | Según acuerdo | No aplica obligatoriedad legal pero se respeta por cultura |

---

## 3. Qué Es Emergencia (Excepción)

| SÍ es emergencia | NO es emergencia |
|-----------------|-----------------|
| Incidente de seguridad de datos (P1) | "¿Puedes revisar este documento?" |
| Caída de plataforma durante evento en vivo | "¿Cuándo tienes la propuesta lista?" |
| Requerimiento de autoridad con plazo perentorio | "Recordatorio: la reunión es mañana" |
| Riesgo inminente para la vida o integridad | "Vi un error en el reporte" |

---

## 4. Reglas para Directivos y Líderes

1. **No enviar mensajes fuera de horario** esperando respuesta inmediata. Si necesita escribir para no olvidar, usar "programar envío" para que llegue en horario laboral.
2. **No sancionar** ni evaluar negativamente a alguien por no responder fuera de horario.
3. **Dar ejemplo:** Si el Director responde a las 11pm, el equipo siente presión implícita.

---

## 5. Consecuencias

| Conducta | Acción |
|----------|--------|
| Contacto recurrente fuera de horario sin justificación de emergencia | Amonestación verbal por RRHH |
| Reincidencia | Amonestación escrita |
| Represalia por no responder fuera de horario | Se puede configurar como **acoso laboral** (Ley 1010/2006) |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMRH-07 / Javier Montaño + Claude

# Proceso: Gestionar Gobierno de Talento Humano

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / COO

---

## 1. Propósito

Gobernar el ciclo de vida del talento: vinculación, gestión, desarrollo, y desvinculación, cumpliendo el Código Sustantivo del Trabajo y la normativa colombiana de seguridad social, acoso laboral, y SST.

---

## 2. Artefactos

### Templates

| Template | Cierra FMRH | Ubicación |
|----------|------------|-----------|
| `template-contrato-laboral.md` | FMRH-01 | `assets/templates/` |
| `template-contrato-prestacion-servicios.md` | FMRH-01 | `assets/templates/` |
| `template-paz-y-salvo.md` | FMRH-04 | `assets/templates/` |

### SOPs

| SOP | Cierra FMRH | Ubicación |
|-----|------------|-----------|
| `sop-contratacion.md` | FMRH-03 | `references/sop/sop-contratacion/` |
| `sop-desvinculacion.md` | FMRH-04 | `references/sop/sop-desvinculacion/` |
| `sop-evaluacion-desempeno.md` | FMRH-09 | `references/sop/sop-evaluacion-desempeno/` |
| `sop-capacitacion.md` | FMRH-10 | `references/sop/sop-capacitacion/` |

### Políticas

| Política | Cierra FMRH | Ubicación |
|---------|------------|-----------|
| `checklist-clasificacion-laboral.md` | FMRH-02 | `assets/` |
| `politica-desconexion-laboral.md` | FMRH-07 | `meta/` |
| `politica-sgsst.md` | FMRH-08 | `meta/` |

---

## 3. Cadencias

| Actividad | Frecuencia | Responsable |
|----------|-----------|------------|
| Evaluación de desempeño | Semestral | RRHH + Director del área |
| Actualización de plan de capacitación | Anual | RRHH |
| Reunión Comité de Convivencia | Trimestral (o cuando haya queja) | Comité |
| Auditoría SG-SST | Anual | ARL + RRHH |
| Verificación de clasificación laboral | Al vincular + anual | RRHH + Legal |

---

## Changelog

- v1.0.0 — Creación inicial / Javier Montaño + Claude

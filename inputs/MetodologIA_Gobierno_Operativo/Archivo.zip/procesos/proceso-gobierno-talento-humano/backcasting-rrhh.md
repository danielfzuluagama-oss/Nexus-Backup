# Backcasting RRHH — Modos de Fallo de Talento Humano y Derecho Laboral

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / COO
**Método:** Backcasting — "¿Qué demanda laboral ganaría un ex-colaborador por falta de governance de RRHH?"
**Contexto Legal:** Colombia — Código Sustantivo del Trabajo (CST), Ley 100/1993, Ley 1010/2006 (Acoso laboral), Ley 2191/2022 (Desconexión laboral)

---

## Modos de Fallo

### FMRH-01: Sin Contrato Laboral o de Prestación de Servicios Estandarizado

| Campo | Valor |
|-------|-------|
| **Severidad** | CRÍTICO |
| **Descripción** | Los vinculados (empleados, contratistas, facilitadores) no tienen contrato escrito, o cada contrato es diferente sin cláusulas estándar. Sin contrato escrito, se presume contrato laboral a término indefinido (Art. 24 CST). |
| **Documento requerido** | `template-contrato-laboral.md` + `template-contrato-prestacion-servicios.md` |

---

### FMRH-02: Riesgo de Reclasificación Laboral de Independientes

| Campo | Valor |
|-------|-------|
| **Severidad** | CRÍTICO |
| **Descripción** | Si un "contratista independiente" tiene: horario fijo, exclusividad, subordinación, herramientas provistas por MetodologIA, y pago mensual fijo — un juez lo reclasifica como empleado. Consecuencia: pago retroactivo de TODAS las prestaciones (prima, cesantías, vacaciones, seguridad social) por hasta 3 años. |
| **Documento requerido** | `checklist-clasificacion-laboral.md` |

---

### FMRH-03: Sin Proceso de Contratación Estandarizado

| Campo | Valor |
|-------|-------|
| **Severidad** | ALTO |
| **Descripción** | No hay checklist de contratación: verificación de antecedentes, solicitud de documentos (hoja de vida, cédula, certificaciones, libretas militares, afiliaciones SS), ni proceso de inducción formal. |
| **Documento requerido** | `sop-contratacion.md` |

---

### FMRH-04: Sin Proceso de Desvinculación

| Campo | Valor |
|-------|-------|
| **Severidad** | CRÍTICO |
| **Descripción** | No hay checklist de terminación: liquidación de prestaciones, paz y salvo, entrega de cargo, revocación de accesos, devolución de equipos. Errores en la liquidación generan demandas ante juez laboral. |
| **Documento requerido** | `sop-desvinculacion.md` + `template-paz-y-salvo.md` |

---

### FMRH-05: Sin Reglamento Interno de Trabajo (RIT)

| Campo | Valor |
|-------|-------|
| **Severidad** | ALTO |
| **Descripción** | El Art. 104 del CST obliga a empresas con >5 trabajadores permanentes a tener RIT publicado y depositado ante el Ministerio del Trabajo. Sin RIT, las sanciones disciplinarias son inaplicables. |
| **Documento requerido** | `reglamento-interno-trabajo.md` (cuando aplique el umbral) |

---

### FMRH-06: Sin Comité de Convivencia Laboral

| Campo | Valor |
|-------|-------|
| **Severidad** | ALTO |
| **Descripción** | La Ley 1010/2006 y la Resolución 652/2012 obligan a toda empresa a constituir un Comité de Convivencia Laboral para prevenir y atender quejas de acoso laboral. Sin comité, MetodologIA no puede gestionar quejas y enfrenta sanciones del Ministerio. |
| **Documento requerido** | `acta-constitucion-comite-convivencia.md` (cuando aplique) |

---

### FMRH-07: Sin Política de Desconexión Laboral

| Campo | Valor |
|-------|-------|
| **Severidad** | MEDIO |
| **Descripción** | La Ley 2191/2022 establece el derecho a la desconexión laboral fuera del horario de trabajo. Sin política, se envían mensajes a las 11pm esperando respuesta inmediata. El incumplimiento puede considerarse acoso laboral. |
| **Documento requerido** | `politica-desconexion-laboral.md` |

---

### FMRH-08: Sin SG-SST (Sistema de Gestión de Seguridad y Salud en el Trabajo)

| Campo | Valor |
|-------|-------|
| **Severidad** | CRÍTICO (si hay empleados) |
| **Descripción** | El Decreto 1072/2015 obliga a TODA empresa con al menos 1 empleado a implementar SG-SST. Incluye: política SST, matriz de riesgos, plan de trabajo anual, capacitaciones, exámenes médicos ocupacionales. Sin SG-SST: multas de hasta 500 SMMLV (~$780M COP). |
| **Documento requerido** | `politica-sgsst.md` + evaluación de implementación |

---

### FMRH-09: Sin Evaluación de Desempeño

| Campo | Valor |
|-------|-------|
| **Severidad** | MEDIO |
| **Descripción** | Sin evaluaciones periódicas, no hay base objetiva para decisiones de promoción, compensación variable, o terminación por bajo desempeño. Terminar sin evidencia de bajo desempeño = indemnización obligatoria. |
| **Documento requerido** | `sop-evaluacion-desempeno.md` |

---

### FMRH-10: Sin Plan de Capacitación

| Campo | Valor |
|-------|-------|
| **Severidad** | MEDIO |
| **Descripción** | MetodologIA vende formación pero no documenta la formación interna de su propio equipo. Para empresas con empleados, el SENA puede auditar el cumplimiento del aporte del 2% verificando que se ejecutan programas de capacitación. |
| **Documento requerido** | `sop-capacitacion.md` |

---

## Resumen

| Severidad | Total | Sin mitigación |
|-----------|-------|----------------|
| CRÍTICO | 4 | 4 |
| ALTO | 3 | 3 |
| MEDIO | 3 | 3 |
| **TOTAL** | **10** | **10** |

---

## Changelog

- v1.0.0 — Creación inicial con 10 FMRHs / Javier Montaño + Claude

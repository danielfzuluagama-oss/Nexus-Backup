# Checklist de Clasificación Laboral: ¿Empleado o Independiente?

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** RRHH / Legal
**Cierra:** FMRH-02 (Backcasting RRHH)
**Base legal:** CST Arts. 22-24, Sentencias CSJ SL (test de subordinación)
**Uso:** Completar ANTES de vincular a cualquier persona. Si el resultado es "EMPLEADO", debe firmarse contrato laboral.

---

## Instrucciones

Responder cada pregunta con SÍ o NO. Contar los SÍ. Si hay **3 o más SÍ**, existe riesgo alto de reclasificación laboral y se recomienda vincular con contrato laboral.

---

## Test de Subordinación (Art. 23 CST)

| # | Indicador | SÍ | NO |
|---|----------|----|----|
| 1 | ¿MetodologIA define el horario de trabajo de esta persona? | ☐ | ☐ |
| 2 | ¿MetodologIA define el lugar de trabajo (oficina, sede)? | ☐ | ☐ |
| 3 | ¿MetodologIA provee las herramientas (laptop, software, cuentas)? | ☐ | ☐ |
| 4 | ¿La persona debe reportar avances diarios/semanales como obligación? | ☐ | ☐ |
| 5 | ¿La persona trabaja exclusivamente para MetodologIA (no tiene otros clientes)? | ☐ | ☐ |
| 6 | ¿MetodologIA puede sancionar disciplinariamente a esta persona? | ☐ | ☐ |
| 7 | ¿La persona recibe un pago mensual fijo (no por resultado)? | ☐ | ☐ |
| 8 | ¿La relación tiene duración indefinida o se renueva automáticamente? | ☐ | ☐ |
| 9 | ¿MetodologIA decide qué hace la persona, no solo el resultado? | ☐ | ☐ |
| 10 | ¿La persona se presenta al mercado como "empleado de MetodologIA"? | ☐ | ☐ |

**Total SÍ:** ___/10

---

## Interpretación

| Score | Clasificación recomendada | Riesgo de reclasificación | Acción |
|-------|--------------------------|--------------------------|--------|
| **0-2 SÍ** | Independiente | BAJO | Proceder con contrato de prestación de servicios |
| **3-5 SÍ** | Zona gris | MEDIO-ALTO | Revisar con abogado laboral. Considerar contrato laboral. |
| **6-10 SÍ** | Empleado de facto | CRÍTICO | **Vincular con contrato laboral.** Contrato de prestación de servicios sería simulación. |

---

## Consecuencias de Reclasificación

Si un juez determina que el "independiente" es empleado:
- Pago retroactivo de: prima, cesantías + intereses, vacaciones (hasta 3 años)
- Pago retroactivo de seguridad social (salud, pensión) con intereses moratorios
- Indemnización moratoria (Art. 65 CST): 1 día de salario por cada día de mora
- Sanción al empleador por evasión de aportes (UGPP)

---

## Registro

```
**Persona evaluada:** [_______________]
**Rol propuesto:** [_______________]
**Fecha de evaluación:** [_______________]
**Evaluado por:** [_______________]
**Score:** ___/10
**Clasificación:** ☐ Independiente | ☐ Zona gris | ☐ Empleado
**Decisión:** ☐ Contrato de prestación de servicios | ☐ Contrato laboral
**Revisado por abogado:** ☐ SÍ | ☐ NO | ☐ N/A (score <3)
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FMRH-02 / Javier Montaño + Claude

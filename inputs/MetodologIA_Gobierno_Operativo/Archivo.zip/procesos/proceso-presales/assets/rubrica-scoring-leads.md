# Rúbrica de Scoring de Leads

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Director Comercial
**Cierra:** FM-06 (Backcasting COO)
**Uso:** Completar para CADA lead antes de ingresarlo al pipeline

---

## Instrucciones

Evaluar cada dimensión del 1 al 5. Sumar los 5 scores. Clasificar según umbral.

**Tiempo:** 5-10 minutos por lead
**Responsable:** Sales Rep asignado al lead
**Frecuencia:** Al recibir el lead y después de cada interacción significativa (re-score)

---

## Dimensiones de Scoring

### D1: PRESUPUESTO (Budget) — ¿Puede pagar?

| Score | Criterio |
|-------|---------|
| 5 | Presupuesto asignado y confirmado para este tipo de servicio |
| 4 | Presupuesto existe pero requiere aprobación interna |
| 3 | Hay indicios de capacidad de pago, pero no presupuesto específico |
| 2 | Empresa con revenue suficiente, pero sin señales de presupuesto asignado |
| 1 | Sin información de presupuesto, empresa pequeña o startup early-stage |

**Score D1:** ___/5

---

### D2: AUTORIDAD (Authority) — ¿Tiene poder de decisión?

| Score | Criterio |
|-------|---------|
| 5 | Contacto directo es el decision-maker (CxO, VP, Director) |
| 4 | Contacto tiene acceso directo al decision-maker y puede influir |
| 3 | Contacto es gerente medio, necesita escalar pero tiene canal |
| 2 | Contacto es operativo, lejos del decision-maker |
| 1 | Sin contacto con decisor, solo formulario web |

**Score D2:** ___/5

---

### D3: NECESIDAD (Need) — ¿El dolor es real y urgente?

| Score | Criterio |
|-------|---------|
| 5 | Dolor cuantificado, impacto medible (>10% costo o >20% tiempo), urgencia explícita |
| 4 | Dolor identificado, impacto estimado, proyecto en agenda del trimestre |
| 3 | Dolor reconocido pero no cuantificado, interés genuino |
| 2 | Interés exploratorio, "queremos entender opciones" |
| 1 | Sin dolor claro, contacto por curiosidad o benchmarking |

**Score D3:** ___/5

---

### D4: TIMELINE (Timing) — ¿Cuándo necesitan resolver?

| Score | Criterio |
|-------|---------|
| 5 | Necesitan resolver en próximos 30 días, deadline externo |
| 4 | Proyecto planificado para próximos 90 días |
| 3 | Interés para este semestre, sin fecha firme |
| 2 | Planificación para próximo año |
| 1 | Sin timeline, "algún día" |

**Score D4:** ___/5

---

### D5: FIT (Encaje) — ¿Somos la solución correcta?

| Score | Criterio |
|-------|---------|
| 5 | Necesidad mapeada directamente a servicio del catálogo, experiencia previa en la industria |
| 4 | Servicio disponible, requiere customización menor (<20%) |
| 3 | Servicio parcialmente disponible, requiere adaptación significativa |
| 2 | Servicio tangencial, fuera del core pero técnicamente posible |
| 1 | Fuera del alcance de servicios, requeriría capacidad nueva |

**Score D5:** ___/5

---

## Cálculo y Clasificación

**Score Total = D1 + D2 + D3 + D4 + D5 = ___/25**

| Rango | Clasificación | Acción |
|-------|-------------|--------|
| **18-25** | 🔥 **HOT** | Prioridad máxima. Avanzar a Deal Review inmediato. Asignar Solution Architect. |
| **12-17** | 🟡 **WARM** | Pipeline activo. Incluir en próximo Deal Review semanal. Programar follow-up. |
| **7-11** | 🔵 **NURTURE** | Devolver a marketing para nurturing. Re-evaluar en 30 días. |
| **5-6** | ⚪ **DISCARD** | No califica. Registrar motivo y archivar. No invertir más tiempo. |

---

## Registro

```
## SCORE CARD — [Nombre del Lead]

**Fecha de scoring:** [_______________]
**Sales Rep:** [_______________]
**Fuente del lead:** ☐ Marketing | ☐ Referido | ☐ Embajador | ☐ Aliado | ☐ Prospección directa | ☐ Evento

**Empresa:** [_______________]
**Contacto:** [_______________]
**Cargo:** [_______________]

| Dimensión | Score | Evidencia |
|-----------|-------|-----------|
| D1: Presupuesto | __/5 | [___] |
| D2: Autoridad | __/5 | [___] |
| D3: Necesidad | __/5 | [___] |
| D4: Timeline | __/5 | [___] |
| D5: Fit | __/5 | [___] |
| **TOTAL** | **__/25** | |

**Clasificación:** ☐ HOT | ☐ WARM | ☐ NURTURE | ☐ DISCARD
**Decisión:** [_______________]
**Próximo paso:** [_______________]
**Fecha de re-score:** [_______________]
```

---

## Changelog

- v1.0.0 — Creación inicial / BANT+Fit adaptado / Cierra FM-06 / Javier Montaño + Claude

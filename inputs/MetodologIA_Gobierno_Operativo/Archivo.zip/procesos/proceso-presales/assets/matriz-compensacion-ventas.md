# Matriz de Compensación de Ventas

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CEO / Director Comercial / RRHH
**Cierra:** FM-11 (Backcasting COO)
**Confidencialidad:** RESTRINGIDO — Solo accesible por directivos y RRHH

---

## 1. Principio

Toda persona con rol de ventas tiene una **estructura de compensación documentada, firmada y conocida ANTES de iniciar actividades comerciales.** Sin documento firmado, no hay derecho a comisión.

---

## 2. Estructura Base + Variable

| Componente | % del total | Descripción |
|-----------|-------------|-------------|
| **Base fija** | 60-70% | Salario o honorarios mensuales garantizados |
| **Variable** | 30-40% | Comisión sobre deals cerrados + bonos por cumplimiento |

---

## 3. Tabla de Comisiones por Rol

### Sales Representative (Ejecutivo Comercial)

| Rango de deal (COP) | Comisión sobre revenue neto | Pagada cuando |
|---------------------|---------------------------|---------------|
| < 20M | 5% | Primer pago del cliente recibido |
| 20M - 50M | 7% | 50% al primer pago, 50% al completar delivery |
| 50M - 100M | 8% | 50% al primer pago, 50% al completar delivery |
| > 100M | 10% | 33% al primer pago, 33% al 50% delivery, 34% al cierre |

### Sales Manager (Director Comercial)

| Concepto | % | Base de cálculo |
|---------|---|----------------|
| Comisión personal por deals propios | Igual que Sales Rep | Revenue neto del deal |
| Override sobre equipo | 2% | Revenue neto total del equipo |
| Bono de cuota trimestral | 15% del variable mensual | Si equipo alcanza ≥100% de cuota |

### Solution Architect (cuando participa en pre-sales)

| Concepto | % | Condición |
|---------|---|-----------|
| Bono de participación | 2-3% del deal | Si participó en >3 sesiones de discovery/structuring |

---

## 4. Aceleradores

| Condición | Multiplicador | Aplica a |
|-----------|-------------|---------|
| Superar cuota trimestral en >120% | 1.5x sobre el exceso | Sales Rep, Sales Manager |
| Deal de nuevo cliente (net-new logo) | 1.2x sobre la comisión del deal | Sales Rep |
| Deal con cross-sell (>2 servicios) | 1.1x sobre la comisión del deal | Sales Rep |
| Cierre antes del deadline del trimestre | +5% adicional sobre la comisión | Sales Rep |

---

## 5. Clawback (Devolución)

| Condición | Consecuencia |
|-----------|-------------|
| Cliente cancela contrato en primeros 90 días | 100% de la comisión pagada se devuelve |
| Cliente no paga factura en >90 días | Comisión pagada se descuenta de siguiente período |
| Deal fue cerrado con descuento no autorizado | Comisión se recalcula sobre precio aprobado |
| Fraude o misrepresentation al cliente | 100% devolución + proceso disciplinario |

---

## 6. Exclusiones (No generan comisión)

- Deals pro-bono o sociales
- Deals con entidades del grupo empresarial (intercompany)
- Renovaciones automáticas sin intervención comercial
- Deals donde el sales rep no fue el owner registrado en CRM

---

## 7. Proceso de Liquidación

| Paso | Acción | Responsable | Plazo |
|------|--------|------------|-------|
| 1 | Sales Rep registra deal cerrado en CRM con evidencia | Sales Rep | Día de cierre |
| 2 | Operaciones verifica: contrato firmado, ODS válida, registro CLM | Operaciones | 5 días hábiles |
| 3 | Finanzas confirma primer pago recibido del cliente | Finanzas | Cuando ocurra |
| 4 | Finanzas calcula comisión según esta matriz | Finanzas | 5 días post-pago |
| 5 | Director Comercial aprueba liquidación | Director Comercial | 3 días hábiles |
| 6 | Pago de comisión en siguiente nómina/honorarios | Finanzas/RRHH | Siguiente ciclo de pago |

---

## 8. Acuerdo Individual

Cada persona con rol de ventas firma un **Acuerdo Individual de Compensación** que incluye:

```
## ACUERDO INDIVIDUAL DE COMPENSACIÓN DE VENTAS

**Fecha:** [_______________]
**Nombre:** [_______________]
**Rol:** ☐ Sales Rep | ☐ Sales Manager | ☐ Solution Architect
**Período de vigencia:** [Desde] — [Hasta]

**Cuota trimestral asignada:** COP [_______________]
**Estructura aplicable:** Conforme a `matriz-compensacion-ventas.md` v[___]

Declaro que he leído y acepto los términos de compensación variable descritos
en la Matriz de Compensación de Ventas vigente, incluyendo las condiciones de
aceleradores, clawback y exclusiones.

Firma: ____________________________________
Fecha: ____________________________________
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-11 / Javier Montaño + Claude

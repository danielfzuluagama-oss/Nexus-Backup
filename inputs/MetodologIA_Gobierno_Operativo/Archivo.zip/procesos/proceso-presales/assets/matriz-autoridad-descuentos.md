# Matriz de Autoridad de Descuentos

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CEO / Director Comercial
**Cierra:** FM-03 (Backcasting COO)

---

## Principio

**Ningún descuento se otorga sin aprobación escrita del nivel de autoridad correspondiente.** La evidencia de aprobación es requisito en `checklist-pre-firma.md`.

---

## Bandas de Descuento

| Banda | Descuento sobre precio canónico | Aprobador | Medio de aprobación | Plazo de respuesta |
|-------|-------------------------------|-----------|--------------------|--------------------|
| **Verde** | 0-5% | Sales Rep (autónomo) | Registro en CRM | Inmediato |
| **Amarilla** | 6-10% | Director Comercial | Email con aprobación explícita | 1 día hábil |
| **Naranja** | 11-20% | Director Comercial + COO | Email dual con justificación | 2 días hábiles |
| **Roja** | 21-30% | CEO | Reunión + email de aprobación | 3 días hábiles |
| **Prohibida** | >30% | Junta Directiva / No permitido sin caso excepcional | Acta de junta | 5 días hábiles |

---

## Justificaciones Válidas

| Justificación | Banda máxima permitida | Condiciones |
|--------------|----------------------|------------|
| **Volumen** (>3 ODS simultáneas) | Naranja (20%) | Compromiso escrito de volumen |
| **Cliente estratégico** (referencia, marca conocida) | Naranja (20%) | Plan de case study o co-marketing |
| **Penetración de mercado** (nuevo segmento/geografía) | Amarilla (10%) | Plan de expansión documentado |
| **Competencia directa** (deal a punto de perderse) | Roja (30%) | Evidencia de oferta competidora |
| **Aliado/Reseller** (margen compartido) | Definido por modelo económico del aliado | Conforme a ODS de aliado |
| **Pro-bono / Social impact** | Roja+ (especial) | Aprobación CEO + alineación con misión |

---

## Justificaciones NO Válidas

- "El cliente dice que es caro" (sin evidencia de competencia)
- "Es mi primer deal y necesito cerrarlo" (presión personal)
- "El cliente es amigo" (conflicto de intereses → ref: `politica-conflicto-intereses.md`)
- "Ya le prometí el precio" (compromiso no autorizado)

---

## Excepciones a Términos de Pago

| Modificación | Aprobador |
|-------------|-----------|
| Pago a 45 días (vs. estándar 30) | Director Comercial |
| Pago a 60 días | COO |
| Pago a 90+ días | CEO (con justificación de cash flow) |
| 0% anticipo (vs. estándar con anticipo) | COO |
| Financiamiento interno (cuotas sin interés) | CEO |

---

## Proceso

1. Sales Rep identifica que el deal requiere descuento
2. Completa el **Formulario de Solicitud de Descuento** (ver abajo)
3. Envía al aprobador correspondiente según banda
4. Aprobador responde por email con "APROBADO" o "RECHAZADO" + razón
5. Sales Rep archiva la aprobación y la referencia en `checklist-pre-firma.md`
6. Si se rechaza, Sales Rep debe presentar propuesta a precio canónico o negociar valor agregado

---

## Formulario de Solicitud de Descuento

```
## SOLICITUD DE DESCUENTO

**Fecha:** [_______________]
**Sales Rep:** [_______________]
**Cliente:** [_______________]
**ODS/Servicio:** [_______________]

**Precio canónico:** COP [_______________]
**Precio solicitado:** COP [_______________]
**Descuento:** ___%
**Banda:** ☐ Verde | ☐ Amarilla | ☐ Naranja | ☐ Roja

**Justificación:** [_______________]
**Evidencia:** [Adjuntar: oferta competidora, plan de volumen, etc.]

**Impacto en margen:**
- Margen a precio canónico: ___%
- Margen con descuento: ___%
- Diferencia: COP [_______________]

**¿Deal se pierde sin descuento?** ☐ SÍ (evidencia) | ☐ PROBABLE | ☐ NO SEGURO
```

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-03 / Javier Montaño + Claude

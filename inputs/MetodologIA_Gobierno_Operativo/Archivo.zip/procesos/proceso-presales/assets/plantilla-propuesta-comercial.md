# Plantilla de Propuesta Comercial

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Director Comercial
**Cierra:** FM-15 (Backcasting COO)
**Uso:** Completar para CADA propuesta antes de enviar al cliente

---

## PROPUESTA COMERCIAL

### Encabezado

| Campo | Valor |
|-------|-------|
| **Propuesta No.** | PROP-[AAAA]-[###] |
| **Fecha** | [_______________] |
| **Cliente** | [_______________] |
| **Contacto principal** | [_______________] |
| **Sales Rep** | [_______________] |
| **Solution Architect** | [_______________] |
| **Vigencia de la propuesta** | 30 días calendario desde la fecha |
| **Lead Score** | __/25 (ref: `rubrica-scoring-leads.md`) |

---

### 1. Resumen Ejecutivo

[2-3 párrafos que resumen: el problema del cliente, la solución propuesta, y el impacto esperado. Escribir en lenguaje de negocio, no técnico.]

---

### 2. Contexto y Diagnóstico

**Situación actual del cliente:**
[Describir el estado actual basado en el discovery]

**Problema identificado:**
[Describir el dolor principal y su impacto cuantificado]

**Impacto de no actuar:**
[Qué pasa si el cliente no resuelve esto en los próximos 6 meses]

---

### 3. Solución Propuesta

**Enfoque:**
[Describir la metodología, fases, y entregables principales]

**Servicios incluidos:**

| Servicio | Código catálogo | Descripción | Duración |
|---------|----------------|-------------|----------|
| [___] | [TEC-XX / EST-XX] | [___] | [___] semanas |

**Entregables:**

| # | Entregable | Formato | Fecha estimada |
|---|-----------|---------|---------------|
| 1 | [___] | [___] | [___] |
| 2 | [___] | [___] | [___] |

---

### 4. Equipo Propuesto

| Rol | Nombre | Dedicación |
|-----|--------|-----------|
| Lead / Project Manager | [___] | __% |
| Solution Architect | [___] | __% |
| Especialista(s) | [___] | __% |

---

### 5. Cronograma

```
[Fase 1: Nombre] ─── [Semanas X-Y]
[Fase 2: Nombre] ─── [Semanas Y-Z]
[Fase 3: Nombre] ─── [Semanas Z-W]
```

**Duración total estimada:** [___] semanas
**Fecha de inicio propuesta:** [_______________]

---

### 6. Inversión

| Concepto | Valor (COP) | IVA | Total |
|---------|-------------|-----|-------|
| [Servicio 1] | $[___] | $[___] | $[___] |
| [Servicio 2] | $[___] | $[___] | $[___] |
| **TOTAL** | **$[___]** | **$[___]** | **$[___]** |

**Términos de pago:**
- Anticipo: ___% al firmar ODS
- Tramo 2: ___% al completar [hito]
- Tramo 3: ___% al cierre y aceptación

**Moneda:** Pesos Colombianos (COP)
**Facturación:** Electrónica conforme DIAN

---

### 7. Condiciones y Supuestos

**Incluye:**
- [Listar qué está incluido]

**NO incluye:**
- [Listar exclusiones explícitas]

**Supuestos del proyecto:**
- [El cliente provee accesos en X días]
- [El sponsor está disponible para revisiones quincenales]

---

### 8. Términos Contractuales

Esta propuesta se formaliza mediante:
1. **MSA** (`contrato-marco-servicios-msa.md`) — si no existe uno vigente
2. **ODS** (Orden de Servicio) — con detalle de alcance, precio y SLA
3. **NDA** — firmado previo a compartir información sensible

Las cláusulas estándar CL-01 a CL-10 (`clausulas-estandar-contratos.md`) aplican.

---

## APROBACIÓN INTERNA (no enviar al cliente sin estas firmas)

| Nivel | Aprobador | Estado | Fecha | Firma |
|-------|----------|--------|-------|-------|
| Comercial | Director Comercial | ☐ Aprobado / ☐ Rechazado | [___] | [___] |
| Financiero | COO/Finanzas | ☐ Aprobado / ☐ Rechazado / ☐ N/A (<20M) | [___] | [___] |
| Ejecutivo | CEO | ☐ Aprobado / ☐ Rechazado / ☐ N/A (<50M) | [___] | [___] |

**Gate:** Sin aprobación completa según `gestionar-presales-proceso.md` Fase 4, **NO SE ENVÍA AL CLIENTE.**

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-15 / Javier Montaño + Claude

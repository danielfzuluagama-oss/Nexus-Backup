# Proceso: Gestionar Pre-Sales

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** Director Comercial
**Audiencia:** Sales Executives, Solution Architects, Deal Managers
**Tiempo de Ciclo:** 15-45 días (lead raw → propuesta aprobada)
**Objetivo:** Convertir leads raw en oportunidades calificadas con propuestas aprobadas internamente, garantizando governance sobre pricing, descuentos y compromisos.

---

## 1. Propósito y Alcance

El proceso de Pre-Sales orquesta la **calificación, scoring, structuring y aprobación** de oportunidades comerciales antes de que entren al ciclo de venta formal. Es el filtro de calidad del pipeline.

**Incluye:**
- Recepción y registro de leads (de marketing, referidos, embajadores, aliados)
- Scoring cuantitativo de oportunidades
- Deal review semanal con governance
- Estructuración y aprobación de propuestas
- Negociación de términos contractuales
- Habilitación del equipo de ventas (enablement)

**NO incluye:**
- Generación de leads (es input del marketing)
- Ejecución de delivery (es output al proceso de delivery)
- Firma de contrato (es output al proceso de cierre, ref: `checklist-pre-firma.md`)

---

## 2. Fases del Proceso

```
QUALIFY → SCORE → REVIEW → PROPOSE → NEGOTIATE → APPROVE
(3-5d)    (1d)    (semanal)  (5-10d)    (5-15d)     (2-3d)
```

### Fase 1: QUALIFY (3-5 días)
**SOP:** `calificar-oportunidad-presales-sop.md`
Recibe lead raw, valida datos mínimos, asigna a sales rep, inicia formulario F0/F1 (ref: `proceso-onboarding-cliente`).

**Input:** Lead desde marketing, referido, embajador, aliado, o prospección directa.
**Output:** Lead registrado con datos básicos y asignación de owner.
**Gate:** Lead tiene nombre, empresa, y canal de contacto → avanza a Score.

### Fase 2: SCORE (1 día)
**Asset:** `rubrica-scoring-leads.md`
Sales rep completa la rúbrica de scoring (5 dimensiones x 1-5 puntos). El score determina la ruta.

| Score | Clasificación | Acción |
|-------|-------------|--------|
| 18-25 | 🔥 HOT | Avanza a Review inmediato |
| 12-17 | 🟡 WARM | Avanza a Review en próximo ciclo semanal |
| < 12 | 🔵 NURTURE | Devolver a marketing para nurturing |

**Output:** Lead con score cuantitativo y clasificación.

### Fase 3: REVIEW (Semanal)
**SOP:** `deal-review-sop.md`
Ceremonia semanal donde el Director Comercial revisa pipeline con el equipo. Decisiones: avanzar, holdear, o kill.

**Participantes:** Director Comercial, Sales Reps, Solution Architect (si aplica)
**Duración:** 60 minutos
**Output:** Pipeline limpio con decisiones documentadas.

### Fase 4: PROPOSE (5-10 días)
**SOP:** `aprobar-propuesta-sop.md`
**Template:** `plantilla-propuesta-comercial.md`
Estructurar propuesta comercial con pricing, alcance, timeline, y términos. Someterla a gate de aprobación interna.

**Gates de aprobación por monto:**

| Monto ODS | Aprobador | Plazo |
|-----------|----------|-------|
| < COP 20M | Director Comercial | 1 día |
| COP 20M - 50M | Director Comercial + COO | 2 días |
| > COP 50M | Director Comercial + COO + CEO | 3 días |

**Output:** Propuesta aprobada internamente, lista para enviar al cliente.

### Fase 5: NEGOTIATE (5-15 días)
**SOP:** `negociar-contrato-sop.md`
Cliente recibe propuesta, solicita cambios. Sales rep negocia conforme al playbook de negociación.

**Red Lines (no negociables):**
- Propiedad de metodologías y frameworks de MetodologIA
- Cláusula de confidencialidad
- Jurisdicción colombiana
- Limitación de responsabilidad

**Negociables (con aprobación):**
- Términos de pago (con aprobación de Finanzas)
- Descuentos (conforme a `matriz-autoridad-descuentos.md`)
- Alcance (con aprobación de Delivery)
- SLA específicos (con aprobación de Operaciones)

**Output:** Términos acordados mutuamente, listos para formalización.

### Fase 6: APPROVE (2-3 días)
Ejecutar `checklist-pre-firma.md` completo. Obtener firmas internas. Coordinar firma con cliente.

**Output:** Deal aprobado, contrato listo para firma.

---

## 3. Supuestos del Proceso

| # | Supuesto | Validación |
|---|----------|-----------|
| S1 | Existe CRM o herramienta para registrar leads y scores | Verificar con TI |
| S2 | El Director Comercial tiene disponibilidad semanal para Deal Review | Confirmar agenda |
| S3 | Los Solution Architects participan en la estructuración de propuestas | Confirmar asignación |
| S4 | El catálogo de precios canónico está actualizado | Verificar con Finanzas |

---

## 4. Artefactos del Proceso

| Artefacto | Tipo | Ubicación |
|-----------|------|-----------|
| `rubrica-scoring-leads.md` | Asset (scoring matrix) | `assets/` |
| `matriz-autoridad-descuentos.md` | Asset (approval matrix) | `assets/` |
| `matriz-compensacion-ventas.md` | Asset (comp model) | `assets/` |
| `plantilla-propuesta-comercial.md` | Template | `assets/` |
| `battle-card-template.md` | Template | `assets/battle-cards/` |
| `calificar-oportunidad-presales-sop.md` | SOP | `references/sop/sop-calificacion-presales/` |
| `deal-review-sop.md` | SOP | `references/sop/sop-deal-review/` |
| `aprobar-propuesta-sop.md` | SOP | `references/sop/sop-propuesta-aprobacion/` |
| `negociar-contrato-sop.md` | SOP | `references/sop/sop-negociacion-contrato/` |
| `gestionar-enablement-sop.md` | SOP | `references/sop/sop-enablement/` |

---

## 5. KPIs

| KPI | Fórmula | Meta |
|-----|---------|------|
| Sales Cycle Time | Días desde MQL hasta firma | < 45 días (B2B), < 15 días (B2C) |
| Win Rate | Propuestas aceptadas / propuestas enviadas | > 30% |
| Pipeline Coverage | Pipeline total / quota trimestral | > 3x |
| Average Deal Size | Revenue total / número de deals | Crecimiento trimestral |
| Discount Frequency | % deals con descuento / total deals | < 20% |
| Proposal Approval Time | Días desde solicitud hasta aprobación interna | < 3 días |

---

## Changelog

- v1.0.0 — Creación inicial del proceso pre-sales / Javier Montaño + Claude

# Política de Conflicto de Intereses

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** CEO / Junta Directiva
**Cierra:** FM-20 (Backcasting COO)
**Aplica a:** Fundadores, empleados, contratistas, embajadores, aliados GTM

---

## 1. Propósito

Establecer las reglas para **identificar, declarar y gestionar** situaciones donde los intereses personales, familiares o económicos de un colaborador puedan entrar en conflicto con los intereses de MetodologIA, sus clientes o su ecosistema.

---

## 2. Definiciones

**Conflicto de Intereses:** Situación en la que una persona vinculada a MetodologIA tiene un interés personal, financiero, familiar o profesional que podría influir indebidamente en su juicio, decisiones o acciones en representación de la organización.

**Tipos de conflicto:**

| Tipo | Ejemplo |
|------|---------|
| **Financiero** | Tener participación accionaria en un proveedor o competidor |
| **Familiar** | Contratar a un familiar como proveedor o subcontratista |
| **Profesional** | Ser consultor simultáneamente para MetodologIA y un competidor |
| **Comercial** | Un embajador que también vende servicios de un competidor directo |
| **Informacional** | Usar información confidencial de un cliente para beneficio personal |

---

## 3. Principio General

**Regla:** Todo conflicto de intereses, real o potencial, debe ser **declarado proactivamente** antes de que influya en cualquier decisión. La transparencia se valora; el ocultamiento se sanciona.

---

## 4. Obligaciones

### 4.1 Para todos los vinculados

1. **Declarar** cualquier conflicto de intereses, real o potencial, al momento de su identificación.
2. **Abstenerse** de participar en decisiones donde exista conflicto declarado.
3. **Actualizar** la declaración anualmente o cuando cambien las circunstancias.

### 4.2 Para embajadores y aliados GTM

1. **Declarar** si representan o venden servicios de competidores directos.
2. **Declarar** si tienen relación comercial con clientes de MetodologIA fuera del ecosistema.
3. **No utilizar** información de MetodologIA para beneficio de terceros competidores.

### 4.3 Para fundadores y directivos

1. Declarar todas las **participaciones societarias** en empresas relacionadas con el sector.
2. Declarar toda **relación familiar** con proveedores, clientes o competidores.
3. **Recusarse** de votaciones o decisiones donde exista conflicto.

---

## 5. Procedimiento de Declaración

### Paso 1: Identificar el conflicto
El vinculado identifica una situación que podría constituir conflicto de intereses.

### Paso 2: Declarar formalmente
Enviar el **Formulario de Declaración** (ver Sección 7) a:
- Empleados/Contratistas → COO
- Embajadores/Aliados → Director de Ecosistema
- Directivos/Fundadores → Junta Directiva o CEO (si no está involucrado)

### Paso 3: Evaluación
El receptor evalúa la severidad:

| Severidad | Definición | Acción |
|-----------|-----------|--------|
| **Baja** | Conflicto teórico, sin impacto actual | Registrar, monitorear anualmente |
| **Media** | Conflicto potencial con impacto si no se gestiona | Registrar, implementar mitigación (recusación de decisiones específicas) |
| **Alta** | Conflicto activo con impacto directo | Registrar, resolver (eliminar el conflicto o desvincular de la actividad) |

### Paso 4: Resolución
Opciones de mitigación:
1. **Recusación:** El vinculado se abstiene de decisiones relacionadas con el conflicto.
2. **Supervisión:** Un tercero supervisa las decisiones del vinculado en el área de conflicto.
3. **Desinversión:** El vinculado elimina el interés en conflicto (ej. vende participación).
4. **Reasignación:** El vinculado es reasignado a otra función/cuenta.
5. **Terminación:** En casos graves, terminación de la relación.

### Paso 5: Registro
Toda declaración y su resolución se registran en el **Registro de Conflictos de Intereses** (confidencial, custodiado por COO).

---

## 6. Sanciones por Incumplimiento

| Conducta | Sanción |
|----------|---------|
| No declarar conflicto conocido | Amonestación escrita + revisión de decisiones afectadas |
| Ocultar intencionalmente un conflicto | Terminación de la relación + acciones legales si hubo daño |
| Actuar en beneficio propio usando información confidencial | Terminación inmediata + acciones legales |
| Reincidencia después de amonestación | Terminación de la relación |

---

## 7. Formulario de Declaración

```
## DECLARACIÓN DE CONFLICTO DE INTERESES

**Fecha:** [_______________]
**Nombre completo:** [_______________]
**Rol en MetodologIA:** [_______________]
**Tipo de vínculo:** ☐ Empleado | ☐ Contratista | ☐ Embajador | ☐ Aliado GTM | ☐ Directivo/Fundador

### Descripción del conflicto
[Describir la situación, las partes involucradas, y por qué constituye un conflicto potencial o real]

### Tipo de conflicto
☐ Financiero | ☐ Familiar | ☐ Profesional | ☐ Comercial | ☐ Informacional

### Impacto potencial
[¿Qué decisiones o actividades podrían verse afectadas?]

### Propuesta de mitigación
[¿Qué sugiere el declarante para gestionar el conflicto?]

### Declaración
Declaro que la información anterior es veraz y completa. Me comprometo a actualizar esta declaración si las circunstancias cambian.

**Firma:** [_______________]
**Fecha:** [_______________]
```

---

## 8. Declaración Anual

Todos los vinculados deben completar una **declaración anual** de conflictos de intereses, incluso si no tienen ninguno que declarar (declaración negativa). Plazo: enero de cada año.

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-20 / Javier Montaño + Claude

# Contrato Marco de Prestación de Servicios (MSA)

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Contexto Legal:** República de Colombia
**Normas aplicables:** Código de Comercio (Decreto 410/1971), Código Civil, Ley 1581/2012 (Habeas Data), Ley 527/1999 (Comercio Electrónico), Estatuto Tributario
**Cierra:** FM-01 (Backcasting COO)

> **DISCLAIMER:** Este documento es una plantilla de referencia operativa. Debe ser revisado y aprobado por un abogado antes de su uso contractual. MetodologIA no presta servicios jurídicos.

---

## CONTRATO MARCO DE PRESTACIÓN DE SERVICIOS PROFESIONALES

Entre los suscritos a saber:

**[NOMBRE RAZÓN SOCIAL DEL CLIENTE]**, sociedad comercial constituida conforme a las leyes de la República de Colombia, identificada con NIT [_______________], con domicilio principal en [_______________], representada legalmente por **[NOMBRE REPRESENTANTE LEGAL]**, identificado(a) con cédula de ciudadanía número [_______________] de [_______________], quien en adelante se denominará **"EL CLIENTE"**,

y

**[NOMBRE RAZÓN SOCIAL METODOLOGÍA]**, sociedad comercial constituida conforme a las leyes de la República de Colombia, identificada con NIT [_______________], con domicilio principal en [_______________], representada legalmente por **[NOMBRE REPRESENTANTE LEGAL]**, identificado(a) con cédula de ciudadanía número [_______________] de [_______________], quien en adelante se denominará **"EL PRESTADOR"**,

quienes conjuntamente se denominarán **"LAS PARTES"**, han convenido celebrar el presente Contrato Marco de Prestación de Servicios Profesionales, el cual se regirá por las siguientes cláusulas:

---

## CLÁUSULA PRIMERA — OBJETO

EL PRESTADOR se obliga a prestar servicios profesionales especializados en las áreas de tecnología, formación, consultoría e innovación, según las condiciones particulares que se definan en cada **Orden de Servicio (ODS)** emitida bajo este Contrato Marco.

**Parágrafo 1:** Cada ODS constituirá un acuerdo específico que detallará: alcance, entregables, cronograma, precio, condiciones de pago, y niveles de servicio (SLA) aplicables.

**Parágrafo 2:** En caso de conflicto entre el presente Contrato Marco y una ODS, prevalecerán los términos de la ODS en lo que sea específico al servicio contratado, y los del Contrato Marco en todo lo demás.

---

## CLÁUSULA SEGUNDA — DURACIÓN

El presente Contrato Marco tendrá una duración de **[UN (1) AÑO / DOS (2) AÑOS]** contados a partir de la fecha de su firma, prorrogable automáticamente por períodos iguales salvo que alguna de LAS PARTES manifieste por escrito su intención de no renovar con al menos **treinta (30) días calendario** de anticipación al vencimiento del período vigente.

**Parágrafo:** La terminación del Contrato Marco no afectará las ODS en ejecución, las cuales continuarán vigentes hasta su conclusión conforme a sus propios términos.

---

## CLÁUSULA TERCERA — OBLIGACIONES DEL PRESTADOR

EL PRESTADOR se obliga a:

1. Prestar los servicios descritos en cada ODS con diligencia profesional, aplicando las mejores prácticas de la industria.
2. Asignar personal calificado y con las competencias técnicas requeridas para cada servicio.
3. Cumplir los cronogramas, entregables y niveles de servicio pactados en cada ODS.
4. Mantener la confidencialidad de la información de EL CLIENTE conforme a la Cláusula Séptima.
5. Notificar oportunamente cualquier riesgo, retraso o impedimento que pueda afectar la prestación del servicio.
6. Cumplir con la normativa aplicable en materia de protección de datos personales (Ley 1581/2012).
7. Entregar facturas electrónicas conforme a la normativa DIAN vigente.

---

## CLÁUSULA CUARTA — OBLIGACIONES DEL CLIENTE

EL CLIENTE se obliga a:

1. Proporcionar oportunamente la información, accesos y recursos necesarios para la prestación de los servicios.
2. Designar un **SPOC** (Single Point of Contact) con autoridad para tomar decisiones operativas relacionadas con cada ODS.
3. Revisar y aprobar los entregables dentro de los plazos establecidos en cada ODS. En caso de no pronunciarse dentro de **diez (10) días hábiles** posteriores a la entrega, los entregables se considerarán aceptados.
4. Realizar los pagos en los plazos pactados en cada ODS.
5. No solicitar a EL PRESTADOR actividades que excedan el alcance de la ODS sin formalizar una **solicitud de cambio** por escrito.

---

## CLÁUSULA QUINTA — PRECIO Y CONDICIONES DE PAGO

1. El precio de cada servicio se definirá en la ODS correspondiente.
2. Los precios se expresarán en **Pesos Colombianos (COP)** más el **IVA** vigente (actualmente 19%).
3. Las facturas electrónicas se emitirán conforme al calendario de hitos o periodicidad definida en cada ODS.
4. El plazo de pago será de **treinta (30) días calendario** contados a partir de la fecha de radicación de la factura, salvo que la ODS establezca un plazo diferente.
5. El incumplimiento en el pago generará intereses de mora a la tasa máxima legal permitida (Art. 884 Código de Comercio).

**Parágrafo:** EL PRESTADOR se reserva el derecho de suspender la prestación de servicios si EL CLIENTE acumula mora superior a **sesenta (60) días calendario**, previa notificación escrita con **quince (15) días** de anticipación.

---

## CLÁUSULA SEXTA — PROPIEDAD INTELECTUAL

1. **Propiedad preexistente:** Cada parte conserva la titularidad de su propiedad intelectual preexistente. Ninguna disposición del presente contrato transfiere propiedad intelectual preexistente.

2. **Entregables del servicio:** Salvo que la ODS disponga lo contrario, los entregables creados específicamente para EL CLIENTE durante la ejecución de una ODS serán de propiedad de EL CLIENTE una vez se realice el pago total del servicio.

3. **Metodologías y herramientas:** Las metodologías, frameworks, herramientas, plantillas, y know-how utilizados por EL PRESTADOR son y seguirán siendo propiedad exclusiva de EL PRESTADOR. EL CLIENTE recibe una licencia de uso no exclusiva, intransferible y limitada al alcance del servicio contratado.

4. **Propiedad compartida:** El conocimiento generado conjuntamente durante sesiones de co-creación (ej. workshops) será de propiedad compartida, salvo acuerdo expreso en la ODS.

**Parágrafo:** Para servicios que requieran cesión formal de propiedad intelectual, LAS PARTES suscribirán el **Anexo de Cesión de Derechos de Propiedad Intelectual** (`cesion-derechos-ip.md`).

---

## CLÁUSULA SÉPTIMA — CONFIDENCIALIDAD

1. LAS PARTES se obligan a mantener en estricta confidencialidad toda información técnica, comercial, financiera, operativa o de cualquier otra naturaleza que reciban de la otra parte en razón del presente contrato.

2. La obligación de confidencialidad tendrá una vigencia de **tres (3) años** contados a partir de la terminación del Contrato Marco o de la última ODS ejecutada, lo que ocurra después.

3. No se considerará información confidencial aquella que:
   a) Sea de dominio público sin culpa de la parte receptora.
   b) Haya sido conocida previamente por la parte receptora de forma legítima.
   c) Sea requerida por autoridad competente mediante orden judicial o administrativa.

4. En caso de existir un **NDA** firmado entre LAS PARTES, los términos del NDA prevalecerán sobre esta cláusula en lo que le sea más favorable a la protección de la información.

---

## CLÁUSULA OCTAVA — PROTECCIÓN DE DATOS PERSONALES

1. LAS PARTES se comprometen a cumplir la **Ley 1581 de 2012** y el **Decreto 1377 de 2013** en materia de tratamiento de datos personales.

2. Cuando EL PRESTADOR actúe como **Encargado del Tratamiento** de datos personales de EL CLIENTE, LAS PARTES suscribirán el **Acuerdo de Tratamiento de Datos** (`acuerdo-tratamiento-datos-dpa.md`).

3. EL PRESTADOR se compromete a:
   a) Tratar los datos personales únicamente para las finalidades autorizadas por EL CLIENTE.
   b) Implementar medidas de seguridad técnicas y organizativas apropiadas.
   c) Notificar a EL CLIENTE cualquier incidente de seguridad de datos dentro de las **veinticuatro (24) horas** siguientes a su detección.
   d) Devolver o destruir los datos personales al término del servicio, según instrucción de EL CLIENTE.

---

## CLÁUSULA NOVENA — GARANTÍA Y NIVELES DE SERVICIO

1. EL PRESTADOR garantiza que los servicios se prestarán con la calidad y estándares profesionales esperables de un prestador especializado.

2. Los niveles de servicio específicos (tiempos de respuesta, disponibilidad, calidad de entregables) se definirán en cada ODS o en el **Anexo de SLA** correspondiente.

3. El incumplimiento de SLA generará las penalizaciones o créditos definidos en el Anexo de SLA, sin perjuicio de las demás acciones legales a que haya lugar.

---

## CLÁUSULA DÉCIMA — LIMITACIÓN DE RESPONSABILIDAD

1. La responsabilidad total acumulada de EL PRESTADOR bajo este Contrato Marco no excederá el **valor total de las ODS ejecutadas en los últimos doce (12) meses** anteriores al evento generador de la responsabilidad.

2. En ningún caso EL PRESTADOR será responsable por daños indirectos, incidentales, consecuenciales, lucro cesante, o pérdida de datos, salvo en casos de dolo o culpa grave.

3. Las limitaciones de esta cláusula no aplicarán a:
   a) Obligaciones de confidencialidad.
   b) Obligaciones de protección de datos personales.
   c) Infracciones de propiedad intelectual.

---

## CLÁUSULA DÉCIMA PRIMERA — TERMINACIÓN

1. **Terminación por mutuo acuerdo:** En cualquier momento, mediante comunicación escrita firmada por ambas partes.

2. **Terminación por incumplimiento:** Cualquiera de LAS PARTES podrá terminar el contrato si la otra parte incumple una obligación material y no subsana dicho incumplimiento dentro de los **treinta (30) días calendario** siguientes a la notificación escrita del incumplimiento.

3. **Terminación por conveniencia:** Cualquiera de LAS PARTES podrá terminar el contrato sin causa, mediante notificación escrita con **sesenta (60) días calendario** de anticipación.

4. **Efectos de la terminación:**
   a) Las ODS en ejecución se terminarán conforme a lo que las partes acuerden o, en su defecto, dentro de los treinta (30) días siguientes.
   b) EL CLIENTE pagará los servicios efectivamente prestados hasta la fecha de terminación.
   c) Las obligaciones de confidencialidad y protección de datos sobrevivirán a la terminación.

---

## CLÁUSULA DÉCIMA SEGUNDA — SOLUCIÓN DE CONTROVERSIAS

1. LAS PARTES intentarán resolver cualquier controversia mediante **negociación directa** entre los representantes legales dentro de los **quince (15) días hábiles** siguientes a la notificación de la controversia.

2. Si la negociación directa no prospera, LAS PARTES someterán la controversia a un **Tribunal de Arbitraje** del Centro de Arbitraje y Conciliación de la Cámara de Comercio de **[Bogotá / Medellín / Ciudad acordada]**, el cual estará integrado por **[un (1) / tres (3)]** árbitro(s) designado(s) conforme al reglamento de dicho Centro.

3. El arbitraje será en **derecho**, se conducirá en **idioma español**, y la sede será **[Ciudad]**, Colombia.

---

## CLÁUSULA DÉCIMA TERCERA — DISPOSICIONES GENERALES

1. **Independencia:** La relación entre LAS PARTES es de contratistas independientes. No se configura relación laboral, sociedad, agencia, ni representación.

2. **Cesión:** Ninguna de LAS PARTES podrá ceder el presente contrato sin el consentimiento previo y escrito de la otra parte.

3. **Modificaciones:** Cualquier modificación al presente contrato deberá constar por escrito y estar firmada por ambas partes.

4. **Totalidad del acuerdo:** El presente contrato, junto con sus anexos y las ODS emitidas, constituye la totalidad del acuerdo entre LAS PARTES y reemplaza cualquier acuerdo o negociación previa sobre la materia.

5. **Notificaciones:** Todas las notificaciones se realizarán por escrito a las direcciones indicadas en el encabezado del contrato, o a las direcciones de correo electrónico que LAS PARTES designen.

6. **Ley aplicable:** El presente contrato se rige por las leyes de la República de Colombia.

---

## FIRMAS

En señal de aceptación, se firma el presente contrato en dos (2) ejemplares del mismo tenor y contenido, en [Ciudad], a los [___] días del mes de [_______________] de [___].

---

**POR EL CLIENTE:**

Nombre: ____________________________________
Cargo: ____________________________________
Cédula: ____________________________________
Firma: ____________________________________
Fecha: ____________________________________

---

**POR EL PRESTADOR:**

Nombre: ____________________________________
Cargo: ____________________________________
Cédula: ____________________________________
Firma: ____________________________________
Fecha: ____________________________________

---

## ANEXOS (se incorporan por referencia)

| Anexo | Documento | Cuándo aplica |
|-------|-----------|---------------|
| Anexo A | `anexo-a-sla-black-label.md` | Servicios Premium |
| Anexo B | `anexo-b-ficha-spoc.md` | Todos los servicios |
| Anexo C | `acuerdo-tratamiento-datos-dpa.md` | Cuando se procesan datos personales |
| Anexo D | `cesion-derechos-ip.md` | Cuando se requiera cesión formal de IP |
| Anexo E | Orden de Servicio (ODS) correspondiente | Siempre |

---

## Changelog

- v1.0.0 — Creación inicial como MSA paraguas para todos los verticales / Cierra FM-01 / Javier Montaño + Claude

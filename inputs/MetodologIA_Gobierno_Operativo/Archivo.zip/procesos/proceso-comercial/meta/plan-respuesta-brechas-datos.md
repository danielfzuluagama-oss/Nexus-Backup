# Plan de Respuesta a Incidentes de Seguridad de Datos Personales

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Contexto Legal:** República de Colombia
**Normas aplicables:** Ley 1581/2012 (Art. 17 lit. n), Decreto 1377/2013, Circular 002/2023 SIC (notificación de incidentes)
**Cierra:** FM-02 (Backcasting COO)
**Owner:** Oficial de Protección de Datos / COO

> **DISCLAIMER:** Template operativa. Adaptar a la estructura organizacional real y validar con asesor legal.

---

## 1. Propósito

Establecer el procedimiento para **detectar, contener, investigar, notificar y remediar** incidentes de seguridad que comprometan datos personales bajo custodia de MetodologIA, cumpliendo los tiempos y requisitos de la SIC.

---

## 2. Alcance

Aplica a todo incidente que involucre:
- Acceso no autorizado a datos personales
- Pérdida, destrucción o alteración no intencional de datos
- Divulgación no autorizada de datos personales
- Ransomware o malware que afecte bases de datos con información personal

---

## 3. Roles y Responsabilidades

| Rol | Responsabilidad | Titular |
|-----|----------------|---------|
| **Oficial de Protección de Datos (OPD)** | Coordinación general del incidente, notificaciones | [Nombre] |
| **COO** | Decisiones operativas, autorización de comunicaciones | [Nombre] |
| **CEO** | Aprobación de comunicaciones públicas, contacto con SIC | [Nombre] |
| **Responsable de TI** | Contención técnica, forensia, restauración | [Nombre] |
| **Asesor Legal** | Evaluación de obligaciones legales, redacción de notificaciones | [Nombre/Firma] |
| **Comunicaciones** | Comunicaciones internas y externas | [Nombre] |

---

## 4. Clasificación de Incidentes

| Nivel | Descripción | Ejemplo | Tiempo de respuesta |
|-------|-------------|---------|-------------------|
| **CRÍTICO** | Datos sensibles comprometidos, >1000 titulares, exposición pública | Base de datos de clientes filtrada públicamente | Activación inmediata (0h) |
| **ALTO** | Datos personales comprometidos, <1000 titulares, sin exposición pública | Acceso no autorizado a carpeta compartida con datos de clientes | Activación en <4h |
| **MEDIO** | Posible compromiso, en investigación | Email con datos personales enviado a destinatario incorrecto | Activación en <8h |
| **BAJO** | Vulnerabilidad detectada sin explotación confirmada | Descubrimiento de contraseña débil en sistema con datos personales | Evaluación en <24h |

---

## 5. Procedimiento de Respuesta

### Fase 1: DETECCIÓN (0-2 horas)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 1.1 | Recibir reporte del incidente (interno, externo, o automático) | Cualquier empleado → OPD | Registro de reporte con timestamp |
| 1.2 | Clasificar severidad (Crítico/Alto/Medio/Bajo) | OPD | Formulario de clasificación completado |
| 1.3 | Activar equipo de respuesta según severidad | OPD | Notificación al equipo (email/chat) |
| 1.4 | Documentar hallazgos iniciales | OPD | Bitácora de incidente iniciada |

### Fase 2: CONTENCIÓN (2-24 horas)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 2.1 | Aislar sistema(s) afectado(s) | Responsable TI | Log de acciones técnicas |
| 2.2 | Preservar evidencia forense (logs, imágenes, tráfico) | Responsable TI | Copia forense con hash SHA-256 |
| 2.3 | Revocar accesos comprometidos | Responsable TI | Lista de accesos revocados |
| 2.4 | Evaluar alcance: ¿qué datos? ¿cuántos titulares? ¿qué bases? | OPD + TI | Informe de alcance |
| 2.5 | Activar comunicación interna (equipo directivo informado) | COO | Minuta de reunión |

### Fase 3: NOTIFICACIÓN (24-72 horas)

| Paso | Acción | Responsable | Plazo | Evidencia |
|------|--------|------------|-------|-----------|
| 3.1 | Evaluar obligación de notificación a titulares | OPD + Legal | 24h post-contención | Informe legal |
| 3.2 | Notificar a titulares afectados (si aplica) | OPD + Comunicaciones | 72h post-detección | Comunicación enviada con acuse |
| 3.3 | Notificar a la SIC (si aplica, conforme Circular 002/2023) | OPD + Legal + CEO | Conforme plazos SIC | Radicado ante SIC |
| 3.4 | Notificar a clientes corporativos (si datos de sus usuarios) | OPD + Comercial | 24h post-contención | Comunicación contractual (DPA) |
| 3.5 | Notificar a encargados de tratamiento afectados | OPD | 24h post-contención | Notificación escrita |

**Contenido mínimo de la notificación a titulares:**
1. Descripción del incidente (sin detalles técnicos sensibles)
2. Datos comprometidos (categorías, no datos específicos)
3. Acciones de contención tomadas
4. Recomendaciones para el titular (cambiar contraseñas, monitorear cuentas)
5. Canal de contacto para consultas
6. Medidas correctivas planificadas

### Fase 4: ERRADICACIÓN (1-7 días)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 4.1 | Eliminar causa raíz del incidente | Responsable TI | Informe técnico de remediación |
| 4.2 | Parchear vulnerabilidades identificadas | Responsable TI | Log de parches aplicados |
| 4.3 | Verificar que la contención fue efectiva (re-test) | Responsable TI | Resultado de pruebas |
| 4.4 | Restaurar servicios afectados | Responsable TI | Confirmación de restauración |

### Fase 5: RECUPERACIÓN Y LECCIONES (7-30 días)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 5.1 | Monitoreo intensivo post-incidente (30 días) | Responsable TI | Dashboard de monitoreo |
| 5.2 | Informe completo del incidente (post-mortem) | OPD | Informe final |
| 5.3 | Reunión de lecciones aprendidas | COO | Minuta con acciones correctivas |
| 5.4 | Actualizar controles de seguridad | OPD + TI | Plan de mejora implementado |
| 5.5 | Actualizar este plan si se identifican gaps | OPD | Nueva versión del plan |
| 5.6 | Capacitación al personal (si el incidente reveló gaps de conocimiento) | OPD | Registro de capacitación |

---

## 6. Plantilla de Registro de Incidente

```
## REGISTRO DE INCIDENTE DE SEGURIDAD DE DATOS

**ID Incidente:** INC-[AAAA]-[###]
**Fecha/hora de detección:** [_______________]
**Fecha/hora de reporte:** [_______________]
**Reportado por:** [_______________]
**Clasificación:** ☐ CRÍTICO | ☐ ALTO | ☐ MEDIO | ☐ BAJO

### Descripción del incidente
[_______________]

### Datos comprometidos
- Tipo de datos: [_______________]
- Número estimado de titulares: [_______________]
- Bases de datos afectadas: [_______________]

### Cronología de respuesta
| Hora | Acción | Responsable |
|------|--------|------------|
| [___] | [___] | [___] |

### Notificaciones realizadas
- [ ] Titulares: [Fecha] [Medio]
- [ ] SIC: [Fecha] [Radicado]
- [ ] Clientes corporativos: [Fecha]
- [ ] Encargados: [Fecha]

### Causa raíz
[_______________]

### Acciones correctivas
[_______________]

### Estado
☐ Abierto | ☐ En contención | ☐ En remediación | ☐ Cerrado
```

---

## 7. Simulacros

EL RESPONSABLE realizará un **simulacro de incidente de datos** al menos una vez al año para verificar la efectividad de este plan.

| Frecuencia | Tipo | Participantes |
|-----------|------|--------------|
| Anual (obligatorio) | Tabletop exercise completo | Equipo completo de respuesta |
| Semestral (recomendado) | Simulacro parcial (notificación) | OPD + Legal + Comunicaciones |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-02 / Javier Montaño + Claude

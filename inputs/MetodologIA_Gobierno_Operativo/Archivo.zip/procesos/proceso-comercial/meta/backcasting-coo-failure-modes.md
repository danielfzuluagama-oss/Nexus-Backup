# Backcasting COO — Modos de Fallo Operativo

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** COO / Director de Operaciones
**Método:** Backcasting — "¿En qué fallaría un COO novato en sus primeros 90 días?"

---

## Propósito

Este documento identifica los **20 modos de fallo más probables** que un COO sin experiencia sufriría al operar MetodologIA. Cada modo de fallo está mapeado a un documento o proceso que lo cierra. Si el documento no existe, es una brecha crítica.

**Uso:** Gate de validación para el gobierno operativo. Si algún FM tiene mitigación = "NINGUNA", es un riesgo abierto.

---

## Matriz de Modos de Fallo

### Severidad
- **CRÍTICO:** Exposición legal, pérdida financiera >10% revenue, o daño reputacional irreparable
- **ALTO:** Ineficiencia operativa, disputas con clientes/partners, cash flow comprometido
- **MEDIO:** Oportunidad perdida, fricción interna, métricas sin visibilidad

---

### FM-01: Sin MSA Paraguas — Gaps Entre Verticales

| Campo | Valor |
|-------|-------|
| **Categoría** | Legal |
| **Severidad** | CRÍTICO |
| **Descripción** | Los contratos son verticales (GTM, Reseller). Un cliente que contrata Workshop + Consultoría necesita 2 contratos separados sin marco unificado. Si surge disputa, no hay jurisdicción clara ni términos generales aplicables. |
| **Mitigación actual** | `contrato-marco-alianza-gtm.md` y `contrato-marco-resellers.md` existen, pero solo para aliados. **No hay MSA para clientes directos.** |
| **Fase que lo cierra** | Fase 1 |
| **Documento requerido** | `contrato-marco-servicios-msa.md` |

---

### FM-02: Brecha de Datos Sin Plan de Respuesta

| Campo | Valor |
|-------|-------|
| **Categoría** | Compliance |
| **Severidad** | CRÍTICO |
| **Descripción** | Si un tercero accede a datos personales de clientes, no hay procedimiento documentado. La SIC (Superintendencia de Industria y Comercio) exige notificación en plazo. Sin plan, la respuesta es improvisada y tardía. |
| **Mitigación actual** | `acuerdo-tratamiento-datos-dpa.md` y `autorizacion-habeas-data.md` existen, pero **no hay plan de respuesta a incidentes**. |
| **Fase que lo cierra** | Fase 1 |
| **Documento requerido** | `plan-respuesta-brechas-datos.md` |

---

### FM-03: Descuento No Autorizado — Sin Matriz de Autoridad

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales |
| **Severidad** | CRÍTICO |
| **Descripción** | Un sales rep ofrece 40% de descuento para cerrar un deal "estratégico". No hay política escrita que defina quién puede autorizar qué nivel de descuento. El margen se destruye sin governance. |
| **Mitigación actual** | `checklist-pre-firma.md` valida precio vs. catálogo y requiere aprobación del Director Comercial si hay descuento, pero **no hay matriz formal de bandas de descuento ni escalamiento por monto**. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `matriz-autoridad-descuentos.md` |

---

### FM-04: Revenue Reconocido Prematuramente — Crisis de Caja

| Campo | Valor |
|-------|-------|
| **Categoría** | Financiero |
| **Severidad** | CRÍTICO |
| **Descripción** | Se reconoce el 100% del ingreso al firmar contrato, pero el delivery dura 6 meses. Cuando los costos se acumulan sin nuevo ingreso, hay crisis de caja. NIIF/IFRS 15 exige reconocimiento por performance obligation cumplida. |
| **Mitigación actual** | **NINGUNA.** No hay SOP de reconocimiento de ingresos. |
| **Fase que lo cierra** | Fase 3 |
| **Documento requerido** | `reconocer-ingresos-sop.md` |

---

### FM-05: Sin ToS en Web — Exposición Habeas Data B2C

| Campo | Valor |
|-------|-------|
| **Categoría** | Legal |
| **Severidad** | CRÍTICO |
| **Descripción** | El sitio web recolecta datos (formularios de contacto, registro a eventos) sin Términos de Servicio publicados ni Política de Privacidad visible. Violación directa de Ley 1581/2012 Art. 12 (deber de información al titular). |
| **Mitigación actual** | `autorizacion-habeas-data.md` existe para recolección directa, pero **no hay ToS ni Política de Privacidad publicada en web**. |
| **Fase que lo cierra** | Fase 1 |
| **Documentos requeridos** | `terminos-de-servicio-tos.md`, `politica-de-privacidad.md` |

---

### FM-06: Leads Calificados por Instinto — Pipeline Inflado

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales |
| **Severidad** | ALTO |
| **Descripción** | Sin rúbrica de scoring, cada sales rep califica leads por "feeling". Pipeline muestra $500M COP pero solo $50M es real. Forecast es ficción. Decisiones de contratación y gasto se basan en datos falsos. |
| **Mitigación actual** | `caracterizacion.md` existe por vertical con arquetipos, pero **no hay rúbrica de scoring cuantitativo**. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `rubrica-scoring-leads.md` |

---

### FM-07: Factura Tardía o en Formato Incorrecto

| Campo | Valor |
|-------|-------|
| **Categoría** | Operaciones Comerciales |
| **Severidad** | ALTO |
| **Descripción** | La factura llega 15 días después del hito. O llega sin CUFE (Código Único de Factura Electrónica DIAN). El cliente rechaza y el cobro se atrasa 30-60 días adicionales. Cash flow comprometido. |
| **Mitigación actual** | **NINGUNA.** No hay SOP de facturación. |
| **Fase que lo cierra** | Fase 3 |
| **Documento requerido** | `facturar-servicio-sop.md`, `plantilla-factura.md` |

---

### FM-08: IP Cedida Sin Cláusula Estándar

| Campo | Valor |
|-------|-------|
| **Categoría** | Legal |
| **Severidad** | ALTO |
| **Descripción** | En un workshop se crea material (frameworks, plantillas, código). Sin cláusula de IP, el cliente asume que es suyo. MetodologIA pierde propiedad intelectual que es core de su valor. |
| **Mitigación actual** | `clausulas-estandar-contratos.md` referencia propiedad intelectual, pero **no hay plantilla standalone de cesión/retención de IP**. |
| **Fase que lo cierra** | Fase 1 |
| **Documento requerido** | `cesion-derechos-ip.md` |

---

### FM-09: Onboarding Sin Baseline de SLA

| Campo | Valor |
|-------|-------|
| **Categoría** | Onboarding |
| **Severidad** | ALTO |
| **Descripción** | El cliente empieza delivery sin SLA definido. A los 30 días reclama "respuesta lenta". No hay baseline contra qué medir. Escalación sin métricas = percepción subjetiva = pérdida de confianza. |
| **Mitigación actual** | `anexo-a-sla-black-label.md` existe como template premium, pero **no hay SOP para negociar y establecer baseline de SLA per deal**. |
| **Fase que lo cierra** | Fase 4 |
| **Documento requerido** | `establecer-sla-baseline-sop.md`, `sla-baseline-template.md` |

---

### FM-10: Contrato Vence Sin Detección — No CLM

| Campo | Valor |
|-------|-------|
| **Categoría** | Legal |
| **Severidad** | ALTO |
| **Descripción** | Un contrato marco con aliado GTM vence. Nadie lo detecta. Se siguen emitiendo órdenes de servicio sobre contrato expirado. Si hay disputa, el ODS es nulo por falta de marco vigente. |
| **Mitigación actual** | **NINGUNA.** No hay proceso de gestión del ciclo de vida de contratos. |
| **Fase que lo cierra** | Fase 1 |
| **Documento requerido** | `proceso-ciclo-vida-contratos-clm.md` |

---

### FM-11: Disputa de Comisión Sin Matriz Documentada

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales / Compensación |
| **Severidad** | ALTO |
| **Descripción** | Sales rep cierra un deal y espera 15% de comisión. La empresa dice que es 8%. No hay documento que ambos hayan firmado definiendo la estructura de compensación. Conflicto laboral, posible demanda. |
| **Mitigación actual** | `liquidar-compensacion-10-20-70-sop.md` existe para embajadores, pero **no hay matriz de compensación para el equipo de ventas directo**. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `matriz-compensacion-ventas.md` |

---

### FM-12: Proveedor Cae Sin Due Diligence Previa

| Campo | Valor |
|-------|-------|
| **Categoría** | Vendor Management |
| **Severidad** | MEDIO |
| **Descripción** | La plataforma LMS que soporta bootcamps deja de funcionar. No se hizo due diligence, no hay SLA con el proveedor, no hay plan B. Los participantes del bootcamp quedan sin acceso. |
| **Mitigación actual** | **NINGUNA.** No hay framework de gestión de proveedores. |
| **Fase que lo cierra** | Fase 1 (checklist) + Fase 6 (proceso completo) |
| **Documento requerido** | `checklist-due-diligence-proveedores.md` |

---

### FM-13: Sobrecosto No Detectado — Sin Reporte de Varianza

| Campo | Valor |
|-------|-------|
| **Categoría** | Financiero |
| **Severidad** | MEDIO |
| **Descripción** | Un programa élite cuesta 40% más de lo presupuestado. Nadie lo detecta hasta el cierre trimestral. Sin reporte mensual de varianza, las desviaciones se acumulan silenciosamente. |
| **Mitigación actual** | **NINGUNA.** No hay reporte de varianza presupuestal. |
| **Fase que lo cierra** | Fase 3 |
| **Documento requerido** | `plantilla-reporte-varianza.md`, `aprobar-gasto-sop.md` |

---

### FM-14: Cliente Envía Datos Personales Antes de NDA/Habeas Data

| Campo | Valor |
|-------|-------|
| **Categoría** | Onboarding / Compliance |
| **Severidad** | ALTO |
| **Descripción** | En la fase de discovery, el cliente comparte listas de empleados con datos personales. No se ha firmado NDA ni autorización habeas data. MetodologIA procesa datos sin base legal. Exposición ante SIC. |
| **Mitigación actual** | `checklist-pre-firma.md` valida NDA y habeas data antes de firma de contrato, pero **no hay gate que impida recibir datos personales ANTES del contrato (en fase discovery/pre-sales)**. |
| **Fase que lo cierra** | Fase 4 |
| **Documento requerido** | `recolectar-datos-progresivo-sop.md` (define qué datos se pueden recibir en cada fase) |

---

### FM-15: Propuesta Va al Cliente Sin Gate de Aprobación

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales |
| **Severidad** | ALTO |
| **Descripción** | Un sales rep envía propuesta de COP 200M directamente al cliente sin aprobación interna. El pricing está mal, el alcance es inalcanzable, o los términos son desfavorables. Una vez enviada, el cliente la acepta y MetodologIA queda comprometida. |
| **Mitigación actual** | **NINGUNA.** No hay SOP de aprobación de propuestas con gates por monto. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `aprobar-propuesta-sop.md`, `plantilla-propuesta-comercial.md` |

---

### FM-16: Sin Ceremonia de Kickoff — Expectativas Desalineadas

| Campo | Valor |
|-------|-------|
| **Categoría** | Onboarding |
| **Severidad** | MEDIO |
| **Descripción** | Delivery arranca sin kickoff formal. El equipo técnico no conoce al sponsor. El cliente espera resultados en 30 días, delivery planificó 90. A las 4 semanas, escalación por "falta de avance". |
| **Mitigación actual** | `02-BRIDGE-COMERCIAL-DELIVERY.md` define Gate H-01 con 7 artefactos, pero **no hay SOP de ceremonia de kickoff con agenda, roles, y follow-up**. |
| **Fase que lo cierra** | Fase 4 |
| **Documento requerido** | `ejecutar-kickoff-sop.md`, `ceremonia-kickoff-template.md` |

---

### FM-17: Deal Review Inexistente — Pipeline Sin Governance

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales |
| **Severidad** | ALTO |
| **Descripción** | No hay ceremonia semanal de revisión de pipeline. Los deals se estancan sin detección. No hay decisión formal de "kill" para oportunidades zombi. El pipeline crece sin higiene. |
| **Mitigación actual** | `L3_GOBIERNO_OPERATIVO.md` define cadencias semanales y mensuales, pero **no hay ritual específico de deal review con formato y governance**. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `deal-review-sop.md`, `deal-review-semanal-ritual.md` |

---

### FM-18: Sin Playbook de Negociación — Concesiones No Controladas

| Campo | Valor |
|-------|-------|
| **Categoría** | Pre-Sales / Legal |
| **Severidad** | MEDIO |
| **Descripción** | El cliente pide modificar 5 cláusulas del contrato. Sin playbook, el sales rep acepta todo o escala todo a legal. Resultado: ciclo de cierre se alarga 30 días o se ceden términos críticos. |
| **Mitigación actual** | `clausulas-estandar-contratos.md` define las cláusulas, pero **no hay guía de qué es negociable, qué son red lines, y cuál es el path de escalamiento**. |
| **Fase que lo cierra** | Fase 2 |
| **Documento requerido** | `negociar-contrato-sop.md` |

---

### FM-19: Sin Proceso de Disputas de Pago

| Campo | Valor |
|-------|-------|
| **Categoría** | Operaciones Comerciales |
| **Severidad** | MEDIO |
| **Descripción** | El cliente disputa una factura: "ese hito no se entregó". No hay SOP de resolución. El cobro queda en limbo. Acumulación de cartera > 90 días. |
| **Mitigación actual** | **NINGUNA.** No hay SOP de disputas ni resolución de pagos. |
| **Fase que lo cierra** | Fase 3 |
| **Documento requerido** | `resolver-disputa-pago-sop.md` |

---

### FM-20: Conflicto de Intereses No Declarado

| Campo | Valor |
|-------|-------|
| **Categoría** | Governance |
| **Severidad** | MEDIO |
| **Descripción** | Un embajador comercial también es proveedor de un competidor. No hay política que obligue a declarar conflictos. Cuando se descubre, la confianza del ecosistema se erosiona. |
| **Mitigación actual** | **NINGUNA.** No hay política de conflicto de intereses. |
| **Fase que lo cierra** | Fase 1 |
| **Documento requerido** | `politica-conflicto-intereses.md` |

---

## Resumen de Cobertura

| Severidad | Total | Con mitigación parcial | Sin mitigación |
|-----------|-------|----------------------|----------------|
| CRÍTICO | 5 | 3 | 2 |
| ALTO | 10 | 4 | 6 |
| MEDIO | 5 | 1 | 4 |
| **TOTAL** | **20** | **8** | **12** |

**60% de los modos de fallo no tienen mitigación alguna.** Esto es la brecha que las Fases 1-6 cierran.

---

## Changelog

- v1.0.0 — Creación inicial con 20 modos de fallo / Backcasting COO / Javier Montaño + Claude

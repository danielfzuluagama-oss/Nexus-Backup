# Política de Privacidad y Tratamiento de Datos Personales

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Contexto Legal:** República de Colombia
**Normas aplicables:** Ley 1581/2012, Decreto 1377/2013, Decreto 1074/2015 (Título 3), Circular Única SIC (Título V)
**Cierra:** FM-05 (Backcasting COO)
**Publicación:** HTML en sitio web público

> **DISCLAIMER:** Template de referencia operativa. Requiere revisión por abogado y registro ante el RNBD de la SIC antes de publicación.

---

## POLÍTICA DE PRIVACIDAD — [NOMBRE COMERCIAL METODOLOGÍA]

**Última actualización:** [DD de MES de AAAA]

---

### 1. RESPONSABLE DEL TRATAMIENTO

| Campo | Valor |
|-------|-------|
| Razón social | [_______________] |
| NIT | [_______________] |
| Domicilio | [_______________] |
| Email del Oficial de Protección de Datos | [_______________] |
| Teléfono | [_______________] |
| Registro RNBD | [Número de registro ante la SIC] |

---

### 2. DATOS QUE RECOLECTAMOS

#### 2.1 Datos proporcionados directamente por el titular

| Dato | Finalidad | Base legal |
|------|-----------|-----------|
| Nombre completo | Identificación, comunicación | Consentimiento (Art. 9, Ley 1581/2012) |
| Correo electrónico | Comunicación, acceso a plataforma | Consentimiento |
| Teléfono | Comunicación comercial | Consentimiento |
| Empresa / Cargo | Segmentación, personalización | Consentimiento |
| Datos financieros (facturación) | Emisión de facturas, cobro | Obligación legal (Estatuto Tributario) |
| Foto de perfil (opcional) | Personalización de plataforma | Consentimiento |

#### 2.2 Datos recolectados automáticamente

| Dato | Finalidad | Base legal |
|------|-----------|-----------|
| Dirección IP | Seguridad, análisis de uso | Interés legítimo |
| Cookies y tecnologías similares | Funcionalidad, experiencia de usuario | Consentimiento (banner de cookies) |
| Datos de navegación | Mejora de servicios, analytics | Consentimiento |
| Datos de participación (asistencia, evaluaciones) | Calidad del servicio, certificación | Ejecución contractual |

#### 2.3 Datos sensibles

EL RESPONSABLE **no recolecta datos sensibles** (origen racial o étnico, orientación política, convicciones religiosas, datos biométricos, datos de salud) salvo cuando sea estrictamente necesario y medie autorización expresa conforme al Art. 6 de la Ley 1581/2012.

---

### 3. FINALIDADES DEL TRATAMIENTO

Los datos personales serán utilizados para:

**Finalidades primarias (necesarias para el servicio):**
1. Gestión de la relación contractual (registro, facturación, soporte).
2. Prestación de los servicios contratados (formación, consultoría, plataforma).
3. Emisión de certificados de participación o aprobación.
4. Cumplimiento de obligaciones legales y tributarias.

**Finalidades secundarias (opcionales):**
5. Envío de comunicaciones comerciales sobre nuevos servicios y eventos.
6. Estudios de mercado y encuestas de satisfacción.
7. Personalización de la experiencia en la Plataforma.

El titular puede negar su consentimiento para las finalidades secundarias sin que ello afecte la prestación de los servicios contratados.

---

### 4. DERECHOS DEL TITULAR (Art. 8, Ley 1581/2012)

El titular de los datos personales tiene derecho a:

1. **Conocer:** Acceder a sus datos personales que han sido objeto de tratamiento.
2. **Actualizar:** Solicitar la actualización de sus datos cuando estén incompletos o inexactos.
3. **Rectificar:** Corregir datos erróneos.
4. **Suprimir:** Solicitar la eliminación de sus datos cuando no exista obligación legal de conservarlos.
5. **Revocar:** Revocar la autorización otorgada para el tratamiento.
6. **Acceder:** Obtener prueba de la autorización otorgada.
7. **Presentar quejas:** Ante la SIC por infracciones a la Ley 1581/2012.

**Para ejercer estos derechos:**
- Email: [email del Oficial de Protección de Datos]
- Asunto: "Ejercicio de derechos ARCO — [nombre del titular]"
- Plazo de respuesta: **diez (10) días hábiles** para consultas, **quince (15) días hábiles** para reclamos (Art. 14 y 15, Ley 1581/2012).

---

### 5. TRANSFERENCIA Y TRANSMISIÓN DE DATOS

| Destinatario | País | Finalidad | Base legal |
|-------------|------|-----------|-----------|
| Plataforma LMS | [País del proveedor] | Acceso a contenido educativo | Contrato de transmisión (Art. 25, Decreto 1377/2013) |
| Proveedor de email marketing | [País] | Envío de comunicaciones | Consentimiento + contrato |
| Proveedor de facturación electrónica | Colombia | Cumplimiento DIAN | Obligación legal |
| Plataforma de videoconferencia | [País] | Prestación de servicios virtuales | Consentimiento + contrato |

**Parágrafo:** Para transferencias internacionales, EL RESPONSABLE verifica que el país de destino cuente con niveles adecuados de protección de datos conforme al Art. 26 de la Ley 1581/2012 y la Circular Externa 005 de 2017 de la SIC, o que se cumplan las excepciones del Art. 26 numeral 2.

---

### 6. MEDIDAS DE SEGURIDAD

EL RESPONSABLE implementa las siguientes medidas para proteger los datos personales:

1. **Técnicas:** Cifrado de datos en tránsito (TLS/SSL) y en reposo, control de acceso basado en roles, monitoreo de acceso.
2. **Organizativas:** Política interna de seguridad de la información, capacitación periódica del personal, acuerdos de confidencialidad con empleados y contratistas.
3. **Físicas:** Control de acceso a instalaciones donde se procesan datos.

---

### 7. COOKIES

La Plataforma utiliza cookies para:

| Tipo | Propósito | Duración | Consentimiento |
|------|-----------|----------|---------------|
| Esenciales | Funcionamiento de la Plataforma | Sesión | No requerido |
| Funcionales | Preferencias del usuario | 1 año | Requerido |
| Analíticas | Estadísticas de uso (Google Analytics o similar) | 2 años | Requerido |
| Marketing | Publicidad personalizada | 1 año | Requerido |

El Usuario puede gestionar sus preferencias de cookies a través del banner de cookies o la configuración de su navegador.

---

### 8. CONSERVACIÓN DE DATOS

| Tipo de dato | Plazo de conservación | Justificación |
|-------------|----------------------|---------------|
| Datos contractuales | 10 años post-terminación | Prescripción de acciones (Código de Comercio) |
| Datos tributarios (facturas) | 5 años | Estatuto Tributario Art. 632 |
| Datos de certificación | Indefinido | Verificación de certificados |
| Datos de marketing | Hasta revocación del consentimiento | Consentimiento del titular |
| Datos de navegación | 2 años | Mejora de servicios |

---

### 9. INCIDENTES DE SEGURIDAD

En caso de incidente de seguridad que comprometa datos personales:

1. EL RESPONSABLE lo investigará dentro de las **veinticuatro (24) horas** siguientes a su detección.
2. Notificará a los titulares afectados dentro de los **tres (3) días hábiles** si el incidente representa riesgo significativo para sus derechos.
3. Notificará a la SIC conforme a la normativa vigente.
4. Implementará medidas correctivas para prevenir recurrencia.

Procedimiento detallado: `plan-respuesta-brechas-datos.md`

---

### 10. MODIFICACIONES A ESTA POLÍTICA

1. EL RESPONSABLE se reserva el derecho de modificar esta Política.
2. Las modificaciones se publicarán en la Plataforma con **quince (15) días** de anticipación.
3. Se notificará por email a los titulares registrados sobre cambios sustanciales.
4. El uso continuado de los servicios posterior a la fecha de vigencia constituye aceptación.

---

### 11. CONTACTO Y QUEJAS

| Canal | Dato |
|-------|------|
| Oficial de Protección de Datos | [Email] |
| Dirección física | [Dirección] |
| Teléfono | [Teléfono] |
| Queja ante la SIC | www.sic.gov.co — Delegatura para la Protección de Datos Personales |

---

## Changelog

- v1.0.0 — Creación inicial de Política de Privacidad / Cierra FM-05 / Javier Montaño + Claude

# Acuerdo de Cesión de Derechos de Propiedad Intelectual

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Contexto Legal:** República de Colombia
**Normas aplicables:** Decisión Andina 351/1993 (Régimen Común de Derechos de Autor), Ley 23/1982 (Derechos de Autor), Decisión Andina 486/2000 (Propiedad Industrial), Código de Comercio
**Cierra:** FM-08 (Backcasting COO)
**Uso:** Anexo al MSA o a la ODS cuando se requiera cesión formal de IP

> **DISCLAIMER:** Template de referencia operativa. Requiere revisión por abogado especialista en propiedad intelectual.

---

## ACUERDO DE CESIÓN DE DERECHOS DE PROPIEDAD INTELECTUAL

**Acuerdo No.:** [_______________]
**ODS vinculada:** [Referencia ODS]
**MSA vinculado:** [Referencia MSA]

---

### PARTES

**CEDENTE:** [NOMBRE RAZÓN SOCIAL DEL PRESTADOR], NIT [_______________], representada por [_______________]

**CESIONARIO:** [NOMBRE RAZÓN SOCIAL DEL CLIENTE], NIT [_______________], representada por [_______________]

---

### CLÁUSULA PRIMERA — DEFINICIONES

1. **Obra:** Todo material, documento, código fuente, diseño, presentación, framework, plantilla, o entregable creado por EL CEDENTE específicamente para EL CESIONARIO en el contexto de la ODS vinculada.
2. **IP Preexistente:** Toda propiedad intelectual que existía antes de la fecha de inicio de la ODS, o que fue desarrollada fuera del alcance de la ODS.
3. **Derechos Patrimoniales:** Los derechos de reproducción, comunicación pública, distribución, transformación, y puesta a disposición previstos en la Decisión Andina 351/1993.
4. **Derechos Morales:** Los derechos inalienables e irrenunciables del autor (paternidad, integridad, inédito, modificación, retiro) conforme al Art. 30 de la Ley 23/1982.

---

### CLÁUSULA SEGUNDA — OBJETO DE LA CESIÓN

EL CEDENTE cede a EL CESIONARIO los **Derechos Patrimoniales** sobre la Obra descrita en el **Anexo 1** de este acuerdo, bajo las siguientes condiciones:

| Aspecto | Términos |
|---------|----------|
| **Alcance** | ☐ Total (todos los derechos patrimoniales) / ☐ Parcial (ver detalle abajo) |
| **Territorio** | ☐ Mundial / ☐ Colombia / ☐ Otro: [_______________] |
| **Duración** | ☐ Por toda la vigencia legal de los derechos / ☐ Por [___] años |
| **Exclusividad** | ☐ Exclusiva / ☐ No exclusiva |
| **Sublicencia** | ☐ Con derecho a sublicenciar / ☐ Sin derecho a sublicenciar |

**Si cesión parcial, los derechos cedidos son:**
- [ ] Reproducción
- [ ] Comunicación pública
- [ ] Distribución
- [ ] Transformación (obras derivadas)
- [ ] Puesta a disposición digital

---

### CLÁUSULA TERCERA — EXCLUSIONES DE LA CESIÓN

**NO se ceden** bajo este acuerdo:

1. **Derechos Morales:** Conforme al Art. 30 de la Ley 23/1982, los derechos morales son inalienables e irrenunciables. EL CEDENTE conserva la paternidad y la integridad de la Obra.

2. **IP Preexistente:** Las metodologías, frameworks, herramientas, plantillas, y know-how preexistente de EL CEDENTE no son objeto de cesión. EL CESIONARIO recibe una **licencia de uso no exclusiva, intransferible** sobre la IP Preexistente incorporada en la Obra, limitada al uso de la Obra cedida.

3. **Conocimiento general:** El conocimiento técnico general, habilidades, y experiencia adquirida por EL CEDENTE durante la ejecución del servicio no está sujeto a restricción.

---

### CLÁUSULA CUARTA — CONTRAPRESTACIÓN

La cesión de derechos patrimoniales está incluida en el valor de la ODS vinculada: COP [_______________] + IVA.

**Parágrafo:** La cesión se perfecciona únicamente con el pago total del valor de la ODS. Hasta tanto no se reciba el pago completo, EL CEDENTE conserva todos los derechos patrimoniales.

---

### CLÁUSULA QUINTA — GARANTÍAS DE EL CEDENTE

EL CEDENTE garantiza que:

1. Es el titular original o tiene los derechos suficientes para otorgar la cesión.
2. La Obra es original y no infringe derechos de terceros.
3. No ha otorgado previamente derechos exclusivos a terceros sobre la Obra.
4. Cuenta con las autorizaciones necesarias de todos los co-autores (si los hay).

**Parágrafo:** En caso de reclamación de terceros por infracción de propiedad intelectual derivada de la Obra, EL CEDENTE mantendrá indemne a EL CESIONARIO, hasta por el valor total de la ODS vinculada.

---

### CLÁUSULA SEXTA — REGISTRO

Las partes podrán registrar la presente cesión ante la **Dirección Nacional de Derecho de Autor (DNDA)** de Colombia, conforme al Art. 183 de la Ley 23/1982. Los costos de registro serán asumidos por [_______________].

---

### CLÁUSULA SÉPTIMA — LEY APLICABLE

Este acuerdo se rige por las leyes de la República de Colombia, en particular la Decisión Andina 351/1993 y la Ley 23/1982.

---

### FIRMAS

**POR EL CEDENTE:**

Nombre: ____________________________________
Cargo: ____________________________________
Firma: ____________________________________
Fecha: ____________________________________

**POR EL CESIONARIO:**

Nombre: ____________________________________
Cargo: ____________________________________
Firma: ____________________________________
Fecha: ____________________________________

---

### ANEXO 1 — DESCRIPCIÓN DE LA OBRA

| Campo | Detalle |
|-------|---------|
| Título/Nombre de la Obra | [_______________] |
| Tipo | ☐ Software / ☐ Documento / ☐ Diseño / ☐ Framework / ☐ Presentación / ☐ Otro: [___] |
| Descripción | [_______________] |
| Formato de entrega | [_______________] |
| ODS vinculada | [_______________] |
| Fecha de creación | [_______________] |
| Autor(es) | [_______________] |
| IP Preexistente incorporada | [Listar frameworks/herramientas de MetodologIA incorporados, si aplica] |

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-08 / Javier Montaño + Claude

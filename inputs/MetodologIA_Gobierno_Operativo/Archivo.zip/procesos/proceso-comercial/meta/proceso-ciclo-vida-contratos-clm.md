# Proceso de Gestión del Ciclo de Vida de Contratos (CLM)

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** COO / Director Legal
**Cierra:** FM-10 (Backcasting COO)

---

## 1. Propósito

Garantizar que **ningún contrato venza sin detección**, que las renovaciones se gestionen proactivamente, y que las enmiendas se tracen. Este proceso previene el FM-10: emitir ODS sobre contratos expirados.

---

## 2. Fases del Ciclo de Vida

```
SOLICITUD → REDACCIÓN → REVISIÓN → NEGOCIACIÓN → FIRMA → EJECUCIÓN → MONITOREO → RENOVACIÓN/TERMINACIÓN
```

---

## 3. Procedimiento por Fase

### Fase 1: SOLICITUD (Día 0)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 1.1 | Identificar necesidad contractual (nueva ODS, nuevo aliado, renovación) | Sales Rep / Director Comercial | Email/ticket de solicitud |
| 1.2 | Verificar si existe Contrato Marco vigente con la contraparte | Operaciones | Consulta al registro CLM |
| 1.3 | Si no existe CM, iniciar proceso de MSA | Operaciones + Legal | Solicitud formal de MSA |
| 1.4 | Asignar ID único al contrato: `CLM-[AAAA]-[###]` | Operaciones | ID asignado en registro |

### Fase 2: REDACCIÓN (Días 1-5)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 2.1 | Seleccionar template apropiado (MSA, ODS, NDA, etc.) | Legal / Operaciones | Template seleccionado |
| 2.2 | Completar campos variables (partes, alcance, precio, plazos) | Sales Rep + Operaciones | Borrador v1 |
| 2.3 | Verificar cláusulas estándar incluidas (ref: `clausulas-estandar-contratos.md`) | Legal | Checklist de cláusulas |

### Fase 3: REVISIÓN INTERNA (Días 5-10)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 3.1 | Revisión legal (cumplimiento normativo, riesgos) | Legal | Memo de revisión |
| 3.2 | Revisión financiera (términos de pago, márgenes, descuentos) | Finanzas | Aprobación financiera |
| 3.3 | Revisión comercial (alcance, SLA, compromisos) | Director Comercial | Aprobación comercial |
| 3.4 | Ejecutar `checklist-pre-firma.md` | Deal Manager | Checklist completado al 100% |

### Fase 4: NEGOCIACIÓN (Días 10-25)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 4.1 | Enviar borrador a contraparte | Sales Rep | Email con borrador y versión |
| 4.2 | Recibir y evaluar comentarios/red-lines de contraparte | Legal | Matriz de cambios solicitados |
| 4.3 | Clasificar cambios: Aceptable / Negociable / Red Line | Legal + Director Comercial | Matriz clasificada |
| 4.4 | Negociar según playbook (`negociar-contrato-sop.md`) | Sales Rep + Legal | Registro de negociación |
| 4.5 | Si cambio afecta margen/riesgo, escalar según matriz de autoridad | Director Comercial / CEO | Aprobación de escalamiento |

### Fase 5: FIRMA (Días 25-30)

| Paso | Acción | Responsable | Evidencia |
|------|--------|------------|-----------|
| 5.1 | Generar versión final en PDF | Operaciones | PDF final con watermark "VERSIÓN PARA FIRMA" |
| 5.2 | Obtener firma de representante legal MetodologIA | CEO / Rep. Legal | Firma en contrato |
| 5.3 | Obtener firma de contraparte | Sales Rep | Firma en contrato |
| 5.4 | Verificar firmas completas (ambas partes, fecha, testigos si aplica) | Operaciones | Contrato con firmas verificadas |
| 5.5 | Registrar contrato en el registro CLM | Operaciones | Entrada en registro con todos los campos |

### Fase 6: EJECUCIÓN Y MONITOREO (Vigencia del contrato)

| Paso | Acción | Responsable | Frecuencia | Evidencia |
|------|--------|------------|-----------|-----------|
| 6.1 | Monitorear cumplimiento de obligaciones (ambas partes) | Operaciones | Mensual | Informe de cumplimiento |
| 6.2 | Verificar hitos de pago y facturación | Finanzas | Por hito/mensual | Registro de facturación |
| 6.3 | Gestionar enmiendas (si hay cambios de alcance) | Legal + Sales Rep | Cuando ocurra | Enmienda firmada con ID `CLM-[AAAA]-[###]-AMD-[##]` |
| 6.4 | **Alerta de vencimiento: 90 días antes** | Operaciones | Automática | Notificación al Director Comercial |
| 6.5 | **Alerta de vencimiento: 60 días antes** | Operaciones | Automática | Notificación al CEO |
| 6.6 | **Alerta de vencimiento: 30 días antes** | Operaciones | Automática | Decisión: Renovar / Renegociar / Terminar |

### Fase 7: RENOVACIÓN O TERMINACIÓN

| Escenario | Acción | Responsable | Plazo |
|-----------|--------|------------|-------|
| **Renovación automática** | Verificar que no se requiera notificación de no-renovación | Operaciones | 30d antes del vencimiento |
| **Renegociación** | Iniciar nueva ronda de negociación con términos actualizados | Sales Rep + Legal | 60d antes |
| **Terminación con causa** | Notificar incumplimiento, dar plazo de cura (30d), terminar si no se subsana | Legal | Conforme cláusula contractual |
| **Terminación sin causa** | Enviar notificación escrita con anticipación pactada | Director Comercial | 60d anticipación (o lo que diga el contrato) |
| **Archivo** | Mover contrato al estado "Archivado" en registro CLM. Conservar por 10 años. | Operaciones | Post-terminación |

---

## 4. Registro CLM (Campos Obligatorios)

Cada contrato debe registrarse con los siguientes campos:

| Campo | Ejemplo |
|-------|---------|
| ID CLM | `CLM-2026-001` |
| Tipo | MSA / ODS / NDA / Alianza GTM / Reseller |
| Contraparte (razón social) | Empresa XYZ S.A.S. |
| NIT contraparte | 900.xxx.xxx-x |
| Fecha de firma | 2026-03-25 |
| Fecha de inicio de vigencia | 2026-04-01 |
| Fecha de vencimiento | 2027-03-31 |
| Renovación automática | SÍ / NO |
| Preaviso de no-renovación | 30 días |
| Valor total | COP $XXX.XXX.XXX + IVA |
| Moneda | COP |
| Estado | Activo / En negociación / Vencido / Terminado / Archivado |
| Archivo digital | Ruta al PDF firmado |
| Enmiendas | Lista de IDs de enmiendas |
| SPOC MetodologIA | Nombre y email |
| SPOC Cliente | Nombre y email |
| Alerta 90d | ☐ Enviada / ☐ Pendiente |
| Alerta 60d | ☐ Enviada / ☐ Pendiente |
| Alerta 30d | ☐ Enviada / ☐ Pendiente |
| Decisión de renovación | Renovar / Renegociar / Terminar / Pendiente |

---

## 5. KPIs del Proceso CLM

| KPI | Meta | Frecuencia |
|-----|------|-----------|
| % contratos con alerta 90d enviada a tiempo | 100% | Mensual |
| Tiempo promedio de ciclo (solicitud → firma) | < 30 días | Mensual |
| % contratos vencidos sin decisión | 0% | Mensual |
| % enmiendas formalizadas vs. verbales | > 95% | Trimestral |
| Contratos activos sin SPOC asignado | 0 | Mensual |

---

## 6. Supuestos

SUPUESTO: Existe una herramienta (hoja de cálculo, CRM, o sistema CLM) para gestionar el registro de contratos y las alertas automáticas.
- Validar con: COO + TI
- Fecha límite: 30 días post-aprobación de este proceso
- Si se invalida: Implementar registro manual con alertas de calendario

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-10 / Javier Montaño + Claude

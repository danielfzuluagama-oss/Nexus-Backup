# Checklist de Due Diligence para Proveedores

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Owner:** COO / Operaciones
**Cierra:** FM-12 (Backcasting COO)
**Uso:** Completar ANTES de contratar o renovar con cualquier proveedor crítico

---

## Instrucciones

Este checklist debe completarse para todo proveedor que cumpla al menos UNO de estos criterios:
- Procesa datos personales de clientes o empleados
- Valor anual del contrato > COP 10M
- Presta un servicio crítico para la operación (plataforma, pagos, comunicaciones)
- Tiene acceso a información confidencial

**Responsable:** Operaciones (con apoyo de TI y Legal según corresponda)
**Tiempo estimado:** 1-2 horas

---

## SECCIÓN A: IDENTIFICACIÓN DEL PROVEEDOR

- [ ] **Razón social:** [_______________]
- [ ] **NIT / Tax ID:** [_______________]
- [ ] **País de constitución:** [_______________]
- [ ] **Dirección:** [_______________]
- [ ] **Representante legal:** [_______________]
- [ ] **Contacto comercial:** [_______________] / Email: [_______________]
- [ ] **Sitio web:** [_______________]
- [ ] **Servicio a contratar:** [_______________]
- [ ] **Categoría:** ☐ Tecnología / ☐ Formación / ☐ Profesional / ☐ Infraestructura / ☐ Financiero / ☐ Otro

---

## SECCIÓN B: EXISTENCIA LEGAL Y FINANCIERA

- [ ] **Cámara de Comercio vigente (o equivalente)** verificada
  - Fecha de constitución: [_______________]
  - Estado: ☐ Activo | ☐ Inactivo (BLOQUEADOR)
- [ ] **RUT vigente** (si Colombia) o registro fiscal equivalente verificado
- [ ] **No aparece en listas restrictivas** (OFAC, Lista Clinton, ONU, listas SIC)
  - Verificación realizada: ☐ SÍ | ☐ NO (BLOQUEADOR)
  - Herramienta usada: [_______________]
- [ ] **Antigüedad mínima:** ≥ 2 años de operación (o justificación documentada si <2 años)
- [ ] **Referencias comerciales:** Al menos 2 clientes verificables
  - Referencia 1: [_______________] / Contacto: [_______________]
  - Referencia 2: [_______________] / Contacto: [_______________]

---

## SECCIÓN C: CAPACIDAD TÉCNICA Y OPERATIVA

- [ ] **Experiencia en servicios similares** demostrada (portafolio, casos de éxito)
- [ ] **Equipo asignado:** ¿Tiene personal calificado para el servicio?
  - Perfil principal: [_______________]
- [ ] **Disponibilidad y SLA ofrecido:**
  - Uptime comprometido: [___]%
  - Tiempo de respuesta a incidentes: [___] horas
- [ ] **Plan de continuidad de negocio:** ¿Tiene BCP documentado?
  - ☐ SÍ (solicitar copia) | ☐ NO (riesgo medio)
- [ ] **Plan B identificado:** Si este proveedor falla, ¿existe alternativa?
  - Alternativa: [_______________] | ☐ No hay alternativa (riesgo alto)

---

## SECCIÓN D: SEGURIDAD Y PROTECCIÓN DE DATOS

- [ ] **¿Procesará datos personales?** ☐ SÍ | ☐ NO
- Si SÍ:
  - [ ] **DPA (Data Processing Agreement) firmado** o por firmar
  - [ ] **Política de privacidad** del proveedor revisada
  - [ ] **Certificaciones de seguridad:** ☐ ISO 27001 | ☐ SOC 2 | ☐ Otra: [___] | ☐ Ninguna
  - [ ] **Ubicación de los datos:** [País/Región]
  - [ ] **Cifrado en tránsito y reposo:** ☐ SÍ | ☐ NO (BLOQUEADOR si datos personales)
  - [ ] **Proceso de notificación de brechas:** ☐ Documentado | ☐ No documentado (riesgo)
  - [ ] **Retención y eliminación de datos:** Política clara y conforme a Ley 1581/2012

---

## SECCIÓN E: TÉRMINOS CONTRACTUALES

- [ ] **Contrato con cláusula de confidencialidad** (o NDA separado)
- [ ] **SLA con penalizaciones** incluido en contrato
- [ ] **Cláusula de terminación** con plazo razonable (≤30 días para portabilidad)
- [ ] **Cláusula de propiedad intelectual** clara (quién es dueño de qué)
- [ ] **Cláusula de auditoría** (derecho a auditar al proveedor)
- [ ] **Responsabilidad y limitaciones** definidas
- [ ] **Ley aplicable:** Colombia (o jurisdicción aceptable)

---

## SECCIÓN F: EVALUACIÓN DE RIESGO

| Dimensión | Riesgo | Nivel |
|-----------|--------|-------|
| Concentración (único proveedor para servicio crítico) | [___] | ☐ Alto / ☐ Medio / ☐ Bajo |
| Financiero (proveedor inestable) | [___] | ☐ Alto / ☐ Medio / ☐ Bajo |
| Datos personales (procesa datos sensibles) | [___] | ☐ Alto / ☐ Medio / ☐ Bajo |
| Reputacional (asociación con proveedor cuestionado) | [___] | ☐ Alto / ☐ Medio / ☐ Bajo |
| Operacional (sin BCP ni alternativa) | [___] | ☐ Alto / ☐ Medio / ☐ Bajo |

**Riesgo consolidado:** ☐ Alto (requiere aprobación CEO) | ☐ Medio (aprobación Director) | ☐ Bajo (aprobación Operaciones)

---

## SECCIÓN G: DECISIÓN

- [ ] **APROBADO** — Proceder con contratación
- [ ] **APROBADO CON CONDICIONES** — Condiciones: [_______________]
- [ ] **RECHAZADO** — Motivo: [_______________]

**Aprobador:** [_______________]
**Fecha:** [_______________]
**Firma:** [_______________]

---

## Changelog

- v1.0.0 — Creación inicial / Cierra FM-12 / Javier Montaño + Claude

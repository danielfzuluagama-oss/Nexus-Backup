# Términos y Condiciones de Servicio (ToS)

**Versión:** 1.0.0
**Fecha:** 2026-03-25
**Contexto Legal:** República de Colombia
**Normas aplicables:** Ley 1480/2011 (Estatuto del Consumidor), Ley 1581/2012 (Habeas Data), Ley 527/1999 (Comercio Electrónico), Decreto 1377/2013
**Cierra:** FM-05 (Backcasting COO)
**Publicación:** HTML en sitio web público

> **DISCLAIMER:** Template de referencia operativa. Requiere revisión por abogado antes de publicación.

---

## TÉRMINOS Y CONDICIONES DE USO — [NOMBRE COMERCIAL METODOLOGÍA]

**Última actualización:** [DD de MES de AAAA]

Al acceder a nuestro sitio web, registrarse en nuestros programas, o contratar nuestros servicios, usted acepta estos Términos y Condiciones. Si no está de acuerdo, por favor absténgase de utilizar nuestros servicios.

---

### 1. IDENTIFICACIÓN DEL PRESTADOR

| Campo | Valor |
|-------|-------|
| Razón social | [_______________] |
| NIT | [_______________] |
| Domicilio | [_______________] |
| Email de contacto | [_______________] |
| Teléfono | [_______________] |
| Superintendencia que vigila | Superintendencia de Industria y Comercio (SIC) |

---

### 2. DEFINICIONES

- **Plataforma:** El sitio web, aplicaciones y herramientas digitales operadas por EL PRESTADOR.
- **Usuario:** Toda persona natural o jurídica que acceda a la Plataforma o contrate servicios.
- **Servicios:** Workshops, bootcamps, programas de formación, consultoría, y demás servicios ofrecidos por EL PRESTADOR.
- **Contenido:** Todo material educativo, frameworks, plantillas, grabaciones, y recursos digitales provistos a través de los Servicios.

---

### 3. SERVICIOS OFRECIDOS

EL PRESTADOR ofrece servicios profesionales especializados en:

1. **Formación:** Workshops presenciales y virtuales, bootcamps, programas de transformación.
2. **Consultoría:** Diagnóstico, acompañamiento, evolución de capacidades.
3. **Contenido Digital:** Acceso a material educativo, frameworks, y herramientas.

Las características, precios, y condiciones específicas de cada servicio se describen en la página correspondiente de la Plataforma y/o en la propuesta comercial o contrato específico.

---

### 4. REGISTRO Y CUENTA DE USUARIO

1. Para acceder a ciertos servicios, el Usuario deberá registrarse proporcionando información veraz, completa y actualizada.
2. El Usuario es responsable de mantener la confidencialidad de sus credenciales de acceso.
3. El Usuario se compromete a notificar inmediatamente cualquier uso no autorizado de su cuenta.
4. EL PRESTADOR se reserva el derecho de suspender o cancelar cuentas que violen estos Términos.

---

### 5. PRECIOS Y PAGOS

1. Los precios de los servicios se expresan en **Pesos Colombianos (COP)** e incluyen IVA salvo indicación expresa en contrario.
2. Los pagos se realizarán a través de los medios habilitados en la Plataforma o según lo pactado en el contrato específico.
3. Las facturas electrónicas se emitirán conforme a la normativa DIAN vigente.
4. **Política de reembolso:**
   - Workshops: Reembolso del 100% si se solicita con más de 7 días de anticipación al evento. 50% si se solicita entre 3-7 días. Sin reembolso dentro de las 72 horas previas.
   - Bootcamps: Reembolso del 100% si se solicita antes del inicio de la segunda semana. Sin reembolso posterior.
   - Consultoría: Conforme a lo pactado en la ODS.
   - Programas Élite: Conforme a lo pactado en el contrato individual.

---

### 6. DERECHO DE RETRACTO (Ley 1480/2011, Art. 47)

Para servicios contratados a distancia (online, teléfono, catálogo), el consumidor persona natural tiene derecho a retractarse dentro de los **cinco (5) días hábiles** siguientes a la celebración del contrato o a la entrega del servicio, lo que ocurra después, siempre que:

1. El servicio no haya comenzado a prestarse con el consentimiento expreso del consumidor.
2. El consumidor devuelva cualquier material físico o digital entregado.

Para ejercer el derecho de retracto, el consumidor deberá enviar comunicación escrita a [email de contacto].

---

### 7. PROPIEDAD INTELECTUAL

1. Todo el Contenido disponible en la Plataforma es propiedad de EL PRESTADOR o de sus licenciantes y está protegido por las leyes de propiedad intelectual de Colombia (Decisión Andina 351/1993, Ley 23/1982).
2. El Usuario recibe una **licencia personal, no exclusiva, intransferible y revocable** para usar el Contenido únicamente en el contexto del servicio contratado.
3. Está prohibido: reproducir, distribuir, modificar, crear obras derivadas, o utilizar el Contenido con fines comerciales sin autorización previa y escrita de EL PRESTADOR.
4. Las metodologías, frameworks y herramientas de EL PRESTADOR son propiedad exclusiva de EL PRESTADOR.

---

### 8. PROTECCIÓN DE DATOS PERSONALES

1. EL PRESTADOR trata datos personales conforme a la **Ley 1581 de 2012** y su **Política de Privacidad** (enlace: [URL de política de privacidad]).
2. Al registrarse, el Usuario autoriza el tratamiento de sus datos personales para las finalidades descritas en la Política de Privacidad.
3. El Usuario tiene los derechos de: conocer, actualizar, rectificar, y suprimir sus datos personales, conforme al Art. 8 de la Ley 1581/2012.
4. Para ejercer estos derechos, el Usuario puede contactar a: [email del Oficial de Protección de Datos].
5. EL PRESTADOR está inscrito ante el **Registro Nacional de Bases de Datos (RNBD)** de la SIC.

---

### 9. CONDUCTA DEL USUARIO

El Usuario se compromete a:

1. No utilizar la Plataforma para fines ilícitos o contrarios a estos Términos.
2. No compartir credenciales de acceso con terceros.
3. No grabar, reproducir, o distribuir sesiones en vivo sin autorización expresa.
4. No realizar ingeniería inversa sobre la Plataforma o su Contenido.
5. Respetar los derechos de propiedad intelectual de EL PRESTADOR y de otros usuarios.

---

### 10. LIMITACIÓN DE RESPONSABILIDAD

1. EL PRESTADOR provee los servicios "tal como son" en lo que respecta a la Plataforma digital.
2. EL PRESTADOR no garantiza resultados específicos derivados del uso de los servicios de formación o consultoría.
3. La responsabilidad total de EL PRESTADOR se limita al valor pagado por el Usuario por el servicio específico que generó la reclamación.
4. EL PRESTADOR no será responsable por: interrupciones de servicio por causas de fuerza mayor, pérdida de datos del Usuario por negligencia del mismo, o daños indirectos o consecuenciales.

---

### 11. MODIFICACIONES

1. EL PRESTADOR se reserva el derecho de modificar estos Términos en cualquier momento.
2. Las modificaciones se notificarán mediante publicación en la Plataforma con al menos **quince (15) días** de anticipación a su entrada en vigencia.
3. El uso continuado de los servicios después de la fecha de vigencia constituye aceptación de los nuevos Términos.
4. El historial de versiones estará disponible en [URL de archivo de versiones].

---

### 12. LEY APLICABLE Y JURISDICCIÓN

1. Estos Términos se rigen por las leyes de la República de Colombia.
2. Para la resolución de controversias, LAS PARTES acudirán primero a los mecanismos de la **SIC** (Superintendencia de Industria y Comercio) para asuntos de consumidor, y al procedimiento establecido en la Cláusula Décima Segunda del MSA para relaciones comerciales B2B.

---

### 13. CONTACTO

Para preguntas sobre estos Términos:
- Email: [_______________]
- Dirección: [_______________]
- Teléfono: [_______________]

---

## Changelog

- v1.0.0 — Creación inicial de ToS para sitio web / Cierra FM-05 / Javier Montaño + Claude
